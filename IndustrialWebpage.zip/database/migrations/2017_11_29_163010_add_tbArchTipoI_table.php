<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbArchTipoITable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbArchTipoI', function (Blueprint $table) {
            $table->increments('idArchTipoI');
            $table->string('tbarchINombre',50);
            $table->string('tbarchIEstado',10);

            //$table->timestamps(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbArchTipoI');
    }
}
