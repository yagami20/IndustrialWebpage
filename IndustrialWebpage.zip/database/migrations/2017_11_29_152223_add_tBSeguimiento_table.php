<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTBSeguimientoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tBSeguimiento', function (Blueprint $table) {
            $table->increments('idSeguimiento');
            $table->integer('idMateria')->unsigned();
            $table->foreign('idMateria')->references('idMateria')->on('tbMateria')->onDelete('cascade');
            $table->string('tbseDescripcion',255);
            $table->string('tbseDocumento',255);
            $table->string('tbseFecha',255);
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tBSeguimiento');
    }
}
