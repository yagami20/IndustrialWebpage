<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbArchTipoETable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbArchTipoE', function (Blueprint $table) {
            $table->increments('idArchTipoE');
            $table->string('tbarchENombre',50);
            $table->string('tbarchEEstado',10);
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbArchTipoE');
    }
}
