<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
             $table->string('tbuCedula',10);
            $table->string('tbuNombres',30);
            $table->string('tbuApellidos',30);
            $table->string('email')->unique();
            $table->string('password');
            $table->rememberToken();
            $table->string('tbuCorreoInstitucional',30);
            $table->string('tbuSexo',1);
            $table->string('tbuTelefono',20);
            $table->date('tbuFechaNacimiento');
            $table->string('tbuFoto')->nullable();
            $table->string('tbuPais',30);
            $table->string('tbuCiudad',30);
            $table->string('tbuCurriculo',30)->nullable();
            $table->string('tbuEstado');
            $table->integer('tbtuId')->unsigned();
            $table->foreign('tbtuId')->references('tbtuId')->on('tbTipoUsuario');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('users');
    }
}
