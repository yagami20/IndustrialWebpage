<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTbDescargasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbDescargas', function (Blueprint $table) {
            $table->increments('idDescarga');
            $table->string('tbdTitulo',250);
            $table->string('tbdDescripcion',250);
            $table->string('tbdExaminar',255);
            $table->date('tbdFecha');
            $table->string('tbdEstado');
            $table->integer('tbdSeccion');
            $table->integer('idEscuela')->unsigned();
            $table->foreign('idEscuela')->references('idEscuela')->on('tbEscuela');
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
