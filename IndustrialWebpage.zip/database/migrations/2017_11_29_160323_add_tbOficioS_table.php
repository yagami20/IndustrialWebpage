<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbOficioSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbOficioS', function (Blueprint $table) {
            $table->increments('idOficioS');
            $table->string('tbOSDescripcion',250);
            $table->string('tbOSNumOficio',100);
            $table->string('tbOSExaminar',100);
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbOficioS');
    }
}
