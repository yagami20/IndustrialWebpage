<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTBSilaboTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tBSilabo', function (Blueprint $table) {
            $table->increments('idSilabo');
            $table->integer('idMateria')->unsigned();
            $table->foreign('idMateria')->references('idMateria')->on('tbMateria')->onDelete('cascade');
            $table->string('tbsiDescripcion',255);
            $table->string('tbsiDocumento',255);
            $table->string('tbsiFecha',255); 
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tBSilabo');
    }
}
