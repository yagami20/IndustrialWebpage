<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbHoraInicioTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbHoraInicio', function (Blueprint $table) {
            $table->increments('idHoraI');
            $table->integer('idDetalle')->unsigned();
            $table->foreign('idDetalle')->references('idDetalle')->on('tbDetalleAsistencia');
            $table->time('tbhiHora'); 
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbHoraInicio');
    }
}
