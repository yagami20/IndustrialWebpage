<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbEscuelaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbEscuela', function (Blueprint $table) {
            $table->increments('idEscuela');
            $table->string('tbeNombre',50);
            $table->string('tbeDireccion',50);
            $table->string('tbeTelefono',20);
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbEscuela');
    }
}
