<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTblSeguimientoPTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tblSeguimientoP', function (Blueprint $table) {
            $table->increments('idSeguimientoP');
            $table->date('tbsegFecha');
            $table->integer('idEscuela')->unsigned();
            $table->foreign('idEscuela')->references('idEscuela')->on('tbEscuela');
            $table->integer('idPlanificacion')->unsigned();
            $table->foreign('idPlanificacion')->references('idPlanificacion')->on('tBPlanificacion');
            $table->integer('idSilabo')->unsigned();
            $table->foreign('idSilabo')->references('idSilabo')->on('tBSilabo');
            $table->integer('idSeguimiento')->unsigned();
            $table->foreign('idSeguimiento')->references('idSeguimiento')->on('tBSeguimiento');
            $table->integer('idObservacion')->unsigned();
            $table->foreign('idObservacion')->references('idObservacion')->on('tBObservacion');
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tblSeguimientoP');
    }
}
