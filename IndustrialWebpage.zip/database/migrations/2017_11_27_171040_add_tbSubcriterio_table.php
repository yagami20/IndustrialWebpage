<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbSubcriterioTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbSubcriterio', function (Blueprint $table) {
            $table->increments('idSubcriterio');
            $table->integer('idCriterio')->unsigned();
            $table->foreign('idCriterio')->references('idCriterio')->on('tbCriterio')->onDelete('cascade');
            $table->string('tbscDescripcion',255);
            //$table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbSubcriterio');
    }
}
