<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbARchInternoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbARchInterno', function (Blueprint $table) {
            $table->increments('idArchIn');
            $table->string('tbarchExNombre',50);
            $table->integer('idArchEII')->unsigned();
            $table->foreign('idArchEII')->references('idArchEII')->on('tbArchivadorEII');
            $table->integer('idArchTipoI')->unsigned();
            $table->foreign('idArchTipoI')->references('idArchTipoI')->on('tbArchTipoI');
            $table->integer('idFechaIA')->unsigned();
            $table->foreign('idFechaIA')->references('idFechaIA')->on('tbFechaIA');
            $table->integer('idFechaSA')->unsigned();
            $table->foreign('idFechaSA')->references('idFechaSA')->on('tbFechaSA');
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbARchInterno');
    }
}
