<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbAutorizacionSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbAutorizacionS', function (Blueprint $table) {
            $table->increments('idAutorizacionS');
            $table->string('tbASDescripcion',250);
            $table->string('tbASNumOficio',100);
            $table->string('tbASExaminar',100);
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbAutorizacionS');
    }
}
