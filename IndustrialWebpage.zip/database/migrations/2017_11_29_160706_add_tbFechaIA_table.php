<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbFechaIATable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbFechaIA', function (Blueprint $table) {
            $table->increments('idFechaIA');
            $table->date('tbfiaFecha');
            $table->integer('idOficioI')->unsigned();
            $table->foreign('idOficioI')->references('idOficioI')->on('tbOficioI');
            $table->integer('idAutorizacionI')->unsigned();
            $table->foreign('idAutorizacionI')->references('idAutorizacionI')->on('tbAutorizacionI');
            

            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbFechaIA');
    }
}
