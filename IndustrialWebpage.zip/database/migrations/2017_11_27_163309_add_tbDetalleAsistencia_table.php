<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbDetalleAsistenciaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbDetalleAsistencia', function (Blueprint $table) {
            $table->increments('idDetalle');
            $table->string('tbaCedula',10);
            $table->string('tbaNombre',60); 
             $table->string('tbaApellido',60);
           // $table->integer('idAsis')->unsigned();
           // $table->foreign('idAsis')->references('idAsis')->on('tbAsistencia');
            $table->date('tbdFecha');  
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbDetalleAsistencia');
    }
}
