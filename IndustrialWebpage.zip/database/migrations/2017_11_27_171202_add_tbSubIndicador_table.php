<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbSubIndicadorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbSubIndicador', function (Blueprint $table) {
            $table->increments('idSubindicador');
            $table->integer('idIndicador')->unsigned();
            $table->foreign('idIndicador')->references('idIndicador')->on('tbIndicador')->onDelete('cascade');
            $table->string('tbsubiDescripcion',255);
            $table->string('tbsubiDocumento',255);
            $table->string('tbsubiTabla',255);
            $table->date('tbsubiFecha');
            //$table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbSubIndicador');
    }
}
