<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbOficioITable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbOficioI', function (Blueprint $table) {
            $table->increments('idOficioI');
            $table->string('tbOIDescripcion',250);
            $table->string('tbOINumOficio',255);
            $table->string('tbOIExaminar',255);
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbOficioI');
    }
}
