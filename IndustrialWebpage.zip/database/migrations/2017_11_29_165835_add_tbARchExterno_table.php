<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbARchExternoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbARchExterno', function (Blueprint $table) {
            $table->increments('idArchEx');
            $table->string('tbarchExNombre',50);
            $table->integer('idArchEII')->unsigned();
            $table->foreign('idArchEII')->references('idArchEII')->on('tbArchivadorEII');
            $table->integer('idArchTipoE')->unsigned();
            $table->foreign('idArchTipoE')->references('idArchTipoE')->on('tbArchTipoE');
            $table->integer('idFechaIA')->unsigned();
            $table->foreign('idFechaIA')->references('idFechaIA')->on('tbFechaIA');
            $table->integer('idFechaSA')->unsigned();
            $table->foreign('idFechaSA')->references('idFechaSA')->on('tbFechaSA');
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbARchExterno');
    }
}
