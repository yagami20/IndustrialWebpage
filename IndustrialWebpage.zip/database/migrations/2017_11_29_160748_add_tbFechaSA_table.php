<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbFechaSATable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbFechaSA', function (Blueprint $table) {
            $table->increments('idFechaSA');
            $table->date('tbfsaFecha');
            $table->integer('idOficioS')->unsigned();
            $table->foreign('idOficioS')->references('idOficioS')->on('tbOficioS');
            $table->integer('idAutorizacionS')->unsigned();
            $table->foreign('idAutorizacionS')->references('idAutorizacionS')->on('tbAutorizacionS');
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbFechaSA');
    }
}
