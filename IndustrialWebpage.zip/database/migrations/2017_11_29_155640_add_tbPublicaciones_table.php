<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbPublicacionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbPublicaciones', function (Blueprint $table) {
            $table->increments('idPublicacion');
            $table->string('tbpTitulo',250);
            $table->string('tbpDescripcion',2600);
            $table->string('tbpFoto',255)->nullable();
            $table->string('tbpExaminar',255)->nullable();
            $table->date('tbpFecha');
            $table->string('tbpEstado');
            $table->integer('idEscuela')->unsigned();
            $table->foreign('idEscuela')->references('idEscuela')->on('tbEscuela');
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbPublicaciones');
    }
}
