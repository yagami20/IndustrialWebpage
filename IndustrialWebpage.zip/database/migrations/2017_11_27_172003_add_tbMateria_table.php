<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbMateriaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbMateria', function (Blueprint $table) {
            $table->increments('idMateria');
            $table->string('tbmNombre',50);
            $table->string('tbmSemestre',30);
            $table->string('tbmISBN',20);
            $table->string('tbmParalelo',1);
            //$table->timestamps();
        });
    }

    
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbMateria');
    }
}
