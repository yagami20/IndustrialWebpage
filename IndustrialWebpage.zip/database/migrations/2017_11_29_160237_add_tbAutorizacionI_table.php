<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbAutorizacionITable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbAutorizacionI', function (Blueprint $table) {
            $table->increments('idAutorizacionI');
            $table->string('tbAIDescripcion',250);
            $table->string('tbAINumOficio',100);
            $table->string('tbAIExaminar',100);
            
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbAutorizacionI');
    }
}
