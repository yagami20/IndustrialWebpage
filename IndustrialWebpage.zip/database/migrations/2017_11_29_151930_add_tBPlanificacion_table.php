<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTBPlanificacionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tBPlanificacion', function (Blueprint $table) {
            $table->increments('idPlanificacion');
            $table->integer('idMateria')->unsigned();
            $table->foreign('idMateria')->references('idMateria')->on('tbMateria')->onDelete('cascade');
            $table->string('tbplDescripcion',255);
            $table->string('tbplDocumento',255);
            $table->string('tbplFecha',255); 
        });
    }

    
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tBPlanificacion');
    }
}
