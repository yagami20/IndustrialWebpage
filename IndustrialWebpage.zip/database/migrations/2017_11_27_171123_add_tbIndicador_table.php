<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTbIndicadorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbIndicador', function (Blueprint $table) {
            $table->increments('idIndicador');
            $table->integer('idSubcriterio')->unsigned();
            $table->foreign('idSubcriterio')->references('idSubcriterio')->on('tbSubcriterio')->onDelete('cascade');
            $table->string('tbinDescripcion',255);
            $table->string('tbinDocumento',255);
            //$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tbIndicador');
    }
}
