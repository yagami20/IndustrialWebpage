<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTBObservacionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tBObservacion', function (Blueprint $table) {
            $table->increments('idObservacion');
            //$table->integer('idSeguimientoP')->unsigned();
            //$table->foreign('idSeguimientoP')->references('idSeguimientoP')->on('tbSeguimientoP')->onDelete('cascade');
            $table->string('tboDetalle',250);
            $table->string('tboDocumento',255);
            $table->string('tboEstado',1);
            $table->string('tboFecha',255);
            //$table->timestamps(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('tBObservacion');
    }
}
