<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbSubcriterio extends Model
{
    //
     protected $table='tbSubcriterio';

    protected $primaryKey='idSubcriterio';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idCriterio',

        'tbscDescripcion',
        
        
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
