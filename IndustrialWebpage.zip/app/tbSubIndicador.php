<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbSubIndicador extends Model
{
    //
     protected $table='tbSubIndicador';

    protected $primaryKey='idSubindicador';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idIndicador',

        'tbsubiDescripcion',
        
        'tbsubiDocumento',

        'tbsubiTabla',

        'tbsubiFecha' 
        
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
