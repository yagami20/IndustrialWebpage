<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tblSeguimientoP extends Model
{
    //
    protected $table='tblSeguimientoP';

    protected $primaryKey='idSeguimientoP';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbsegFecha',
        
        'idEscuela',

        'idPlanificacion',

        'idSilabo',

        'idSeguimiento',
        
        'idObservacion'  
         
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
