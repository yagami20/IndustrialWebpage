<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbIndicador extends Model
{
    //
     protected $table='tbIndicador';

    protected $primaryKey='idIndicador';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idSubcriterio',

        'tbinDescripcion',
        
        'tbinDocumento' 
        

];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
