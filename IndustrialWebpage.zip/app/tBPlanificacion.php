<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tBPlanificacion extends Model
{
    //
     protected $table='tBPlanificacion';

    protected $primaryKey='idPlanificacion';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idMateria',
        
        'tbplDescripcion',

        'tbplDocumento',

        'tbplFecha'  
        
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
