<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbFechaIA extends Model
{
    //
    protected $table='tbFechaIA';

    protected $primaryKey='idFechaIA';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbfiaFecha', 
        
        'idOficioI',
        'idAutorizacionI'
          
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
