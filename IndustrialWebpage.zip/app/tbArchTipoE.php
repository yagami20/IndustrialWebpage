<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbArchTipoE extends Model
{
    //
    protected $table='tbArchTipoE';

    protected $primaryKey='idArchTipoE';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbarchENombre',
        
        'tbarchEEstado'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
