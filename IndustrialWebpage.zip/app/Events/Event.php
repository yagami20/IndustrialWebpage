<?php

namespace IndustrialWebpage\Events;

abstract class Event
{
    //
}
