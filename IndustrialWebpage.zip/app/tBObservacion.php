<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tBObservacion extends Model
{
    //
    protected $table='tBObservacion';

    protected $primaryKey='idObservacion';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tboDetalle',
        
        'tboDocumento',

        'tboEstado',

        'tboFecha'  
         
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
