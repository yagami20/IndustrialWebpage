<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbOficioI extends Model
{
    //
    protected $table='tbOficioI';

    protected $primaryKey='idOficioI';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbOIDescripcion',
        
        'tbOINumOficio',
        
        'tbOIExaminar' 
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
