<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbHoraInicio extends Model
{
    //
    protected $table='tbHoraInicio';

    protected $primaryKey='idHoraI';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        
        'idDetalle',

        'tbhiHora'

        
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
