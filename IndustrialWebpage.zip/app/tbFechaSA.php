<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbFechaSA extends Model
{
    //
    protected $table='tbFechaSA';

    protected $primaryKey='idFechaSA'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbfsaFecha',
          
        'idOficioS',
        'idAutorizacionS'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
