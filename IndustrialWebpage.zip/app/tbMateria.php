<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbMateria extends Model
{
    //
    protected $table='tbMateria';

    protected $primaryKey='idMateria';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbmNombre',
        
        'tbmSemestre',

        'tbmISBN',
        
        'tbmParalelo' 
        
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
