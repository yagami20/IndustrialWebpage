<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbARchExterno extends Model
{
    //
    protected $table='tbARchExterno';

    protected $primaryKey='idArchEx';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbarchExNombre',
        
        'idArchEII',
        'idArchTipoE',
        'idFechaIA',
        'idFechaSA'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
