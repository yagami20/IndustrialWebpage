<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class PublicacionFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
        
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'tbpTitulo' => 'required|max:255',
            'tbpDescripcion' => 'required|max:2600',

            'tbpFoto' => 'mimes:jpeg,bmp,png',

            'tbpExaminar' =>'mimes:pdf',

            'tbpFecha'=> 'required',

            'tbpEstado'=>'required',

            'idEscuela'=>'required'
        ];
    }
}
