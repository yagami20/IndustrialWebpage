<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class PlanifFromRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'idMateria' => 'required',

            'tbplDescripcion' => 'required|max:255',

            'tbplDocumento'=>'mimes:pdf',

            'tbplFecha'=>'required|max:10'

        ];
    }
}
