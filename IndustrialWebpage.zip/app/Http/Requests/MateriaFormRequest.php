<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class MateriaFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'tbmNombre'=> 'required|max:50',
            'tbmSemestre'=>'required|max:30',
            'tbmISBN'=>'required|max:20',
            'tbmParalelo'=>'required|max:1'

        ];
    }
}
