<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class IndicFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
             'idSubcriterio'=> 'required',
            'tbinDescripcion'=>'required|max:255',
            'tbinDocumento'=>'mimes:pdf'
            
        ];
    }
}
