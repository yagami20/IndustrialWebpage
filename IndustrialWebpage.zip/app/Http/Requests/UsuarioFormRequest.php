<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class UsuarioFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'tbuCedula' => 'required|max:10',

            'tbuNombres' => 'required|max:30',

            'tbuApellidos' =>'required|max:30',

            'email'=> 'required',

            'password'=>'required',

            'tbuCorreoInstitucional'=> 'required',

            'tbuSexo'=> 'required|max:1',

            'tbuTelefono'=> 'required|max:20',

            'tbuFechaNacimiento'=>'required|max:20',

            'tbuFoto'=>'mimes:jpeg,bmp,png',

            'tbuPais'=> 'required|max:30',

            'tbuCiudad'=> 'required|max:30',

            'tbuCurriculo'=> 'mimes:pdf',

            'tbuEstado'=> 'required|max:255',

            'tbtuId'=> 'required'
          

        ];
    }
}
