<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class CritFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'idEscuela'=> 'required',
            'tbcDescripcion'=>'required|max:40'
        ];
    }
}
