<?php

namespace IndustrialWebpage\Http\Requests;

use IndustrialWebpage\Http\Requests\Request;

class DescargaFromRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
       return true;
        
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'tbdTitulo' => 'required|max:255',
            'tbdDescripcion' => 'required|max:512',

            'tbdExaminar' =>'mimes:pdf',

            'tbdFecha'=> 'required',

            'tbdEstado'=>'required',

            'idEscuela'=>'required',
            
            'tbdSeccion'=>'required'
        ];
    }
}
