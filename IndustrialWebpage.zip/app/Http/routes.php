<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware'=>'web'],function(){
Route::get('/', 'WelcomeController@index');


Route::auth();
//cas
Route::get('/cas/protected', 'OtrosController@indexCas')->name('authCAS');
Route::get('/docente', 'OtrosController@indexDoc')->name('authDocent');
Route::get('/estudiante', 'OtrosController@indexEst')->name('authEstudiante');

Route::get('/login','LoginController@logueo')->name('logInC');
Route::get('/logout','LoginController@cierre')->name('logoutC');
//front end
Route::get('/{slug?}', 'HomeController@index'); 

//DocAcademicos
Route::resource('WebExterna/DocAcademicos','DocAcademicosController');  //ruta al controlador
//Noticias
Route::resource('WebExterna/noticias','noticias');  //ruta al controlador
Route::get('WebExterna/noticias/article/{idPublicacion}','noticias@article');//ruta mostrar noticia
//facultad
Route::resource('WebExterna/Facultad','FacultadController'); 
//...->
//contacto
Route::resource('WebExterna/contacto','ContactController'); 
//...->
//Autoridades
Route::resource('WebExterna/Autoridades','AutoridadesController');
//...->



});
//administrador documentos
//aqui inicio Route::group(['middleware'=>['auth','usuarioAdm']],function(){

//administrador documentos
Route::resource('archivador/tipousuario','TipoUsuarioController');  //ruta al controlador
Route::resource('archivador/usuario','UsuarioController');  //ruta al controlador
Route::resource('archivador/uAdministrativo','uAdministrativoController');  //ruta al controlador
Route::resource('archivador/uDocente','uDocenteController');  //ruta al controlador
Route::resource('archivador/uEstudiante','uEstudianteController');  //ruta al controlador

//administrador publicaciones
Route::resource('escuela/publicaciones','PublicacionesController');  //ruta al controlador
//administrador Documnetos Academicos
Route::resource('escuela/descargas','DescargaController');  //ruta al controlador

//descargador
Route::resource('escuela/descargador','DescController');  //ruta al controlador
Route::resource('escuela/descargadorP','DescControllerP');  //ruta al controlador Planif
Route::resource('escuela/descargadorS','DescControllerS');  //ruta al controlador silabo

//estudiante
Route::resource('estudiante/descargador','publicEst');
Route::resource('estudiante/descargadorS','silbEst');
Route::resource('estudiante/descargadorP','planifEst');
Route::resource('estudiante/SegPedFecha','segPedEst');
//docente
Route::resource('docente/descargador','publicDoc');
Route::resource('docente/descargadorS','silbDoc');
Route::resource('docente/descargadorP','planifDoc');
Route::resource('docente/seguimientos','seguimientDoc');
Route::resource('docente/seguimiento/planificacion','PlanifDocController');  //ruta al controlador planificacion
Route::resource('docente/seguimiento/silabo','SilbDocController');
Route::resource('docente/AsistenciaI','AsisIdocController');
Route::resource('docente/AsistenciaS','AsisSdocController');
//pdfAsistencia
Route::resource('escuela/AsisBusqueda/busquedaO','pdfRegistroAsisController');
Route::resource('escuela/AsisBusqueda/busquedaI','pdfRegistroIndController');
Route::resource('docente/AsisBusqueda/busquedaI','pdfRegistroAsisDindController');

//administrador Autoevaluacion
Route::resource('escuela/autoevaluacion/criterio','CriterioController');  //ruta al controlador
Route::resource('escuela/autoevaluacion/subcriterio','SubcritController');

Route::resource('escuela/autoevaluacion/indicador','IndicadorController'); //-->ubicacion programador
Route::resource('escuela/autoevaluacion/subindicador','SubindicController');

Route::get('escuela/autoevaluacion/pdf','OtrosController@actionImprimirPdf');//-->imprimir pdf



//administrador Seguimiento
Route::resource('escuela/seguimiento/materia','MateriaController');  //ruta al controlador materia
Route::resource('escuela/seguimiento/planificacion','PlanifController');  //ruta al controlador planificacion
Route::resource('escuela/seguimiento/silabo','SilaboController');  //ruta al controlador planificacion
Route::resource('escuela/seguimiento/seguimientos','SegController');  //ruta al controlador planificacion
Route::resource('escuela/seguimiento/observacion','ObservacionController');  //ruta al controlador planificacion

Route::resource('escuela/seguimiento/seguimientPed','SegPedController');  //ruta al controlador planificacion
// ruta comentario


Route::resource('escuela/seguimiento/SegPedDocente','SegPedDocController');  //ruta al controlador planificacion



//administrador Oficios y autorizaciones
Route::resource('escuela/archivador/oficiosI','OficioIController'); //oficios Ingreso
Route::resource('escuela/archivador/oficiosS','OficioSController'); //oficios Salida
Route::resource('escuela/archivador/autorI','AutorizIController'); //autorizacion Ingreso
Route::resource('escuela/archivador/autorS','AutorizSController'); //autorizacion salida
Route::resource('escuela/archivador/busquedaO','PdfBusqS');
Route::resource('escuela/archivador/busquedaA','PdfBusqAController');
Route::resource('escuela/autoevaluacion/BusqAut','PdfBusqAutController');


//aqui cierre });

//Docente documentos
//inicio docente
// Route::group(['middleware'=>['auth','usuarioDoc']],function(){

	//Route::resource('archivador/tipousuario','TipoUsuarioController');  //ruta al controlador
	

//rutas docentes
Route::resource('escuela/autoevaluacion/CritDoc','CritDocController');  //ruta al controlador
Route::get('escuela/autoevaluacion/CrSC/{idCriterio}', 'CrScController@edit')->name('autoevaluacion.show'); //ruta subcriterio Docente
Route::get('escuela/autoevaluacion/ScIn/{idSubcriterio}', 'ScInController@edit')->name('indicadores.show'); //ruta indicador Docente
Route::get('escuela/autoevaluacion/InSi/{idIndicador}', 'InSiController@edit')->name('subindicadores.show'); //ruta subindicador Docente

// ruta comentario

Route::resource('escuela/seguimiento/seguimientPed/obserSeguimiento','ComentSegController');
//docente seguimiento
Route::resource('escuela/seguimiento/SegPedDocente','SegPedDocController');  //ruta al controlador planificacion
//Asistencia
Route::resource('escuela/AsistenciaI','AsistenciaController');  //.->Asis ruta al controlador
Route::resource('escuela/AsistenciaS','AsistenciaControllerS');

// });// fin docente

//Estudiante documentos
// Route::group(['middleware'=>['auth','usuarioEst']],function(){
	//estudiante
Route::resource('escuela/seguimiento/SegPedFecha','VisualPSSController');

// });