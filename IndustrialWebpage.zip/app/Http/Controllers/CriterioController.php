<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbCriterio;
use Illuminate\Support\Facades\Redirect;
use phpCAS;

use IndustrialWebpage\Http\Requests\CritFormRequest;

use DB;

class CriterioController extends Controller
{
    //
	
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$criterio=DB::table('tbCriterio')->where('tbcDescripcion','LIKE','%'.$query.'%')
    		->orderby('idCriterio','asc')
    		->paginate(7);

    		return view ('escuela.autoevaluacion.criterio.index',["criterio"=>$criterio,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view ("escuela.autoevaluacion.criterio.create",["escuela"=>$escuela]);


    }

    
public function store (CritFormRequest $request)
    {

    	$criterio=new tbCriterio;

    	$criterio->idEscuela=$request->get('idEscuela');
		
		$criterio->tbcDescripcion=$request->get('tbcDescripcion');

    	$criterio->save();

    	return Redirect::to('escuela/autoevaluacion/criterio');


    }


    
public function show ($idCriterio)
    {

    	return view("escuela.autoevaluacion.criterio.show",["criterio"=>tbCriterio::findOrFail($idCriterio)]);

    }

    
public function edit($idCriterio)
    {

    	$criterio=tbCriterio::findOrFail($idCriterio);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.autoevaluacion.criterio.edit",["criterio"=>$criterio, "escuela"=>$escuela]);
        
    }



public function update(CritFormRequest $request, $idCriterio)
    {

    	$criterio=tbCriterio::findOrFail($idCriterio);

    	$criterio->idEscuela=$request->get('idEscuela');
		
		$criterio->tbcDescripcion=$request->get('tbcDescripcion');
    	
        $criterio->update();

    	return Redirect::to('escuela/autoevaluacion/criterio');
    	
    }

    


    
public function destroy($idCriterio)
    {
        $criterio=tbCriterio::findOrFail($idCriterio);        
        $query=$criterio->tbcDescripcion;

        return view("escuela.autoevaluacion.CrSC.show",["idCriterio"=>$query]);


    }

    //
}
