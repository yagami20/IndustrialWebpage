<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte llamado

use IndustrialWebpage\tbIndicador;
use IndustrialWebpage\tbSubIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;
use Fpdf;

class PdfBusqS extends Controller
{
    //
    //
	public function __construct()
    {
    	$this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }

	public function index (Request $request)
    {
			
    	if ($request)
    	   {
    	
			$fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

			$fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
    	    
            $cont=$request->get('cont');
            $fechaI=DB::table('tbFechaIA as tbI')
            ->whereBetween('tbI.tbfiaFecha',[$f1,$f2])
            ->get();

            $fechaS=DB::table('tbFechaSA as tbS')
            ->whereBetween('tbS.tbfsaFecha',[$f1,$f2])
            ->get();
            
            if ($cont=='1'){
                if($fechaI)
                {
                    $oficioI=DB::table('tbOficioI as tbI')
                        ->join('tbFechaIA as tbSC','tbI.idOficioI','=','tbSC.idOficioI')
                        ->select('tbI.tbOIDescripcion as desc','tbI.tbOINumOficio as nof','tbI.tbOIExaminar as doc','tbSC.tbfiaFecha as fecha')
                        ->whereBetween('tbSC.tbfiaFecha',[$f1,$f2])
                        ->where('tbI.idOficioI','!=',1)
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
            //fin cont
            }

            if ($fechaS) {
            # code...
                $oficioS=DB::table('tbOficioS as tbS')
                    ->join('tbFechaSA as tbSA','tbSA.idOficioS','=','tbS.idOficioS')
                    ->select('tbS.tbOSDescripcion as desc','tbS.tbOSNumOficio as nof','tbS.tbOSExaminar as doc','tbSA.tbfsaFecha as fecha')
                    ->whereBetween('tbSA.tbfsaFecha',[$f1,$f2])
                    ->where('tbS.idOficioS','!=',1)
                    ->get();
                // if($oficioS->idOficioS<>'1'){
                    
                    $this->bfecha($oficioS); 
                //fin id
                // }
            //fin cont
            } 
    return view ('escuela.archivador.busquedaO.index',["FechaInicio"=>$fecha1,
                                                                "FechaFin"=>$fecha2,
                                                                "cont"=>$cont]);
            }
			
    }


    //
    public function bfecha ($oficio)
    {

            Fpdf::AddPage();
            //Fpdf::imagejpeg('/imagenes/encabezado/EII.JPG',10,8,33);
            //Fpdf::Image('EII.png',20,20,-100);
            Fpdf::Image('imagenes/encabezado/EII.png',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Cell(40,6,'Descripcion',1,0,'C');
            Fpdf::Cell(40,6,'N. Oficio',1,0,'C');
            Fpdf::Cell(40,6,'Documento',1,0,'C');            
            Fpdf::Cell(40,6,'Fecha',1,1,'C');
            Fpdf::SetFont('Arial','',10);
            // while ($row=pg_fetch_assoc($oficio)) {
            //     # code...
            //     Fpdf::Cell(70,6,$row['desc'],1,0,'C');
            //     Fpdf::Cell(20,6,$row['nof'],1,0,'C');
            //     Fpdf::Cell(20,6,$row['doc'],1,0,'C');                
            //     Fpdf::Cell(70,6,$row['fecha'],1,1,'C');
            // }
            //
            $i=1;
            foreach($oficio as $row)
            {
            foreach($row as $col)
            {
                    
                Fpdf::Cell(40,6,$col,1,0,'C');
                // Fpdf::Cell(40,6,$col,1,0,'C');
                // Fpdf::Cell(40,6,$col,1,0,'C');                
                // Fpdf::Cell(70,6,$col,1,1,'C');

            }
            Fpdf::Ln();
            $i++;
            }
            //
            Fpdf::Output();
            exit;

		

        
           
    }
    
}
