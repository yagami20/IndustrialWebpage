<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte llamado
use IndustrialWebpage\tbIndicador;
use IndustrialWebpage\tbSubIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;
use Fpdf;

class PdfBusqAutController extends Controller
{
    //
    public function __construct()
    {
    	$this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }
    public function index (Request $request)
    {
            
        if ($request)
           {
        
            $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            
            $cont=$request->get('cont');
           
            
            if ($cont=='1'){
                
                    $autI=DB::table('tbSubIndicador as tbSI')
            ->join('tbIndicador as tbI', 'tbSI.idIndicador','=','tbI.idIndicador')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbSC.idCriterio','=','tbC.idCriterio')
            ->select('tbC.tbcDescripcion as DesC','tbSC.tbscDescripcion as DesSC','tbI.tbinDescripcion as DesIn','tbSI.tbsubiDescripcion as DesSI', 'tbSI.tbsubiFecha'
                 
                 )
                        ->whereBetween('tbSI.tbsubiFecha',[$f1,$f2])
                        ->get();                    
                        $this->bfecha($autI);
                
            //fin cont
            }

            
    return view ('escuela.autoevaluacion.BusqAut.index',["FechaInicio"=>$fecha1,
                                                                "FechaFin"=>$fecha2,
                                                                "cont"=>$cont]);
            }
            
    }


    //
    public function bfecha ($autorizacion)
    {
            Fpdf::AddPage();            
            Fpdf::Image('imagenes/encabezado/EII.png',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Cell(40,6,'Criterio',1,0,'C');
            Fpdf::Cell(40,6,'Subcriterio',1,0,'C');
            Fpdf::Cell(40,6,'Indicador',1,0,'C');
            Fpdf::Cell(40,6,'SubIndicador',1,0,'C');            
            Fpdf::Cell(40,6,'Fecha',1,1,'C');
            Fpdf::SetFont('Arial','',10);            
            $i=1;
            foreach($autorizacion as $row)
            {
            foreach($row as $col)
            {                    
                Fpdf::Cell(40,6,$col,1,0,'C');             
            }
            Fpdf::Ln();
            $i++;
            }            
            Fpdf::Output();
            exit;
        }
}
