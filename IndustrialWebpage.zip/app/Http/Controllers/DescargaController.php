<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbDescarga;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;
use Illuminate\Http\Response;
//use Symfony\Component\HttpFoundation\Response;



use IndustrialWebpage\Http\Requests\DescargaFromRequest;

use DB;
class DescargaController extends Controller
{
    //

    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$descarga=DB::table('tbDescargas')->where('tbdTitulo','LIKE','%'.$query.'%')
    		->where ('tbdEstado','=','1')
    		->orderby('idDescarga','desc')
    		->paginate(3);

    		return view ('escuela.descargas.index',["descarga"=>$descarga,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view ("escuela.descargas.create",["escuela"=>$escuela]);


    }

    
public function store (DescargaFromRequest $request)
    {

    	$descarga=new tbDescarga;
        $descarga->tbdTitulo=$request->get('tbdTitulo');

        $descarga->tbdDescripcion=$request->get('tbdDescripcion');

    	
    	

    	/*seccion pdf */
    	//$publicacion->tbpExaminar=$request->get('tbpExaminar');

    	if (Input::hasFile('tbdExaminar')){
         $file=Input::file('tbdExaminar');
         $file->move(public_path().'/documentos/curriculo/',$file->getClientOriginalName());
         $descarga->tbdExaminar=$file->getClientOriginalName();
        }

    	$descarga->tbdFecha=$request->get('tbdFecha');

        $descarga->tbdEstado=$request->get('tbdEstado');
        
        $descarga->idEscuela=$request->get('idEscuela');
        $descarga->tbdSeccion=$request->get('tbdSeccion');

    	
    	$descarga->save();

    	return Redirect::to('escuela/descargas');


    }


    
public function show ($idDescarga)
    {

    	return view("escuela.descargas.show",["descarga"=>tbDescargas::findOrFail($idDescarga)]);

    }

    
public function edit($idDescarga)
    {

    	$descarga=tbDescarga::findOrFail($idDescarga);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.descargas.edit",["descarga"=>$descarga, "escuela"=>$escuela]);
        
    }

public function archivo($idDescarga)
    {

        $descarga=tbDescargas::findOrFail($idDescarga);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.descargas.descargaU",["descarga"=>$descarga, "escuela"=>$escuela]);
         

    }


    
public function update(DescargaFromRequest $request, $idDescarga)
    {

    	$descarga=tbDescarga::findOrFail($idDescarga);

       

        $descarga->tbdTitulo=$request->get('tbdTitulo');
        $descarga->tbdDescripcion=$request->get('tbdDescripcion');

       

        /*seccion pdf */
        //$publicacion->tbpExaminar=$request->get('tbpExaminar');

        if (Input::hasFile('tbdExaminar')){
         $file=Input::file('tbdExaminar');
         $file->move(public_path().'/documentos/curriculo/',$file->getClientOriginalName());
         $descarga->tbdExaminar=$file->getClientOriginalName();
        }

        $descarga->tbdFecha=$request->get('tbdFecha');

        $descarga->tbdEstado=$request->get('tbdEstado');
        
        $descarga->idEscuela=$request->get('idEscuela');
         $descarga->tbdSeccion=$request->get('tbdSeccion');

    	
        $descarga->update();

    	return Redirect::to('escuela/descargas');
    	
    }

    

public function destroy($idDescarga)
    {

    	$descarga=tbDescarga::findOrFail($idDescarga);

    	$descarga->tbdEstado='0';

    	$descarga->update();

    	return Redirect::to('escuela/descargas'); 


    }
    
}
