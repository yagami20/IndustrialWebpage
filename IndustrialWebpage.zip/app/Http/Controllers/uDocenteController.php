<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;

//parte de llamado
use IndustrialWebpage\tbUsuario;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;

use IndustrialWebpage\Http\Requests\UsuarioFormRequest;

use DB;

class uDocenteController extends Controller
{
     //
    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $uadm=DB::table('users')->where('tbuNombres','LIKE','%'.$query.'%')
            ->where ('tbtuId','=','3')
            ->orderby('tbuCedula','desc')
            ->paginate(7);

            return view ('archivador.uDocente.index',["uDocente"=>$uadm,"searchText"=>$query]);

        }



    }


    
public function create()
    {

        $tipousuario=DB::table('tbTipoUsuario')->where('tbtuEstado','=','1')->get();
        return view ("archivador.uDocente.create",["tipousuario"=>$tipousuario]);


    }

    
public function store (UsuarioFormRequest $request)
    {

        $uadm=new User;

        $uadm->tbuCedula=$request->get('tbuCedula');

        $uadm->tbuNombres=$request->get('tbuNombres');

        $uadm->tbuApellidos=$request->get('tbuApellidos');

        $uadm->email=$request->get('email');

        $uadm->password=$request->get('password');
        
        //$uadm->remember_token=$request->get('remember_token');

        $uadm->tbuCorreoInstitucional=$request->get('tbuCorreoInstitucional');

        $uadm->tbuSexo=$request->get('tbuSexo');

        $uadm->tbuTelefono=$request->get('tbuTelefono');

        $uadm->tbuFechaNacimiento=$request->get('tbuFechaNacimiento');

        if (Input::hasFile('tbuFoto')){
         $file=Input::file('tbuFoto');
         $file->move(public_path().'/imagenes/usuarios/',$file->getClientOriginalName());
         $uadm->tbuFoto=$file->getClientOriginalName();
        }
        
        $uadm->tbuPais=$request->get('tbuPais');

        $uadm->tbuCiudad=$request->get('tbuCiudad');

        //$uadm->tbuCurriculo=$request->get('tbuCurriculo');
        if (Input::hasFile('tbuCurriculo')){
         $file1=Input::file('tbuCurriculo');
         $file1->move(public_path().'/documentos/CurriculoUs/',$file1->getClientOriginalName());
         $uadm->tbuCurriculo=$file1->getClientOriginalName();
        }
        
        $uadm->tbuEstado=$request->get('tbuEstado');

        $uadm->tbtuId=$request->get('tbtuId');

        $uadm->save();

        return Redirect::to('archivador/uDocente');


    }


    
public function show ($id)
    {

        return view("archivador.uDocente.show",["uDocente"=>User::findOrFail($id)]);

    }

    
public function edit($tbuIdu)
    {

        $uadm=User::findOrFail($id);
        $tipousuario=DB::table('tbTipoUsuario')->where('tbtuEstado','=','1')->get();
        return view("archivador.uDocente.edit",["uDocente"=>$uadm, "tipousuario"=>$tipousuario]);
        
    }

    
public function update(UsuarioFormRequest $request, $id)
    {

        $uadm=User::findOrFail($id);

        $uadm->tbuCedula=$request->get('tbuCedula');

        $uadm->tbuNombres=$request->get('tbuNombres');

        $uadm->tbuApellidos=$request->get('tbuApellidos');

        $uadm->email=$request->get('email');

        $uadm->password=$request->get('password');
        
        //$uadm->remember_token=$request->get('remember_token');

        $uadm->tbuCorreoInstitucional=$request->get('tbuCorreoInstitucional');

        $uadm->tbuSexo=$request->get('tbuSexo');

        $uadm->tbuTelefono=$request->get('tbuTelefono');

        $uadm->tbuFechaNacimiento=$request->get('tbuFechaNacimiento');

        if (Input::hasFile('tbuFoto')){
         $file=Input::file('tbuFoto');
         $file->move(public_path().'/imagenes/usuarios/',$file->getClientOriginalName());
         $uadm->tbuFoto=$file->getClientOriginalName();
        }

        $uadm->tbuPais=$request->get('tbuPais');

        $uadm->tbuCiudad=$request->get('tbuCiudad');

        //$uadm->tbuCurriculo=$request->get('tbuCurriculo');
        if (Input::hasFile('tbuCurriculo')){
         $file1=Input::file('tbuCurriculo');
         $file1->move(public_path().'/documentos/CurriculoUs/',$file1->getClientOriginalName());
         $uadm->tbuCurriculo=$file1->getClientOriginalName();
        }

        $uadm->tbuEstado=$request->get('tbuEstado');

        $uadm->tbtuId=$request->get('tbtuId');

        
        $uadm->update();

        return Redirect::to('archivador/uDocente');
        
    }

    

public function destroy($id)
    {

        $uadm=User::findOrFail($id);

        $uadm->tbuEstado='0';

        $uadm->update();

        return Redirect::to('archivador/uDocente'); 


    }

}
