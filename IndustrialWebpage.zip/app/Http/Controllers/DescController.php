<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
 //parte de llamado
use IndustrialWebpage\tbPublicaciones;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;
use Illuminate\Http\Response;
//use Symfony\Component\HttpFoundation\Response;



use IndustrialWebpage\Http\Requests\PublicacionFormRequest;

use DB; 


class DescController extends Controller
{
    //
   
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$publicacion=DB::table('tbPublicaciones')->where('tbpDescripcion','LIKE','%'.$query.'%')
    		->where ('tbpEstado','=','1')
    		->orderby('idPublicacion','desc')
    		->paginate(7);

    		return view ('escuela.descargador.index',["publicacion"=>$publicacion,"searchText"=>$query]);

    	}



    }


    
public function create()
    {


    }

    
public function store (PublicacionFormRequest $request)
    {

    }


    
public function show ($idPublicacion)
    {

    	return view("escuela.publicaciones.show",["publicacion"=>tbPublicaciones::findOrFail($idPublicacion)]);

    }

    
public function edit($idPublicacion)
    {

    	
    }

public function archivo($idPublicacion)
    {

        $publicacion=tbPublicaciones::findOrFail($idPublicacion);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.publicaciones.publicacionU",["publicacion"=>$publicacion, "escuela"=>$escuela]);
         

    }


    
public function update(PublicacionFormRequest $request, $idPublicacion)
    {

    }

    

public function destroy($idPublicacion)
    {

    	
    }

}
