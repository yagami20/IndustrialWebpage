<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;

//parte de llamado
use IndustrialWebpage\tbPublicaciones;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;
//use Symfony\Component\HttpFoundation\Response;
use phpCAS;


use IndustrialWebpage\Http\Requests\PublicacionFormRequest;

use DB;


class PublicacionesController extends Controller
{
    //

    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$publicacion=DB::table('tbPublicaciones')
            // ->where('tbpTitulo','LIKE','%'.$query.'%')
            ->where('tbpDescripcion','LIKE','%'.$query.'%')
    		->where ('tbpEstado','=','1')
    		->orderby('idPublicacion','desc')
    		->paginate(7);

    		return view ('escuela.publicaciones.index',["publicacion"=>$publicacion,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view ("escuela.publicaciones.create",["escuela"=>$escuela]);


    }

    
public function store (PublicacionFormRequest $request)
    {

    	$publicacion=new tbPublicaciones;
        $publicacion->tbpTitulo=$request->get('tbpTitulo');

        $publicacion->tbpDescripcion=$request->get('tbpDescripcion');

    	
    	/*seccion foto */
    	//$publicacion->tbpFoto=$request->get('tbpFoto');

    	if (Input::hasFile('tbpFoto')){
         $file1=Input::file('tbpFoto');
         $file1->move(public_path().'/imagenes/publicaciones/',$file1->getClientOriginalName());
         $publicacion->tbpFoto=$file1->getClientOriginalName();
        }

    	/*seccion pdf */
    	//$publicacion->tbpExaminar=$request->get('tbpExaminar');

    	if (Input::hasFile('tbpExaminar')){
         $file=Input::file('tbpExaminar');
         $file->move(public_path().'/documentos/curriculo/',$file->getClientOriginalName());
         $publicacion->tbpExaminar=$file->getClientOriginalName();
        }

    	$publicacion->tbpFecha=$request->get('tbpFecha');

        $publicacion->tbpEstado=$request->get('tbpEstado');
        
        $publicacion->idEscuela=$request->get('idEscuela');

    	
    	$publicacion->save();

    	return Redirect::to('escuela/publicaciones');


    }


    
public function show ($idPublicacion)
    {

    	return view("escuela.publicaciones.show",["publicacion"=>tbPublicaciones::findOrFail($idPublicacion)]);

    }

    
public function edit($idPublicacion)
    {

    	$publicacion=tbPublicaciones::findOrFail($idPublicacion);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.publicaciones.edit",["publicacion"=>$publicacion, "escuela"=>$escuela]);
        
    }

public function archivo($idPublicacion)
    {

        $publicacion=tbPublicaciones::findOrFail($idPublicacion);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.publicaciones.publicacionU",["publicacion"=>$publicacion, "escuela"=>$escuela]);
         

    }


    
public function update(PublicacionFormRequest $request, $idPublicacion)
    {

    	$publicacion=tbPublicaciones::findOrFail($idPublicacion);

       

        $publicacion->tbpDescripcion=$request->get('tbpTitulo');
        $publicacion->tbpDescripcion=$request->get('tbpDescripcion');

        
        /*seccion foto */
        //$publicacion->tbpFoto=$request->get('tbpFoto');

        if (Input::hasFile('tbpFoto')){
         $file1=Input::file('tbpFoto');
         $file1->move(public_path().'/imagenes/publicaciones/',$file1->getClientOriginalName());
         $publicacion->tbpFoto=$file1->getClientOriginalName();
        }

        /*seccion pdf */
        //$publicacion->tbpExaminar=$request->get('tbpExaminar');

        if (Input::hasFile('tbpExaminar')){
         $file=Input::file('tbpExaminar');
         $file->move(public_path().'/documentos/curriculo/',$file->getClientOriginalName());
         $publicacion->tbpExaminar=$file->getClientOriginalName();
        }

        $publicacion->tbpFecha=$request->get('tbpFecha');

        $publicacion->tbpEstado=$request->get('tbpEstado');
        
        $publicacion->idEscuela=$request->get('idEscuela');

    	
        $publicacion->update();

    	return Redirect::to('escuela/publicaciones');
    	
    }

    

public function destroy($idPublicacion)
    {

    	$publicacion=tbPublicaciones::findOrFail($idPublicacion);

    	$publicacion->tbpEstado='0';

    	$publicacion->update();

    	return Redirect::to('escuela/publicaciones'); 


    }
    
}
