<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;

//parte de llamado
use IndustrialWebpage\tbIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\IndicFormRequest;
use phpCAS;
use DB;


class ScInController extends Controller
{
    //
    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }
    public function edit($idSubcriterio)
    {

        $indicador=DB::table('tbIndicador as tbI')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbC.idCriterio','=','tbSC.idCriterio')
            ->select('tbI.idIndicador','tbI.idSubcriterio','tbI.tbinDescripcion','tbI.tbinDocumento','tbSC.tbscDescripcion as DesSC', 'tbC.tbcDescripcion as DesC')

            ->where('tbI.idSubcriterio','=',$idSubcriterio)
            ->orderby('idIndicador','asc')
    		->paginate(7); 

        return view ('escuela.autoevaluacion.ScIn.edit',["indicador"=>$indicador]);
    }
}
