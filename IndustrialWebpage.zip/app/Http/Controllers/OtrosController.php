<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte llamado

use IndustrialWebpage\tbIndicador;
use IndustrialWebpage\tbSubIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;
use Fpdf;



class OtrosController extends Controller
{
    //
    public function __construct()
    {
        
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
        
        
    }
    public function indexCas()
    {
        return view('cas.protected.index');
    }
    public function indexDoc()
    {
        return view('docente.index');
    }
    public function indexEst()
    {
        return view('estudiante.index');
    }
    //

    public function actionImprimirPdf()
    {

        //$indicador=DB::table('tbIndicador')->get();
        //$subindicador=tbSubIndicador::whereRaw('idIndicador=?', [$indicador[0]->idIndicador])->get();


        
        $indicador=DB::table('tbSubIndicador')->get();
        $subindicador=DB::table('tbSubIndicador as tbSI')
            ->join('tbIndicador as tbI', 'tbSI.idIndicador','=','tbI.idIndicador')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbSC.idCriterio','=','tbC.idCriterio')
            ->select('tbSI.tbsubiDescripcion as DesSI',
                'tbSI.tbsubiDocumento', 'tbSI.tbsubiTabla', 'tbSI.tbsubiFecha',
                'tbI.tbinDescripcion as DesIn', 'tbSC.tbscDescripcion as DesSC',
                 'tbC.tbcDescripcion as DesC')
            ->orderby('idSubindicador','asc')
            ->get();

           

    	Fpdf::AddPage();
        Fpdf::SetFont('Arial','B',10);
        
        $i=1;

       
       foreach($subindicador as $row)
        {
            foreach($row as $col)
            {
                    
                Fpdf::Cell(100,10,$col, 1, 1, 'LR');

            }
            Fpdf::Ln();
            $i++;
        }

        /*Fpdf::Cell(40,10,'Hello World!', 0, 1, 'C');
        Fpdf::Cell(40,10,'by Yagami20!', 0, 1, 'C');
        */

        Fpdf::Output();
        exit;

        
    }
}
