<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbSubcriterio;
use Illuminate\Support\Facades\Redirect;


use IndustrialWebpage\Http\Requests\SubcritFormRequest;
use phpCAS;
use DB;


class SubcritController extends Controller
{
    //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		/* $subcriterio=DB::table('tbSubcriterio')->where('tbscDescripcion','LIKE','%'.$query.'%')
    		->orderby('idSubcriterio','asc')
    		->paginate(7); */
            $subcriterio=DB::table('tbSubcriterio as tbU')
            ->join('tbCriterio as Tbt','Tbt.idCriterio','=','tbU.idCriterio')

            ->select('tbU.idSubcriterio','tbU.idCriterio','tbU.tbscDescripcion','Tbt.tbcDescripcion as Descrip')
            
            ->where('tbU.tbscDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbcDescripcion','LIKE','%'.$query.'%')
        
            
            ->orderBy('idSubcriterio','asc')

            ->paginate(6);

    		return view ('escuela.autoevaluacion.subcriterio.index',["subcriterio"=>$subcriterio,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$criterio=DB::table('tbCriterio')->get();
        return view ("escuela.autoevaluacion.subcriterio.create",["criterio"=>$criterio]);


    }

    
public function store (SubcritFormRequest $request)
    {

    	$subcriterio=new tbSubcriterio;

    	$subcriterio->idCriterio=$request->get('idCriterio');
		
		$subcriterio->tbscDescripcion=$request->get('tbscDescripcion');

    	$subcriterio->save();

    	return Redirect::to('escuela/autoevaluacion/subcriterio');


    }


    
public function show ($idSubcriterio)
    {

    	return view("escuela.autoevaluacion.subcriterio.show",["subcriterio"=>tbSubcriterio::findOrFail($idSubcriterio)]);

    }

    
public function edit($idSubcriterio)
    {

    	$subcriterio=tbSubcriterio::findOrFail($idSubcriterio);
        $criterio=DB::table('tbCriterio')->get();
        return view("escuela.autoevaluacion.subcriterio.edit",["subcriterio"=>$subcriterio, "criterio"=>$criterio]);
        
    }

public function update(SubcritFormRequest $request, $idSubcriterio)
    {

    	$subcriterio=tbSubcriterio::findOrFail($idSubcriterio);

    	$subcriterio->idCriterio=$request->get('idCriterio');
		
		$subcriterio->tbscDescripcion=$request->get('tbscDescripcion');
    	
        $subcriterio->update();

    	return Redirect::to('escuela/autoevaluacion/subcriterio');
    	
    }

    


}
