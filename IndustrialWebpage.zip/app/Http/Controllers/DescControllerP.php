<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
use IndustrialWebpage\tBPlanificacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;
use Illuminate\Http\Response;
//use Symfony\Component\HttpFoundation\Response;



use IndustrialWebpage\Http\Requests\PlanifFromRequest;

use DB;


class DescControllerP extends Controller
{
    //
     //
    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$planificacion=DB::table('tBPlanificacion as tbU')
            ->join('tbMateria as Tbt','Tbt.idMateria','=','tbU.idMateria')

            ->select('tbU.idPlanificacion','tbU.idMateria','tbU.tbplDescripcion','tbU.tbplDocumento','tbU.tbplFecha','Tbt.tbmNombre as Materia', 'Tbt.tbmSemestre as Semestre', 'Tbt.tbmParalelo as Paralelo')
            
            ->where('tbU.tbplDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbmNombre','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbplFecha','LIKE','%'.$query.'%')
    		
    		->orderby('idPlanificacion','desc')
    		->paginate(7);

    		return view ('escuela.descargadorP.index',["planificacion"=>$planificacion,"searchText"=>$query]);

    	}



    }


    
public function create()
    {


    }

    
public function store (PublicacionFormRequest $request)
    {

    }


    
public function show ($idPlanificacion)
    {

    	return view("escuela.descargadorP.show",["planificacion"=>tBPlanificacion::findOrFail($idPlanificacion)]);

    }

    
public function edit($idPlanificacion)
    {

    	
    }

public function archivo($idPlanificacion)
    {

        $planificacion=tBPlanificacion::findOrFail($idPlanificacion);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.descargadorP.publicacionU",["planificacion"=>$planificacion, "escuela"=>$escuela]);
         

    }


    
public function update(PublicacionFormRequest $request, $idPlanificacion)
    {

    }

    

public function destroy($idPlanificacion)
    {

    	
    }
}
