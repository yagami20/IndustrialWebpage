<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbMateria;
use Illuminate\Support\Facades\Redirect;


use IndustrialWebpage\Http\Requests\MateriaFormRequest;
use phpCAS;
use DB;

class MateriaController extends Controller
{
    //
    //
      
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$materia=DB::table('tbMateria')->where('tbmNombre','LIKE','%'.$query.'%')
    		
    		->orwhere('tbmSemestre','LIKE','%'.$query.'%')
    		->orwhere('tbmISBN','LIKE','%'.$query.'%')
    		->orwhere('tbmParalelo','LIKE','%'.$query.'%')

    		->orderby('idMateria','desc')
    		->paginate(7);

    		return view ('escuela.seguimiento.materia.index',["materia"=>$materia,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	return view ("escuela.seguimiento.materia.create");
    }

    
public function store (MateriaFormRequest $request)
    {
    	$materia=new tbMateria; //referencia modelo
        $materia->tbmNombre=$request->get('tbmNombre');
    	$materia->tbmSemestre=$request->get('tbmSemestre');
    	$materia->tbmISBN=$request->get('tbmISBN');
    	$materia->tbmParalelo=$request->get('tbmParalelo');

    	$materia->save();

    	return Redirect::to('escuela/seguimiento/materia');
    }


    
public function show ($idMateria)
    {

    	return view("escuela.seguimiento.materia.show",["materia"=>tbMateria::findOrFail($idMateria)]);

    }

    
public function edit($idMateria)
    {

    	return view("escuela.seguimiento.materia.edit",["materia"=>tbMateria::findOrFail($idMateria)]);
    }




    
public function update(MateriaFormRequest $request, $idMateria)
    {
        $materia=tbMateria::findOrFail($idMateria);
        $materia->tbmNombre=$request->get('tbmNombre');
        $materia->tbmSemestre=$request->get('tbmSemestre');
        $materia->tbmISBN=$request->get('tbmISBN');
        $materia->tbmParalelo=$request->get('tbmParalelo');

        $materia->update();

        return Redirect::to('escuela/seguimiento/materia');
    }

    

public function destroy($idMateria)
    {

    	
    }

}
