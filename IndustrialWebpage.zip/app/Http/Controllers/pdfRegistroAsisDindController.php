<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte llamado

use IndustrialWebpage\tbAsistencia;
use IndustrialWebpage\tbDetalleAsistencia;
use IndustrialWebpage\tbHoraInicio;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;
use Fpdf;

class pdfRegistroAsisDindController extends Controller
{
    //general
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }

    public function index (Request $request)
    {
            
        if ($request)
           {
        
            $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            
            $cont=$request->get('cont');
            $fechaI=DB::table('tbDetalleAsistencia as tbI')
            ->whereBetween('tbI.tbdFecha',[$f1,$f2])
            ->get();

            $fechaS=DB::table('tbDetalleAsistencia as tbS')
            ->whereBetween('tbS.tbdFecha',[$f1,$f2])
            ->get();
            
            if ($cont=='1'){
                if($fechaI)
                {
                    $oficioI=DB::table('tbAsistencia as tbA')
                        ->join('tbDetalleAsistencia as tbDA','tbA.idAsis','=','tbDA.idAsis')
                        ->join('tbHoraInicio as tbHI','tbDA.idDetalle','=','tbHI.idDetalle')
                        ->select('tbDA.tbdFecha as fecha','tbDA.tbaCedula as cedula','tbDA.tbaNombre as Nombre','tbDA.tbaApellido as Apellido','tbHI.tbhiHora as hora')
                        ->whereBetween('tbDA.tbdFecha',[$f1,$f2])
                        ->where('tbDA.tbaCedula',phpCAS::getAttribute('cedula'))
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
            //fin cont
            }

            if ($fechaS) {
            # code...
                $oficioS=DB::table('tbAsistencia as tbA')
                        ->join('tbDetalleAsistencia as tbDA','tbA.idAsis','=','tbDA.idAsis')
                        ->join('tbHoraFin as tbHI','tbDA.idDetalle','=','tbHI.idDetalle')
                        ->select('tbDA.tbdFecha as fecha','tbDA.tbaCedula as cedula','tbDA.tbaNombre as Nombre','tbDA.tbaApellido as Apellido','tbHI.tbhfHora as hora')
                        ->whereBetween('tbDA.tbdFecha',[$f1,$f2])
                        ->where('tbDA.tbaCedula',phpCAS::getAttribute('cedula'))
                        ->get();
                // if($oficioS->idOficioS<>'1'){
                    
                    $this->bfecha($oficioS); 
                //fin id
                // }
            //fin cont
            } 
    return view ('docente.AsisBusqueda.busquedaI.index',["FechaInicio"=>$fecha1,
                                                                "FechaFin"=>$fecha2,
                                                                "cont"=>$cont]);
            }
            
    }


    //
    public function bfecha ($oficio)
    {

            Fpdf::AddPage();
            //Fpdf::imagejpeg('/imagenes/encabezado/EII.JPG',10,8,33);
            //Fpdf::Image('EII.png',20,20,-100);
            Fpdf::Image('imagenes/encabezado/EII.png',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Cell(40,6,'Fecha',1,0,'C');
            Fpdf::Cell(40,6,'Cedula',1,0,'C');
            Fpdf::Cell(40,6,'Nombre',1,0,'C');
            Fpdf::Cell(40,6,'Apellido',1,0,'C');            
            Fpdf::Cell(40,6,'Hora',1,1,'C');
            Fpdf::SetFont('Arial','',10);
            // while ($row=pg_fetch_assoc($oficio)) {
            //     # code...
            //     Fpdf::Cell(70,6,$row['desc'],1,0,'C');
            //     Fpdf::Cell(20,6,$row['nof'],1,0,'C');
            //     Fpdf::Cell(20,6,$row['doc'],1,0,'C');                
            //     Fpdf::Cell(70,6,$row['fecha'],1,1,'C');
            // }
            //
            $i=1;
            foreach($oficio as $row)
            {
            foreach($row as $col)
            {
                    
                Fpdf::Cell(40,6,$col,1,0,'C');
                // Fpdf::Cell(40,6,$col,1,0,'C');
                // Fpdf::Cell(40,6,$col,1,0,'C');                
                // Fpdf::Cell(70,6,$col,1,1,'C');

            }
            Fpdf::Ln();
            $i++;
            }
            //
            Fpdf::Output();
            exit;

        

        
           
    }
}
