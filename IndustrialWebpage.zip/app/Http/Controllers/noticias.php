<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbPublicaciones;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;
use IndustrialWebpage\Http\Requests\PublicacionFormRequest;

use DB;


class noticias extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index (Request $request)
    {

        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $publicacion=DB::table('tbPublicaciones')->where('tbpDescripcion','LIKE','%'.$query.'%')
            ->where ('tbpEstado','=','1')
            ->orderby('idPublicacion','desc')
            ->paginate(3);

            return view ('WebExterna.noticias.index',["publicacion"=>$publicacion,"searchText"=>$query]); 

        }



    }
    public function show ($idPublicacion)
    {

        return view("WebExterna.noticias.show",["publicacion"=>tbPublicaciones::findOrFail($idPublicacion)]);

    }
    public function destroy($idPublicacion)
    {

        $publicacion=tbPublicaciones::findOrFail($idPublicacion);

        $publicacion->tbpEstado='0';

        $publicacion->update();

        return Redirect::to('WebExterna/noticias'); 


    }
    public function article($idPublicacion)
    {
        $publicacion=tbPublicaciones::findOrFail($idPublicacion);

        return view("WebExterna.noticias.article",["publicacion"=>$publicacion,"idP"=>$idPublicacion]);
        // ->with('publicacion','$publicacion'); 



    }
}
