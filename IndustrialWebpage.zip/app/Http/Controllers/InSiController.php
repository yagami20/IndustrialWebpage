<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//

use IndustrialWebpage\tbSubIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;

class InSiController extends Controller
{
    //
    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }
    public function edit($idIndicador)
    {

        $subindicador=DB::table('tbSubIndicador as tbSI')
            ->join('tbIndicador as tbI', 'tbSI.idIndicador','=','tbI.idIndicador')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbSC.idCriterio','=','tbC.idCriterio')
            ->select('tbSI.idSubindicador', 'tbSI.idIndicador', 'tbSI.tbsubiDescripcion as DesSI',
                'tbSI.tbsubiDocumento', 'tbSI.tbsubiTabla', 'tbSI.tbsubiFecha',
                'tbI.tbinDescripcion as DesIn', 'tbSC.tbscDescripcion as DesSC',
                 'tbC.tbcDescripcion as DesC')

            ->where('tbSI.idIndicador','=',$idIndicador)
            ->orderby('idSubindicador','asc')
    		->paginate(7);



        return view ('escuela.autoevaluacion.InSi.edit',["subindicador"=>$subindicador]);
    }

}
