<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tBSeguimiento;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response; 

use IndustrialWebpage\Http\Requests\SegFormRequest;
use phpCAS;
use DB; 

class seguimientDoc extends Controller
{
    //
     public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		
            $seguimiento=DB::table('tBSeguimiento as tbU')
            ->join('tbMateria as Tbt','Tbt.idMateria','=','tbU.idMateria')

            ->select('tbU.idSeguimiento','tbU.idMateria','tbU.tbseDescripcion','tbU.tbseDocumento','tbU.tbseFecha','Tbt.tbmNombre as Materia', 'Tbt.tbmSemestre as Semestre', 'Tbt.tbmParalelo as Paralelo')
            
            ->where('tbU.tbseDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbmNombre','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbseFecha','LIKE','%'.$query.'%')
    		
            ->orderBy('tbU.idSeguimiento','asc')

    		->paginate(7);

    		return view ('docente.seguimientos.index',["seguimiento"=>$seguimiento,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

        $materia=DB::table('tbMateria')->get();
        return view ("docente.seguimientos.create",["materia"=>$materia]);
    }

    
public function store (SegFormRequest $request)
    {
        $seguimiento=new tBSeguimiento;

        $seguimiento->idMateria=$request->get('idMateria');
        
        $seguimiento->tbseDescripcion=$request->get('tbseDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbseDocumento')){
         $file=Input::file('tbseDocumento');
         $file->move(public_path().'/documentos/seguimiento/seguimientos/',$file->getClientOriginalName());
         $seguimiento->tbseDocumento=$file->getClientOriginalName();
        }

        $seguimiento->tbseFecha=$request->get('tbseFecha');

        
        $seguimiento->save();

        return Redirect::to('docente/seguimientos');
    }


    
public function show ($idSeguimiento)
    {

    	return view("docente.seguimientos.show",["seguimiento"=>tBSeguimiento::findOrFail($idSeguimiento)]);

    }

    
public function edit($idSeguimiento)
    {

    	$seguimiento=tBSeguimiento::findOrFail($idSeguimiento);
        $materia=DB::table('tbMateria')->get();
        return view("docente.seguimientos.edit",["seguimiento"=>$seguimiento, "materia"=>$materia]);
    }




    
public function update(SegFormRequest $request, $idSeguimiento)
    {
        $seguimiento=tBSeguimiento::findOrFail($idSeguimiento);

        $seguimiento->idMateria=$request->get('idMateria');
        
        $seguimiento->tbseDescripcion=$request->get('tbseDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbseDocumento')){ 
         $file=Input::file('tbseDocumento');
         $file->move(public_path().'/documentos/seguimiento/seguimientos/',$file->getClientOriginalName());
         $seguimiento->tbseDocumento=$file->getClientOriginalName();
        }

        $seguimiento->tbseFecha=$request->get('tbseFecha');

        $seguimiento->update();

        return Redirect::to('docente/seguimientos');
    }

    

public function destroy($idSeguimiento)
    {

    	
    }

}
