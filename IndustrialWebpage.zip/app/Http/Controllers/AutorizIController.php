<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tbAutorizacionI;
use IndustrialWebpage\Http\Requests\AutorizIFromRequest;
use IndustrialWebpage\tbOficioI;
use IndustrialWebpage\tbFechaIA;
use IndustrialWebpage\tbFechaSA;

use IndustrialWebpage\tbARchInterno;
use IndustrialWebpage\tbARchExterno;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;


use DB;


class AutorizIController extends Controller
{
    ////

        
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		$autI=DB::table('tbAutorizacionI')->where('tbAIDescripcion','LIKE','%'.$query.'%')
            
    		->orwhere('tbAINumOficio','LIKE','%'.$query.'%')                       
            ->where ('idAutorizacionI', '!=', 1)
    		->orderBy('idAutorizacionI','desc')

    		->paginate(7);

    		return view ('escuela.archivador.autorI.index',["autI"=>$autI,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

        $archivadorEII=DB::table('tbArchivadorEII')->get();
        $archTipoI=DB::table('tbArchTipoI')->get();
        
        return view ("escuela.archivador.autorI.create",["archivadorEII"=>$archivadorEII,"archTipoI"=>$archTipoI]);
        
    } 

    
public function store (AutorizIFromRequest $request)
    {
        $autI=new tbAutorizacionI;

        $autI->tbAIDescripcion=$request->get('tbAIDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbAIExaminar')){
         $file=Input::file('tbAIExaminar');
         $file->move(public_path().'/documentos/archivador/autorizaciones/ingreso/',$file->getClientOriginalName());
         $autI->tbAIExaminar=$file->getClientOriginalName();
        }

        $autI->tbAINumOficio=$request->get('tbAINumOficio');

        $autI->save();

        $this->addFecha($autI->idAutorizacionI,$request);

        return Redirect::to('escuela/archivador/autorI');
    }

//finciones new
public function addFecha ($idAutorizacionI,$request)
    {

        $fecha= new tbFechaIA;//llamar
        $fecha->tbfiaFecha=$request->get('tbfiaFecha');
        $fecha->idOficioI=$request->get('idOficioI');
        $fecha->idAutorizacionI=$idAutorizacionI;
        $fecha->save();
        $this->addFechaS($request,$fecha->idFechaIA,$idAutorizacionI);
                
        return Redirect::to('escuela/archivador/autorI');

    }

public function addFechaS ($request,$idFechaIA,$idAutorizacionI)
    {

        $fechaS= new tbFechaSA;//llamar
        $fechaS->tbfsaFecha=$request->get('tbfiaFecha');
        $fechaS->idOficioS=$request->get('idOficioS');
        $fechaS->idAutorizacionS=$request->get('idAutorizacionS');
        $fechaS->save();
        $this->addArch($request,$fechaS->idFechaSA,$idFechaIA);
                
        return Redirect::to('escuela/archivador/autorI');

    }


public function addArch ($request,$idFechaSA,$idFechaIA)
    {

        if ($request->get('cont')=='1'){

            $archIn= new tbARchInterno;//llamar
            $archIn->tbarchExNombre=$request->get('tbAIDescripcion');
            $archIn->idArchEII=$request->get('idArchEII');
            $archIn->idArchTipoI=$request->get('idArchTipoI');
            $archIn->idFechaIA=$idFechaIA;
            $archIn->idFechaSA=$idFechaSA;
            $archIn->save();    
            return Redirect::to('escuela/archivador/autorI');

        }
        
        else{
            $archEx= new tbARchExterno;//llamar
            $archEx->tbarchExNombre=$request->get('tbAIDescripcion');
            $archEx->idArchEII=$request->get('idArchEII');
            $archEx->idArchTipoE=$request->get('idArchTipoI');
            $archEx->idFechaIA=$idFechaIA;
            $archEx->idFechaSA=$idFechaSA;
            $archEx->save();     
            return Redirect::to('escuela/archivador/autorI');

        }
        

    }

//
    
public function show ($idAutorizacionI)
    {

    	return view("escuela.archivador.autorI.show",["autI"=>tbAutorizacionI::findOrFail($idAutorizacionI)]);

    }

    
public function edit($idAutorizacionI)
    {

    	$autorI=tbAutorizacionI::findOrFail($idAutorizacionI);

        $fechaI=DB::table('tbFechaIA')->get();
        
        return view("escuela.archivador.autorI.edit",["autorI"=>$autorI,"fechaI"=>$fechaI]);
    }




    
public function update(AutorizIFromRequest $request, $idAutorizacionI)
    {
        $autI=tbAutorizacionI::findOrFail($idAutorizacionI);

        $autI->tbAIDescripcion=$request->get('tbAIDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbAIExaminar')){
         $file=Input::file('tbAIExaminar');
         $file->move(public_path().'/documentos/archivador/autorizaciones/ingreso/',$file->getClientOriginalName());
         $autI->tbAIExaminar=$file->getClientOriginalName();
        }

        $autI->tbAINumOficio=$request->get('tbAINumOficio');


        $autI->update();

        $this->modFecha($autI->idAutorizacionI,$request);

        return Redirect::to('escuela/archivador/autorI');
    }


    //mdificacion
    public function modFecha ($idAutorizacionI,$request)
    {

        // $fecha= new tbFechaIA;//llamar
        $fecha=tbFechaIA::findOrFail($request->get('idFechaIA'));
        $fecha->tbfiaFecha=$request->get('tbfiaFecha');
        $fecha->idOficioI=$request->get('idOficioI');
        $fecha->idAutorizacionI=$idAutorizacionI;
        $fecha->update();
        //$this->modFechaS($request,$fecha->idFechaIA,$idOficioI);
                
        return Redirect::to('escuela/archivador/autorI');

    }

    //

    

public function destroy($idAutorizacionI)
    {
    	$coment=tbAutorizacionI::findOrFail($idAutorizacionI);

    	$coment->tboEstado='0';

    	$coment->update();

    	return Redirect::to('escuela/archivador/autorI');
    	
    }

}
