<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;

//parte de llamado
use IndustrialWebpage\User;
//use IndustrialWebpage\tbUsuario;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;

use IndustrialWebpage\Http\Requests\UsuarioFormRequest;

use DB;

class uEstudianteController extends Controller
{
     //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
             $usuario=DB::table('users as tbU')
            ->join('tbTipoUsuario as Tbt','Tbt.tbtuId','=','tbU.tbtuId')

           ->select('tbU.id','tbU.tbuCedula','tbU.tbuNombres','tbU.tbuApellidos','tbU.email','tbU.password','tbU.remember_token','tbU.tbuCorreoInstitucional','tbU.tbuSexo','tbU.tbuTelefono','tbU.tbuFechaNacimiento','tbU.tbuFoto','tbU.tbuPais','tbU.tbuCiudad','tbU.tbuCurriculo','tbU.tbuEstado','Tbt.tbtuDescripcion as Tipo')
            
            ->where('tbU.tbuCedula','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbuNombres','LIKE','%'.$query.'%')

            
            ->where ('tbU.tbuEstado','=','1')

            
            ->orderBy('tbU.tbuCedula','desc')

            ->paginate(7);

            return view ('archivador.usuario.index',["usuario"=>$usuario,"searchText"=>$query]);

        }



    }


    
public function create()
    {

        $tipousuario=DB::table('tbTipoUsuario')->where('tbtuEstado','=','1')->get();
        return view ("archivador.usuario.create",["tipousuario"=>$tipousuario]);



    }

    
public function store (UsuarioFormRequest $request)
    {

        $usuario=new User;

        $usuario->tbuCedula=$request->get('tbuCedula');

        $usuario->tbuNombres=$request->get('tbuNombres');

        $usuario->tbuApellidos=$request->get('tbuApellidos');

        $usuario->email=$request->get('email');

        $usuario->password=bcrypt($request->get('password'));
        
       // $usuario->remember_token=$request->get('remember_token');

        $usuario->tbuCorreoInstitucional=$request->get('tbuCorreoInstitucional');

        $usuario->tbuSexo=$request->get('tbuSexo');

        $usuario->tbuTelefono=$request->get('tbuTelefono');

        $usuario->tbuFechaNacimiento=$request->get('tbuFechaNacimiento');

        if (Input::hasFile('tbuFoto')){
         $file=Input::file('tbuFoto');
         $file->move(public_path().'/imagenes/usuarios/',$file->getClientOriginalName());
         $usuario->tbuFoto=$file->getClientOriginalName();
        }
        
        $usuario->tbuPais=$request->get('tbuPais');

        $usuario->tbuCiudad=$request->get('tbuCiudad');

        //$usuario->tbuCurriculo=$request->get('tbuCurriculo');
        if (Input::hasFile('tbuCurriculo')){
         $file1=Input::file('tbuCurriculo');
         $file1->move(public_path().'/documentos/CurriculoUs/',$file1->getClientOriginalName());
         $usuario->tbuCurriculo=$file1->getClientOriginalName();
        }

        $usuario->tbuEstado=$request->get('tbuEstado');

        $usuario->tbtuId=$request->get('tbtuId');

        $usuario->save();

        return Redirect::to('archivador/usuario');


    }


    
public function show ($id)
    {

        return view("archivador.usuario.show",["usuario"=>User::findOrFail($id)]);


    }

    
public function edit($id)
    {

        $usuario=User::findOrFail($id);
        $tipousuario=DB::table('tbTipoUsuario')->where('tbtuEstado','=','1')->get();
        return view("archivador.usuario.edit",["usuario"=>$usuario, "tipousuario"=>$tipousuario]);
        
    }

    public function update(UsuarioFormRequest $request, $id)
    {

        $usuario=User::findOrFail($id);

        $usuario->tbuCedula=$request->get('tbuCedula');

        $usuario->tbuNombres=$request->get('tbuNombres');

        $usuario->tbuApellidos=$request->get('tbuApellidos');

        $usuario->email=$request->get('email');

        $usuario->password=bcrypt($request->get('password'));
        
        $usuario->tbuCorreoInstitucional=$request->get('tbuCorreoInstitucional');

        $usuario->tbuSexo=$request->get('tbuSexo');

        $usuario->tbuTelefono=$request->get('tbuTelefono');

        $usuario->tbuFechaNacimiento=$request->get('tbuFechaNacimiento');

        if (Input::hasFile('tbuFoto')){
         $file=Input::file('tbuFoto');
         $file->move(public_path().'/imagenes/usuarios/',$file->getClientOriginalName());
         $usuario->tbuFoto=$file->getClientOriginalName();
        }

        $usuario->tbuPais=$request->get('tbuPais');

        $usuario->tbuCiudad=$request->get('tbuCiudad');

        //$usuario->tbuCurriculo=$request->get('tbuCurriculo');
        if (Input::hasFile('tbuCurriculo')){
         $file1=Input::file('tbuCurriculo');
         $file1->move(public_path().'/documentos/CurriculoUs/',$file1->getClientOriginalName());
         $usuario->tbuCurriculo=$file1->getClientOriginalName();
        }

        $usuario->tbuEstado=$request->get('tbuEstado');

        $usuario->tbtuId=$request->get('tbtuId');

        
        $usuario->update();

        return Redirect::to('archivador/usuario');
        
    }

    

public function destroy($id)
    {

        $usuario=User::findOrFail($id);

        $usuario->tbuEstado='0';

        $usuario->update();

        return Redirect::to('archivador/usuario'); 


    }
}
