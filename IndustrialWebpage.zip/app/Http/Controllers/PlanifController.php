<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tBPlanificacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;

use IndustrialWebpage\Http\Requests\PlanifFromRequest;
use phpCAS;
use DB; 


class PlanifController extends Controller
{
    //
    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $planificacion=DB::table('tBPlanificacion as tbU')
            ->join('tbMateria as Tbt','Tbt.idMateria','=','tbU.idMateria')

            ->select('tbU.idPlanificacion','tbU.idMateria','tbU.tbplDescripcion','tbU.tbplDocumento','tbU.tbplFecha','Tbt.tbmNombre as Materia', 'Tbt.tbmSemestre as Semestre', 'Tbt.tbmParalelo as Paralelo')
            
            ->where('tbU.tbplDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbmNombre','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbplFecha','LIKE','%'.$query.'%')

            
            ->orderBy('tbU.idPlanificacion','asc')

            ->paginate(7);

    		return view ('escuela.seguimiento.planificacion.index',["planificacion"=>$planificacion,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

        $materia=DB::table('tbMateria')->get();
        return view ("escuela.seguimiento.planificacion.create",["materia"=>$materia]);
    }

    
public function store (PlanifFromRequest $request)
    {
        $planificacion=new tBPlanificacion;

        $planificacion->idMateria=$request->get('idMateria');
        
        $planificacion->tbplDescripcion=$request->get('tbplDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbplDocumento')){
         $file=Input::file('tbplDocumento');
         $file->move(public_path().'/documentos/seguimiento/planificacion/',$file->getClientOriginalName());
         $planificacion->tbplDocumento=$file->getClientOriginalName();
        }

        $planificacion->tbplFecha=$request->get('tbplFecha');
        $planificacion->save();

        return Redirect::to('escuela/seguimiento/planificacion');

    }


    
public function show ($idPlanificacion)
    {

    	return view("escuela.seguimiento.planificacion.show",["planificacion"=>tBPlanificacion::findOrFail($idPlanificacion)]);

    }

    
public function edit($idPlanificacion)
    {

        $planificacion=tBPlanificacion::findOrFail($idPlanificacion);
        $materia=DB::table('tbMateria')->get();
        return view("escuela.seguimiento.planificacion.edit",["planificacion"=>$planificacion, "materia"=>$materia]);    	
    }




    
public function update(PlanifFromRequest $request, $idPlanificacion)
    {
        $planificacion=tBPlanificacion::findOrFail($idPlanificacion);

        $planificacion->idMateria=$request->get('idMateria');
        
        $planificacion->tbplDescripcion=$request->get('tbplDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbplDocumento')){
         $file=Input::file('tbplDocumento');
         $file->move(public_path().'/documentos/seguimiento/planificacion/',$file->getClientOriginalName());
         $planificacion->tbplDocumento=$file->getClientOriginalName();
        }

        $planificacion->tbplFecha=$request->get('tbplFecha');
        $planificacion->update();

        return Redirect::to('escuela/seguimiento/planificacion');
    }

    

public function destroy($idPlanificacion)
    {

    	
    }

}
