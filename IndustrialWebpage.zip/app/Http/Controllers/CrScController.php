<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;

//parte de llamado
use IndustrialWebpage\tbSubcriterio;
use Illuminate\Support\Facades\Redirect;
use phpCAS;

use IndustrialWebpage\Http\Requests\SubcritFormRequest;

use DB;


class CrScController extends Controller
{
    //

     //

   
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index ($idCriterio)
    {


            

    }

/*
public function create()
    {

        $criterio=DB::table('tbCriterio')->get();
        return view ("escuela.autoevaluacion.CrSC.create",["criterio"=>$criterio]);


    }

    
public function store (SubcritFormRequest $request)
    {

        $subcriterio=new tbSubcriterio;

        $subcriterio->idCriterio=$request->get('idCriterio');
        
        $subcriterio->tbscDescripcion=$request->get('tbscDescripcion');

        $subcriterio->save();

        return Redirect::to('escuela/autoevaluacion/CrSC');


    }

*/
    
public function show ($idCriterio)
    {

 }

public function edit($idCriterio)
    {

        $subcriterio=DB::table('tbSubcriterio as tbU')
            ->join('tbCriterio as Tbt','Tbt.idCriterio','=','tbU.idCriterio')

            ->select('tbU.idSubcriterio','tbU.idCriterio','tbU.tbscDescripcion','Tbt.tbcDescripcion as Descrip')
            
            
            ->where('tbU.idCriterio','=',$idCriterio)
            
            ->orderBy('idSubcriterio','asc')

            ->paginate(7);

        return view ('escuela.autoevaluacion.CrSC.edit',["subcriterio"=>$subcriterio]);
    }

    

}
