<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
use IndustrialWebpage\User;
use IndustrialWebpage\tbAsistencia;
use IndustrialWebpage\tbDetalleAsistencia;
use IndustrialWebpage\tbHoraInicio;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\AsistenciaFormRequest;
// use Carbon\Carbon;
use Carbon\Carbon;
use phpCAS;

use DB;
class AsistenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }

    public function index(Request $request)
    {
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $date = Carbon::now();
            $dia=$date->toDateString();
            
             $asistencia=DB::table('tbAsistencia as tbA')
             ->join('tbDetalleAsistencia as tbD','tbD.idAsis','=','tbA.idAsis')
             ->join('tbHoraInicio as tbH','tbH.idDetalle','=','tbD.idDetalle')
             ->select('tbA.tbaDescripcion as Dia','tbD.tbdFecha as Fecha','tbD.tbaCedula as cedula','tbD.tbaNombre as Nombre','tbD.tbaApellido as Apellido','tbH.tbhiHora as hora')
             ->where('tbA.tbaDescripcion','LIKE','%'.$query.'%')
             ->orwhere('tbD.tbaCedula','LIKE','%'.$query.'%')
             ->orderBy('tbD.tbaCedula','asc')
             ->paginate(7);
         return view ('escuela.AsistenciaI.index',["asistencia"=>$asistencia,"searchText"=>$query,"dia"=>$dia]);
     }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // $now=Carbon::now();

        return view ("escuela.AsistenciaI.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   public function store (AsistenciaFormRequest $request)
    {
       
       // $fechaActual=Carbon::now();
        $date = Carbon::now();
        $asistencia=new tbAsistencia;

        $asistencia->tbaDescripcion=$date->format('l jS ');

        $asistencia->save();
        $this->addFechaDetalle($asistencia->idAsis,$request,$date);

        return Redirect::to('escuela/AsistenciaI');
    }

    public function addFechaDetalle ($idAsis,$request,$date)
    {
        //
        $porciones = explode(" ", $request->get('tbaNombre'));
        //
        $fechaI= new tbDetalleAsistencia;//llamar
        $fechaI->tbdFecha=$date->toDateString();
        $fechaI->idAsis=$idAsis;
        $fechaI->tbaCedula=$request->get('tbaCedula');
        $fechaI->tbaNombre=$porciones[0];
        $fechaI->tbaApellido=$porciones[2];
        $fechaI->save();
        $this->addHoraI($fechaI->idDetalle,$date);
                
        return Redirect::to('escuela/AsistenciaI');
    }

    public function addHoraI ($idDetalle,$date)
    {
        $horaI= new tbHoraInicio;//llamar
        $horaI->tbhiHora=$date->toTimeString();
        $horaI->idDetalle=$idDetalle;
        $horaI->save();
                
        return Redirect::to('escuela/AsistenciaI');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function show ($idAsis)
    {

        return view("escuela.AsistenciaI.show",["asistencia"=>tbAsistencia::findOrFail($idAsis)]);


    }
    

    public function destroy($id)
    {
        //
    }
}
