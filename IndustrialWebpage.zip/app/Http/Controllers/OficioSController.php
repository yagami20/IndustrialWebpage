<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tbOficioS;
use IndustrialWebpage\tbFechaIA;
use IndustrialWebpage\tbFechaSA;

use IndustrialWebpage\tbARchInterno;
use IndustrialWebpage\tbARchExterno;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use IndustrialWebpage\Http\Requests\OficioIfromRequest;
use phpCAS;
use DB;



class OficioSController extends Controller
{
    //

     
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		$oficioS=DB::table('tbOficioS')->where('tbOSDescripcion','LIKE','%'.$query.'%')
            
    		->orwhere('tbOSNumOficio','LIKE','%'.$query.'%')                       
            ->where ('idOficioS', '!=', 1)
    		->orderBy('idOficioS','desc')

    		->paginate(7);

    		return view ('escuela.archivador.oficiosS.index',["oficioS"=>$oficioS,"searchText"=>$query]);

    	}



    }


    
public function create()
    {
        $archivadorEII=DB::table('tbArchivadorEII')->get();
        $archTipoI=DB::table('tbArchTipoI')->get();
        return view ("escuela.archivador.oficiosS.create",["archivadorEII"=>$archivadorEII,"archTipoI"=>$archTipoI]);
        
    }

    
public function store (Request $request)
    {
        $oficioS=new tbOficioS;

        $oficioS->tbOSDescripcion=$request->get('tbOSDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbOSExaminar')){
         $file=Input::file('tbOSExaminar');
         $file->move(public_path().'/documentos/archivador/oficios/salida/',$file->getClientOriginalName());
         $oficioS->tbOSExaminar=$file->getClientOriginalName();
        }

        $oficioS->tbOSNumOficio=$request->get('tbOSNumOficio');
        $oficioS->save();
        $this->addFecha($oficioS->idOficioS,$request);

       

        return Redirect::to('escuela/archivador/oficiosS');
    }


    
public function addFecha ($idOficioS,$request)
    {

        $fecha= new tbFechaSA;//llamar
        $fecha->tbfsaFecha=$request->get('tbfsaFecha');
        $fecha->idOficioS=$idOficioS;
        $fecha->idAutorizacionS=$request->get('idAutorizacionS');
        $fecha->save();
        $this->addFechaI($request,$fecha->idFechaSA,$idOficioS);
                
        return Redirect::to('escuela/archivador/oficiosS');

    }

public function addFechaI ($request,$idFechaSA,$idOficioS)
    {

        $fechaS= new tbFechaIA;//llamar
        $fechaS->tbfiaFecha=$request->get('tbfsaFecha');
        $fechaS->idOficioI=$request->get('idOficioI');
        $fechaS->idAutorizacionI=$request->get('idAutorizacionS');
        $fechaS->save();
        $this->addArch($request,$fechaS->idFechaIA,$idFechaSA);
                
        return Redirect::to('escuela/archivador/oficiosS');

    }


public function addArch ($request,$idFechaIA,$idFechaSA)
    {

        if ($request->get('cont')=='1'){

            $archIn= new tbARchInterno;//llamar
            $archIn->tbarchExNombre=$request->get('tbOSDescripcion');
            $archIn->idArchEII=$request->get('idArchEII');
            $archIn->idArchTipoI=$request->get('idArchTipoI');
            $archIn->idFechaIA=$idFechaIA;
            $archIn->idFechaSA=$idFechaSA;
            $archIn->save();    
            return Redirect::to('escuela/archivador/oficiosS');

        }
        
        else{
            $archEx= new tbARchExterno;//llamar
            $archEx->tbarchExNombre=$request->get('tbOSDescripcion');
            $archEx->idArchEII=$request->get('idArchEII');
            $archEx->idArchTipoE=$request->get('idArchTipoI');
            $archEx->idFechaIA=$idFechaIA;
            $archEx->idFechaSA=$idFechaSA;
            $archEx->save();     
            return Redirect::to('escuela/archivador/oficiosS');

        }
        

    }


public function show ($idOficioS)
    {

        return view("escuela.archivador.oficiosS",["oficioS"=>tbOficioS::findOrFail($idOficioS)]);

    }

    
public function edit($idOficioS)
    {

        $oficioS=tbOficioS::findOrFail($idOficioS);
                
        $fechaS=DB::table('tbFechaSA')->get();
        
        return view("escuela.archivador.oficiosS.edit",["oficioS"=>$oficioS,"fechaS"=>$fechaS]);
    }




    
public function update(Request $request, $idOficioS)
    {
        $oficioS=tbOficioS::findOrFail($idOficioS);

        $oficioS->tbOSDescripcion=$request->get('tbOSDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbOSExaminar')){
         $file=Input::file('tbOSExaminar');
         $file->move(public_path().'/documentos/archivador/oficios/salida/',$file->getClientOriginalName());
         $oficioS->tbOSExaminar=$file->getClientOriginalName();
        }

        $oficioS->tbOSNumOficio=$request->get('tbOSNumOficio');

        $oficioS->update();
        $this->modFecha($oficioS->idOficioS,$request);

        return Redirect::to('escuela/archivador/oficiosS');
    }

//modificacion
    
public function modFecha ($idOficioS,$request)
    {

        // $fecha= new tbFechaIA;//llamar
        $fecha=tbFechaSA::findOrFail($request->get('idFechaSA'));
        $fecha->tbfsaFecha=$request->get('tbfsaFecha');
        $fecha->idOficioS=$idOficioS;
        $fecha->idAutorizacionS=$request->get('idAutorizacionS');
        $fecha->update();
        //$this->modFechaS($request,$fecha->idFechaIA,$idOficioI);
                
        return Redirect::to('escuela/archivador/oficiosS');

    }



//
public function destroy($idOficioS)
    {
        /*
        
        */
        $coment=DB::table('tbFechaSA')->where('idOficioS','=',$idOficioS)->get();
        $coment->delete();

        $this->dest2($idOficioS);
        return Redirect::to('escuela/archivador/oficiosS');
        
    }

    public function dest2($idOficioS)
    {
        
        $com1=tbOficioS::find($idOficioS);
        //$coment->tbOINumOficio='0';
        $com1->delete();

        return Redirect::to('escuela/archivador/oficiosS');
        
    }

}
