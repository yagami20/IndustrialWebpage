<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tBObservacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use IndustrialWebpage\Http\Requests\ObservFormRequest;
use phpCAS;
use DB;


class ObservacionController extends Controller
{
    //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		$coment=DB::table('tBObservacion')->where('tboDetalle','LIKE','%'.$query.'%')
            
            ->where ('tboEstado','=','1')
    		->orderBy('idObservacion','desc')

    		->paginate(7);

    		return view ('escuela.seguimiento.observacion.index',["coment"=>$coment,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

        return view ("escuela.seguimiento.observacion.create");
        
    }

    
public function store (ObservFormRequest $request)
    {
        $coment=new tBObservacion;

        $coment->tboDetalle=$request->get('tboDetalle');
        
        /*seccion pdf */
        if (Input::hasFile('tboDocumento')){
         $file=Input::file('tboDocumento');
         $file->move(public_path().'/documentos/seguimiento/observacion/',$file->getClientOriginalName());
         $coment->tboDocumento=$file->getClientOriginalName();
        }

        $coment->tboEstado=$request->get('tboEstado');

        $coment->tboFecha=$request->get('tboFecha');

        
        $coment->save();

        return Redirect::to('escuela/seguimiento/observacion');
    }


    
public function show ($idObservacion)
    {

    	return view("escuela.seguimiento.observacion.show",["coment"=>tBObservacion::findOrFail($idObservacion)]);

    }

    
public function edit($idObservacion)
    {

    	$coment=tBObservacion::findOrFail($idObservacion);
        
        return view("escuela.seguimiento.observacion.edit",["coment"=>$coment]);
    }




    
public function update(ObservFormRequest $request, $idObservacion)
    {
        $coment=tBObservacion::findOrFail($idObservacion);

        $coment->tboDetalle=$request->get('tboDetalle');
        
        /*seccion pdf */
        if (Input::hasFile('tboDocumento')){
         $file=Input::file('tboDocumento');
         $file->move(public_path().'/documentos/seguimiento/observacion/',$file->getClientOriginalName());
         $coment->tboDocumento=$file->getClientOriginalName();
        }

        $coment->tboEstado=$request->get('tboEstado');

        $coment->tboFecha=$request->get('tboFecha');

        $coment->update();

        return Redirect::to('escuela/seguimiento/observacion');
    }

    

public function destroy($idObservacion)
    {
    	$coment=tBObservacion::findOrFail($idObservacion);

    	$coment->tboEstado='0';

    	$coment->update();

    	return Redirect::to('escuela/seguimiento/observacion');
    	
    }

    
}
