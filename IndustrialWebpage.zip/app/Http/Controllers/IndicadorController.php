<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\IndicFormRequest;
use phpCAS;
use DB;




class IndicadorController extends Controller
{
    //
    //

   
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		/* $subcriterio=DB::table('tbSubcriterio')->where('tbscDescripcion','LIKE','%'.$query.'%')
    		->orderby('idSubcriterio','asc')
    		->paginate(7); */
            
            $indicador=DB::table('tbIndicador as tbI')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbC.idCriterio','=','tbSC.idCriterio')
            ->select('tbI.idIndicador','tbI.idSubcriterio','tbI.tbinDescripcion','tbI.tbinDocumento','tbSC.tbscDescripcion as DesSC', 'tbC.tbcDescripcion as DesC')

            ->where('tbinDescripcion','LIKE','%'.$query.'%')
            ->orwhere('tbSC.tbscDescripcion','LIKE','%'.$query.'%')
            ->orwhere('tbC.tbcDescripcion','LIKE','%'.$query.'%')
    		->orderby('idIndicador','asc')
    		->paginate(7);


    		return view ('escuela.autoevaluacion.indicador.index',["indicador"=>$indicador,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$criterio=DB::table('tbCriterio')->get();
    	$subcriterio=DB::table('tbSubcriterio')->get();
        return view ("escuela.autoevaluacion.indicador.create",["criterio"=>$criterio,"subcriterio"=>$subcriterio]);


    }

    
public function store (IndicFormRequest $request)
    {

    	$indicador=new tbIndicador;

    	$indicador->idSubcriterio=$request->get('idSubcriterio');
		
		$indicador->tbinDescripcion=$request->get('tbinDescripcion');

		if (Input::hasFile('tbinDocumento')){
         $file=Input::file('tbinDocumento');
         $file->move(public_path().'/documentos/autoevaluacion/indicador/',$file->getClientOriginalName());
         $indicador->tbinDocumento=$file->getClientOriginalName();
        }

    	$indicador->save();

    	return Redirect::to('escuela/autoevaluacion/indicador');


    }


    
public function show ($idIndicador)
    {

    	return view("escuela.autoevaluacion.indicador.show",["indicador"=>tbIndicador::findOrFail($idIndicador)]);

    }

    
public function edit($idIndicador)
    {

    	$indicador=tbIndicador::findOrFail($idIndicador);
        $criterio=DB::table('tbCriterio')->get();
        $subcriterio=DB::table('tbSubcriterio')->get();
        return view("escuela.autoevaluacion.indicador.edit",["indicador"=>$indicador, "criterio"=>$criterio,"subcriterio"=>$subcriterio]);
        
    }

public function update(IndicFormRequest $request, $idIndicador)
    {

    	$indicador=tbIndicador::findOrFail($idIndicador);

    	$indicador->idSubcriterio=$request->get('idSubcriterio');
		
		$indicador->tbinDescripcion=$request->get('tbinDescripcion');

		if (Input::hasFile('tbinDocumento')){
         $file=Input::file('tbinDocumento');
         $file->move(public_path().'/documentos/autoevaluacion/indicador/',$file->getClientOriginalName());
         $indicador->tbinDocumento=$file->getClientOriginalName();
        }
        
        $indicador->update();

    	return Redirect::to('escuela/autoevaluacion/indicador');
    	
    }

public function destroy($idIndicador)
    {

        $indicador=tbIndicador::findOrFail($idIndicador);
        return Redirect::to('escuela/autoevaluacion/indicador'); 


    }


    

}
