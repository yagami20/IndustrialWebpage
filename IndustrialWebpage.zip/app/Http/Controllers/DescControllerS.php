<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
 //parte de llamado
use IndustrialWebpage\tbPublicaciones;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;
//use Symfony\Component\HttpFoundation\Response;
use phpCAS;


use IndustrialWebpage\Http\Requests\PublicacionFormRequest;

use DB; 

class DescControllerS extends Controller
{
    //
     //
   
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$silabo=DB::table('tBSilabo as tbU')
            ->join('tbMateria as Tbt','Tbt.idMateria','=','tbU.idMateria')

            ->select('tbU.idSilabo','tbU.idMateria','tbU.tbsiDescripcion','tbU.tbsiDocumento','tbU.tbsiFecha','Tbt.tbmNombre as Materia', 'Tbt.tbmSemestre as Semestre', 'Tbt.tbmParalelo as Paralelo')
            
            ->where('tbU.tbsiDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbmNombre','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbsiFecha','LIKE','%'.$query.'%')
    		
            ->orderBy('tbU.idSilabo','asc')
    		->paginate(7);

    		return view ('escuela.descargadorS.index',["silabo"=>$silabo,"searchText"=>$query]);

    	}



    }


    
public function create()
    {


    }

    
public function store (PublicacionFormRequest $request)
    {

    }


    
public function show ($idSilabo)
    {

    	return view("escuela.descargadorP.show",["silabo"=>tBSilabo::findOrFail($idSilabo)]);

    }

    
public function edit($idPlanificacion)
    {

    	
    }

public function archivo($idPlanificacion)
    {

        $planificacion=tBPlanificacion::findOrFail($idPlanificacion);
        $escuela=DB::table('tbEscuela')->where('idEscuela','=','1')->get();
        return view("escuela.descargadorP.publicacionU",["planificacion"=>$planificacion, "escuela"=>$escuela]);
         

    }


    
public function update(PublicacionFormRequest $request, $idPlanificacion)
    {

    }

    

public function destroy($idSilabo)
    {

    	
    }
}
