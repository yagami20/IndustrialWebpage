<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use Carbon\Carbon;
use DateTime;
use IndustrialWebpage\tblSeguimientoP;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\SegPedagoFormRequest;

use DB;
use phpCAS; 

class VisualPSSController extends Controller
{
    //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {
    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
			$f1=date("Y-m-d", strtotime($request->get('searchText')));
			$f2=date("Y-m-d", strtotime($request->get('searchText')));			 
			$segp=DB::table('tblSeguimientoP as tbI')
            ->join('tBPlanificacion as tbSC','tbI.idPlanificacion','=','tbSC.idPlanificacion')
            ->join('tBSilabo as tbC','tbC.idSilabo','=','tbI.idSilabo')
            
            ->join('tBObservacion as tbO','tbO.idObservacion','=','tbI.idObservacion')
            ->join('tbEscuela as tbE','tbE.idEscuela','=','tbI.idEscuela')
            ->join('tBSeguimiento as tbD','tbD.idSeguimiento','=','tbI.idSeguimiento')
            ->join('tbMateria as tbM','tbM.idMateria','=','tbD.idMateria')
            ->select('tbI.idSeguimientoP','tbI.tbsegFecha','tbI.idEscuela','tbI.idPlanificacion','tbI.idSilabo','tbI.idSeguimiento','tbI.idObservacion','tbSC.tbplDescripcion as DesPl','tbSC.tbplDocumento as DocPl','tbC.tbsiDescripcion as DesSi','tbC.tbsiDocumento as DocSi','tbD.tbseDescripcion as DesSe','tbD.tbseDocumento as DocSe','tbM.tbmNombre as Materia','tbO.tboDocumento as DocOb','tbO.tboDetalle as DesOb','tbE.tbeNombre as Escuela')
            ->whereBetween('tbI.tbsegFecha',[$f1,$f2])
            ->orwhere('tbM.tbmNombre','LIKE','%'.$query.'%')
            ->orderby('idSeguimientoP','asc')
            ->paginate(7);
            return view ('escuela.seguimiento.SegPedFecha.index',["segp"=>$segp,"searchText"=>$query]);
            

    		

    	}
    	



    }


    
public function create()
    {

        $planificacion=DB::table('tBPlanificacion')->get();
        $silabo=DB::table('tBSilabo')->get();
        $seguimiento=DB::table('tBSeguimiento')->get();
        $escuela=DB::table('tbEscuela')->get();
        return view ("escuela.seguimiento.SegPedDocente.create",["planificacion"=>$planificacion,"silabo"=>$silabo,"seguimiento"=>$seguimiento,"escuela"=>$escuela]);
    }

    
public function store (SegPedagoFormRequest $request)
    {
        $segp=new tblSeguimientoP;

        $segp->tbsegFecha=$request->get('tbsegFecha');
        
        $segp->idEscuela=$request->get('idEscuela');

        $segp->idPlanificacion=$request->get('idPlanificacion');

        $segp->idSilabo=$request->get('idSilabo');
        
        $segp->idSeguimiento=$request->get('idSeguimiento');
        
        $segp->idObservacion=$request->get('idObservacion');
        
        
        $segp->save();

        return Redirect::to('escuela/seguimiento/SegPedDocente');
    }


    
public function show ($idSeguimientoP)
    {

    	return view("escuela.seguimiento.SegPedDocente.show",["segp"=>segp::findOrFail($idSeguimientoP)]);

    }

    
public function edit($idSeguimientoP)
    {

    	
        $segp=tblSeguimientoP::findOrFail($idSeguimientoP);
        $planificacion=DB::table('tBPlanificacion')->get();
        $silabo=DB::table('tBSilabo')->get();
        $seguimiento=DB::table('tBSeguimiento')->get();
        $escuela=DB::table('tbEscuela')->get();
        $materia=DB::table('tbMateria')->get();
        return view ("escuela.seguimiento.SegPedDocente.edit",["segp"=>$segp,"planificacion"=>$planificacion,"silabo"=>$silabo,"seguimiento"=>$seguimiento,"escuela"=>$escuela,"materia"=>$materia]);
    }




    
public function update(SegPedagoFormRequest $request, $idSeguimientoP)
    {
        $segp=tblSeguimientoP::findOrFail($idSeguimientoP);

        $segp->tbsegFecha=$request->get('tbsegFecha');
        
        $segp->idEscuela=$request->get('idEscuela');

        $segp->idPlanificacion=$request->get('idPlanificacion');

        $segp->idSilabo=$request->get('idSilabo');
        
        $segp->idSeguimiento=$request->get('idSeguimiento');
        
        $segp->idObservacion=$request->get('idObservacion');
        
        $segp->update();

        return Redirect::to('escuela/seguimiento/SegPedDocente');
    }

    

public function destroy($idSeguimientoP)
    {

    	
    }
}
