<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//

use IndustrialWebpage\tbSubIndicador;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\SubIndFormRequest;
use phpCAS;
use DB;

class SubindicController extends Controller
{
    //
     


   
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		/* $subcriterio=DB::table('tbSubcriterio')->where('tbscDescripcion','LIKE','%'.$query.'%')
    		->orderby('idSubcriterio','asc')
    		->paginate(7); */
            
            $subindicador=DB::table('tbSubIndicador as tbSI')
            ->join('tbIndicador as tbI', 'tbSI.idIndicador','=','tbI.idIndicador')
            ->join('tbSubcriterio as tbSC','tbI.idSubcriterio','=','tbSC.idSubcriterio')
            ->join('tbCriterio as tbC','tbSC.idCriterio','=','tbC.idCriterio')
            ->select('tbSI.idSubindicador', 'tbSI.idIndicador', 'tbSI.tbsubiDescripcion as DesSI',
                'tbSI.tbsubiDocumento', 'tbSI.tbsubiTabla', 'tbSI.tbsubiFecha',
                'tbI.tbinDescripcion as DesIn', 'tbSC.tbscDescripcion as DesSC',
                 'tbC.tbcDescripcion as DesC')

            ->where('tbsubiDescripcion','LIKE','%'.$query.'%')
            ->orwhere('tbI.tbinDescripcion','LIKE','%'.$query.'%')
            ->orwhere('tbSC.tbscDescripcion','LIKE','%'.$query.'%')
            ->orwhere('tbC.tbcDescripcion','LIKE','%'.$query.'%')
            ->orderby('idSubindicador','asc')
    		->paginate(7);

            return view ('escuela.autoevaluacion.subindicador.index',["subindicador"=>$subindicador,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	$criterio=DB::table('tbCriterio')->get();
    	$subcriterio=DB::table('tbSubcriterio')->get();
        $indicador=DB::table('tbIndicador')->get();
        return view ("escuela.autoevaluacion.subindicador.create",["criterio"=>$criterio,"subcriterio"=>$subcriterio,"indicador"=>$indicador]);


    }

    
public function store (SubIndFormRequest $request)
    {

    	$subindicador=new tbSubIndicador;

    	$subindicador->idIndicador=$request->get('idIndicador');
		
		$subindicador->tbsubiDescripcion=$request->get('tbsubiDescripcion');

		/*seccion foto */
        //$subindicador->tbpFoto=$request->get('tbpFoto');

        if (Input::hasFile('tbsubiDocumento')){
         $file1=Input::file('tbsubiDocumento');
         $file1->move(public_path().'/documentos/autoevaluacion/subindicador/documento/',$file1->getClientOriginalName());
         $subindicador->tbsubiDocumento=$file1->getClientOriginalName();
        }

        /*seccion pdf */
        //$subindicador->tbpExaminar=$request->get('tbpExaminar');

        if (Input::hasFile('tbsubiTabla')){
         $file=Input::file('tbsubiTabla');
         $file->move(public_path().'/documentos/autoevaluacion/subindicador/tabla/',$file->getClientOriginalName());
         $subindicador->tbsubiTabla=$file->getClientOriginalName();
        }

        $subindicador->tbsubiFecha=$request->get('tbsubiFecha');

    	$subindicador->save();

    	return Redirect::to('escuela/autoevaluacion/subindicador');


    }


    
public function show ($idSubindicador)
    {

    	return view("escuela.autoevaluacion.subindicador.show",["subindicador"=>tbSubIndicador::findOrFail($idSubindicador)]);

    }

    
public function edit($idSubindicador)
    {
        $subindicador=tbSubIndicador::findOrFail($idSubindicador);
    	$indicador=DB::table('tbIndicador')->get();
        $criterio=DB::table('tbCriterio')->get();
        $subcriterio=DB::table('tbSubcriterio')->get();
        return view("escuela.autoevaluacion.subindicador.edit",["subindicador"=>$subindicador,"indicador"=>$indicador, "criterio"=>$criterio,"subcriterio"=>$subcriterio]);
        
    }

public function update(SubIndFormRequest $request, $idSubindicador)
    {

    	$subindicador=tbSubIndicador::findOrFail($idSubindicador);

    	$subindicador->idIndicador=$request->get('idIndicador');
        
        $subindicador->tbsubiDescripcion=$request->get('tbsubiDescripcion');

        /*seccion foto */
        //$subindicador->tbpFoto=$request->get('tbpFoto');

        if (Input::hasFile('tbsubiDocumento')){
         $file1=Input::file('tbsubiDocumento');
         $file1->move(public_path().'/documentos/autoevaluacion/subindicador/documento/',$file1->getClientOriginalName());
         $subindicador->tbsubiDocumento=$file1->getClientOriginalName();
        }

        /*seccion pdf */
        //$subindicador->tbpExaminar=$request->get('tbpExaminar');

        if (Input::hasFile('tbsubiTabla')){
         $file=Input::file('tbsubiTabla');
         $file->move(public_path().'/documentos/autoevaluacion/subindicador/tabla/',$file->getClientOriginalName());
         $subindicador->tbsubiTabla=$file->getClientOriginalName();
        }

        $subindicador->tbsubiFecha=$request->get('tbsubiFecha');

        
        $subindicador->update();

    	return Redirect::to('escuela/autoevaluacion/subindicador');
    	
    }

    public function destroy($idSubindicador)
    {

        $subindicador=tbSubIndicador::findOrFail($idSubindicador);
        return Redirect::to('escuela/autoevaluacion/subindicador'); 


    }

    public function destroy2($idSubindicador)
    {

        $subindicador=tbSubIndicador::findOrFail($idSubindicador);
        return Redirect::to('escuela/autoevaluacion/subindicador'); 


    }



    
}
