<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tbAutorizacionS;

use IndustrialWebpage\Http\Requests\AutorizSFromRequest;
use IndustrialWebpage\tbOficioS;
use IndustrialWebpage\tbFechaIA;
use IndustrialWebpage\tbFechaSA;

use IndustrialWebpage\tbARchInterno;
use IndustrialWebpage\tbARchExterno;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;

use DB;
class AutorizSController extends Controller
{
    ////

        
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		$autS=DB::table('tbAutorizacionS')->where('tbASDescripcion','LIKE','%'.$query.'%')
            
    		->orwhere('tbASNumOficio','LIKE','%'.$query.'%')                       
            ->where ('idAutorizacionS', '!=', 1)
    		->orderBy('idAutorizacionS','desc')

    		->paginate(7);

    		return view ('escuela.archivador.autorS.index',["autS"=>$autS,"searchText"=>$query]);

    	} 



    }


    
public function create()
    {

        $archivadorEII=DB::table('tbArchivadorEII')->get();
        $archTipoI=DB::table('tbArchTipoI')->get();
        return view ("escuela.archivador.autorS.create",["archivadorEII"=>$archivadorEII,"archTipoI"=>$archTipoI]);
        
    }

    
public function store (AutorizSFromRequest $request)
    {
        $autS=new tbAutorizacionS;

        $autS->tbASDescripcion=$request->get('tbASDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbASExaminar')){
         $file=Input::file('tbASExaminar');
         $file->move(public_path().'/documentos/archivador/autorizaciones/salida/',$file->getClientOriginalName());
         $autS->tbASExaminar=$file->getClientOriginalName();
        }

        $autS->tbASNumOficio=$request->get('tbASNumOficio');

        
        $autS->save();

        $this->addFecha($autS->idAutorizacionS,$request);


        return Redirect::to('escuela/archivador/autorS');
    }

//
    public function addFecha ($idAutorizacionS,$request)
    {

        $fecha= new tbFechaSA;//llamar
        $fecha->tbfsaFecha=$request->get('tbfsaFecha');
        $fecha->idOficioS=$request->get('idOficioS');
        $fecha->idAutorizacionS=$idAutorizacionS;
        $fecha->save();
        $this->addFechaI($request,$fecha->idFechaSA,$idAutorizacionS);
                
        return Redirect::to('escuela/archivador/autorS');

    }

public function addFechaI ($request,$idFechaSA,$idAutorizacionS)
    {

        $fechaS= new tbFechaIA;//llamar
        $fechaS->tbfiaFecha=$request->get('tbfsaFecha');
        $fechaS->idOficioI=$request->get('idOficioI');
        $fechaS->idAutorizacionI=$request->get('idAutorizacionI');
        $fechaS->save();
        $this->addArch($request,$fechaS->idFechaIA,$idFechaSA);
                
        return Redirect::to('escuela/archivador/autorS');

    }


public function addArch ($request,$idFechaIA,$idFechaSA)
    {

        if ($request->get('cont')=='1'){

            $archIn= new tbARchInterno;//llamar
            $archIn->tbarchExNombre=$request->get('tbASDescripcion');
            $archIn->idArchEII=$request->get('idArchEII');
            $archIn->idArchTipoI=$request->get('idArchTipoI');
            $archIn->idFechaIA=$idFechaIA;
            $archIn->idFechaSA=$idFechaSA;
            $archIn->save();    
            return Redirect::to('escuela/archivador/autorS');

        }
        
        else{
            $archEx= new tbARchExterno;//llamar
            $archEx->tbarchExNombre=$request->get('tbASDescripcion');
            $archEx->idArchEII=$request->get('idArchEII');
            $archEx->idArchTipoE=$request->get('idArchTipoI');
            $archEx->idFechaIA=$idFechaIA;
            $archEx->idFechaSA=$idFechaSA;
            $archEx->save();     
            return Redirect::to('escuela/archivador/autorS');

        }
        

    }
//
    
public function show ($idAutorizacionS)
    {

    	return view("escuela.archivador.autorS.show",["autS"=>tbAutorizacionS::findOrFail($idAutorizacionS)]);

    }

    
public function edit($idAutorizacionS)
    {

    	$autS=tbAutorizacionS::findOrFail($idAutorizacionS);
        $fechaS=DB::table('tbFechaSA')->get();
        
        return view("escuela.archivador.autorS.edit",["autS"=>$autS,"fechaS"=>$fechaS]);
    }




    
public function update(AutorizSFromRequest $request, $idAutorizacionS)
    {
        $autS=tbAutorizacionS::findOrFail($idAutorizacionS);

        $autS->tbASDescripcion=$request->get('tbASDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbASExaminar')){
         $file=Input::file('tbASExaminar');
         $file->move(public_path().'/documentos/archivador/autorizaciones/salida/',$file->getClientOriginalName());
         $autS->tbASExaminar=$file->getClientOriginalName();
        }

        $autS->tbASNumOficio=$request->get('tbASNumOficio');

        
        $autS->update();

        $this->modFecha($autS->idAutorizacionS,$request);

        return Redirect::to('escuela/archivador/autorS');
    }

    //modif
    public function modFecha ($idAutorizacionS,$request)
    {

        // $fecha= new tbFechaIA;//llamar
        $fecha=tbFechaSA::findOrFail($request->get('idFechaSA'));
        $fecha->tbfsaFecha=$request->get('tbfsaFecha');
        $fecha->idOficioS=$request->get('idOficioS');
        $fecha->idAutorizacionS=$idAutorizacionS;
        $fecha->update();
        //$this->modFechaS($request,$fecha->idFechaIA,$idOficioI);
                
        return Redirect::to('escuela/archivador/autorS');

    }


    //

    

public function destroy($idAutorizacionS)
    {
    	$coment=tbAutorizacionS::findOrFail($idAutorizacionS);

    	$coment->tboEstado='0';

    	$coment->update();

    	return Redirect::to('escuela/archivador/autorS');
    	
    }

}
