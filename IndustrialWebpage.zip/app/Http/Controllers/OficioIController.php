<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tbOficioI;
use IndustrialWebpage\tbFechaIA;
use IndustrialWebpage\tbFechaSA;

use IndustrialWebpage\tbARchInterno;
use IndustrialWebpage\tbARchExterno;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use IndustrialWebpage\Http\Requests\OficioIfromRequest;
use phpCAS;
use DB;

class OficioIController extends Controller
{
    //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            $oficioI=DB::table('tbOficioI')->where('tbOIDescripcion','LIKE','%'.$query.'%')
            
            ->orwhere('tbOINumOficio','LIKE','%'.$query.'%')
            ->orwhere ('tbOINumOficio', '!=', '0')
            
            ->orderBy('idOficioI','desc')

            ->paginate(7);

            return view ('escuela.archivador.oficiosI.index',["oficioI"=>$oficioI,"searchText"=>$query]);

        }



    }


    
public function create()
    {
        $archivadorEII=DB::table('tbArchivadorEII')->get();
        $archTipoI=DB::table('tbArchTipoI')->get();
        return view ("escuela.archivador.oficiosI.create",["archivadorEII"=>$archivadorEII,"archTipoI"=>$archTipoI]);
        
    }

    
public function store (Request $request)
    {
        $oficioI=new tbOficioI;

        $oficioI->tbOIDescripcion=$request->get('tbOIDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbOIExaminar')){
         $file=Input::file('tbOIExaminar');
         $file->move(public_path().'/documentos/archivador/oficios/ingreso/',$file->getClientOriginalName());
         $oficioI->tbOIExaminar=$file->getClientOriginalName();
        }

        $oficioI->tbOINumOficio=$request->get('tbOINumOficio');
        $oficioI->save();
        $this->addFecha($oficioI->idOficioI,$request);

       

        return Redirect::to('escuela/archivador/oficiosI');
    }


    
public function addFecha ($idOficioI,$request)
    {

        $fecha= new tbFechaIA;//llamar
        $fecha->tbfiaFecha=$request->get('tbfiaFecha');
        $fecha->idOficioI=$idOficioI;
        $fecha->idAutorizacionI=$request->get('idAutorizacionI');
        $fecha->save();
        $this->addFechaS($request,$fecha->idFechaIA,$idOficioI);
                
        return Redirect::to('escuela/archivador/oficiosI');

    }

public function addFechaS ($request,$idFechaIA,$idOficioI)
    {

        $fechaS= new tbFechaSA;//llamar
        $fechaS->tbfsaFecha=$request->get('tbfiaFecha');
        $fechaS->idOficioS=$request->get('idOficioS');
        $fechaS->idAutorizacionS=$request->get('idAutorizacionI');
        $fechaS->save();
        $this->addArch($request,$fechaS->idFechaSA,$idFechaIA);
                
        return Redirect::to('escuela/archivador/oficiosI');

    }


public function addArch ($request,$idFechaSA,$idFechaIA)
    {

        if ($request->get('cont')=='1'){

            $archIn= new tbARchInterno;//llamar
            $archIn->tbarchExNombre=$request->get('tbOIDescripcion');
            $archIn->idArchEII=$request->get('idArchEII');
            $archIn->idArchTipoI=$request->get('idArchTipoI');
            $archIn->idFechaIA=$idFechaIA;
            $archIn->idFechaSA=$idFechaSA;
            $archIn->save();    
            return Redirect::to('escuela/archivador/oficiosI');

        }
        
        else{
            $archEx= new tbARchExterno;//llamar
            $archEx->tbarchExNombre=$request->get('tbOIDescripcion');
            $archEx->idArchEII=$request->get('idArchEII');
            $archEx->idArchTipoE=$request->get('idArchTipoI');
            $archEx->idFechaIA=$idFechaIA;
            $archEx->idFechaSA=$idFechaSA;
            $archEx->save();     
            return Redirect::to('escuela/archivador/oficiosI');

        }
        

    }


public function show ($idOficioI)
    {

    	return view("escuela.archivador.oficiosI",["oficioI"=>tbOficioI::findOrFail($idOficioI)]);

    }

    
public function edit($idOficioI)
    {

    	$oficioI=tbOficioI::findOrFail($idOficioI);
                
        $fechaI=DB::table('tbFechaIA')->get();
        
        return view("escuela.archivador.oficiosI.edit",["oficioI"=>$oficioI,"fechaI"=>$fechaI]);
    }




    
public function update(Request $request, $idOficioI)
    {
        $oficioI=tbOficioI::findOrFail($idOficioI);

        $oficioI->tbOIDescripcion=$request->get('tbOIDescripcion');
        
        /*seccion pdf */
        if (Input::hasFile('tbOIExaminar')){
         $file=Input::file('tbOIExaminar');
         $file->move(public_path().'/documentos/archivador/oficios/ingreso/',$file->getClientOriginalName());
         $oficioI->tbOIExaminar=$file->getClientOriginalName();
        }

        $oficioI->tbOINumOficio=$request->get('tbOINumOficio');

        $oficioI->update();
        $this->modFecha($oficioI->idOficioI,$request);

        return Redirect::to('escuela/archivador/oficiosI');
    }

//modificacion
    
public function modFecha ($idOficioI,$request)
    {

        // $fecha= new tbFechaIA;//llamar
        $fecha=tbFechaIA::findOrFail($request->get('idFechaIA'));
        $fecha->tbfiaFecha=$request->get('tbfiaFecha');
        $fecha->idOficioI=$idOficioI;
        $fecha->idAutorizacionI=$request->get('idAutorizacionI');
        $fecha->update();
        //$this->modFechaS($request,$fecha->idFechaIA,$idOficioI);
                
        return Redirect::to('escuela/archivador/oficiosI');

    }



//
public function destroy($idOficioI)
    {
        /*
        
        */
    	$coment=DB::table('tbFechaIA')->where('idOficioI','=',$idOficioI)->get();
        $coment->delete();

        $this->dest2($idOficioI);
    	return Redirect::to('escuela/archivador/oficiosI');
    	
    }

    public function dest2($idOficioI)
    {
        
        $com1=tbOficioI::find($idOficioI);
        //$coment->tbOINumOficio='0';
        $com1->delete();

        return Redirect::to('escuela/archivador/oficiosI');
        
    }



}
