<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use phpCAS;

class Controller extends BaseController
{
    use AuthorizesRequests, AuthorizesResources, DispatchesJobs, ValidatesRequests;
/*
	conf cas
*/
    protected function configCas(){

    	$casservername = 'seguridad.espoch.edu.ec';
        $casport = 443;
        $casbaseuri = '/cas';
        $caslogouturl = '/logout?service=';
        $casprotocol = 'https://';
        phpCAS::client(CAS_VERSION_3_0, $casservername, $casport, $casbaseuri);
        phpCAS::setNoCasServerValidation();
    }
}
