<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbCriterio;
use Illuminate\Support\Facades\Redirect;
use phpCAS;

use IndustrialWebpage\Http\Requests\CritFormRequest;

use DB;


class CritDocController extends Controller
{
    //
    


    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }
    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			
    		$criterio=DB::table('tbCriterio')
    		->orderby('idCriterio','asc')
    		->paginate(7);

    		return view ('escuela.autoevaluacion.CritDoc.index',["criterio"=>$criterio]);

    	}



    }
        
    //
}
