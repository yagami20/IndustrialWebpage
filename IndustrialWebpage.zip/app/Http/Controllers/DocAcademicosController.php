<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tbDescarga;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;
use IndustrialWebpage\Http\Requests\DescargaFromRequest;

use DB;

class DocAcademicosController extends Controller
{
   public function __construct()
    {


    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda
    		$descarga=DB::table('tbDescargas')->where('tbdTitulo','LIKE','%'.$query.'%')
    		->where ('tbdEstado','=','1')
    		->orderby('idDescarga','desc')
    		->paginate(3);

    		return view ('WebExterna.DocAcademicos.index',["descarga"=>$descarga,"searchText"=>$query]);

    	}



    }
    public function show ($idDescarga)
    {

        return view("WebExterna.DocAcademicos.show",["descarga"=>tbDescarga::findOrFail($idDescarga)]);

    }
    public function destroy($idDescarga)
    {

        $descarga=tbDescarga::findOrFail($idDescarga);

        $descarga->tbdEstado='0';

        $descarga->update();

        return Redirect::to('WebExterna/DocAcademicos'); 


    }
     

}

