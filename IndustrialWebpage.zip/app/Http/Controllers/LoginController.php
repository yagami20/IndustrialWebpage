<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//llamado
use Illuminate\Support\Facades\Redirect;

use phpCAS;
//soap
use SoapClient;
use SoapHeader;

class LoginController extends Controller
{
    //
    protected $authC;
    
    public function __construct()
    {
        
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
        	// echo "cas ";
        }
        
        
    }

    /*
		inicio configuracion cas
    */
		public function logueo()
		{
			$cedula=phpCAS::getAttribute('cedula');
			// echo $cedula; //obtener cedula
			$long=strlen($cedula)-1;//para quitar el último digito que se hace en la sig. linea
			 // echo "<br>".
			$cedula3='171961524-5';
			$cedula2=substr($cedula, 0, $long)."-".substr($cedula,-1);//se forma la nueva cadena 	
			$client = new SoapClient("http://academico.espoch.edu.ec/OAS_Interop/Seguridad.asmx?wsdl");
	        $headers=array();
	        $headers[] = new SoapHeader("http://academico.espoch.edu.ec/", 'credentials', array('username' => 'webmail', 'password' => 'webmail'));
	        // $result = $client->__soapCall("GetRolUsuarioCarrera", array("GetRolUsuarioCarrera" => array("login" =>$cedula2)), NULL, $headers);
	        $result = $client->__soapCall("GetRolUsuarioCarrera", array("GetRolUsuarioCarrera" => array("login" =>$cedula2)), NULL, $headers); 
	        $result=  $result->GetRolUsuarioCarreraResult->RolCarrera;
	        
	        // dd($result);
	        // for($i=0;$i<sizeof($result);$i++){
	        // 	if($result[$i]->CodigoCarrera=='EII'||$result[$i]->CodigoCarrera=='EIS'){
	        // 		if($result[$i]->NombreRol=='DOC'||$result[$i]->NombreRol=='EST'){
	        // 			echo "<br>".$cedula3;
	        // 		}
	        // 	}
	        // }
	        // dd($result[3]->CodigoCarrera);
	        //roles (DIRCAR,DOC,EST) +"CodigoCarrera": "EII"
	        // foreach ($result as $key ) {
	        // 	dd($key->CodigoCarrera);
        	//  	// dd($key->NombreRol);
        	// }
        	// unset($key);
			
        	// echo "<br>".$key->NombreRol; //ultimo rol
        	if($cedula=='1719615245'|| $cedula=='0601015688'){
        		return Redirect::to('escuela/autoevaluacion/criterio');
        	}
        	else{
	        for($i=0;$i<sizeof($result);$i++){
	        	// if($result[$i]->CodigoCarrera=='EII'||$result[$i]->CodigoCarrera=='EIS'){
	        	if($result[$i]->CodigoCarrera=='EII'|| $cedula=='0604188359'||$result[$i]->CodigoCarrera=='EIS'){
	        		if($result[$i]->NombreRol=='DOC'|| $cedula=='0604188359'){
	        			return Redirect::to('/docente');
	        			// return Redirect::to('/estudiante');	        			
	        		}
	        		else{
	        			
	        			
			        		if($result[$i]->NombreRol=='EST'){
			        			// return Redirect::to('/docente');
	        					return Redirect::to('/estudiante');	        			
	        				}
	        			
	        			
	        		}
	        	}
	        }	
        	}
        	
		}

		/*
		* funcion cierre
		*/
		public function cierre(){
			session_unset();
			  if (ini_get("session.use_cookies")) 
				{
				  $params = session_get_cookie_params();
				  setcookie(session_name(), '', time() - 42000,
				      $params["path"], $params["domain"],
				      $params["secure"], $params["httponly"]);
				}
			session_destroy();
			session_write_close(); 
			  // Session::flush();

			// header('Location: index.php');
			// route('/');
			header('Location: https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https://seguridad.espoch.edu.ec/cas/logout?service=http://localhost:8080/IndustrialWebpage/public');
			exit;
		}
	
    /*
	* redireccion
    */
    // public function redirectPath()
    //     {
    //     if (auth()->user()->hasRole('admin')) {
    //         return '/layouts/admin2';
            
    //     }
    //     else{
    //         if(auth()->user()->hasRole('docent')){
    //             return '/layouts/docente';
    //         }
    //     }

    //     return '/layouts/estudiante';
    //     }
}
