<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
use IndustrialWebpage\User;
use IndustrialWebpage\tbAsistencia;
use IndustrialWebpage\tbDetalleAsistencia;
use IndustrialWebpage\tbHoraFin;
use IndustrialWebpage\tbHoraInicio;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\AsistenciaFormRequest;
// use Carbon\Carbon;
use Carbon\Carbon;
use phpCAS;

use DB;

class AsistenciaControllerS extends Controller
{
    //
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }

    public function index(Request $request)
    {
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $date = Carbon::now();
            $dia=$date->toDateString();
            
             $asistencia=DB::table('tbAsistencia as tbA')
             ->join('tbDetalleAsistencia as tbD','tbD.idAsis','=','tbA.idAsis')
             ->join('tbHoraFin as tbH','tbH.idDetalle','=','tbD.idDetalle')
             ->select('tbA.tbaDescripcion as Dia','tbD.tbdFecha as Fecha','tbD.tbaCedula as cedula','tbD.tbaNombre as Nombre','tbD.tbaApellido as Apellido','tbH.tbhfHora as hora')
             ->where('tbA.tbaDescripcion','LIKE','%'.$query.'%')
             ->orwhere('tbD.tbaCedula','LIKE','%'.$query.'%')
             ->orderBy('tbD.tbaCedula','desc')
             ->paginate(7);
         return view ('escuela.AsistenciaS.index',["asistencia"=>$asistencia,"searchText"=>$query,"dia"=>$dia]);
     }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // $now=Carbon::now();

        return view ("escuela.AsistenciaS.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   public function store (AsistenciaFormRequest $request)
    {
       
       // $fechaActual=Carbon::now();
        $date = Carbon::now();
        $asistencia=new tbAsistencia;

        $asistencia->tbaDescripcion=$date->format('l jS ');

        $asistencia->save();
        $this->addFechaDetalle($asistencia->idAsis,$request,$date);

        return Redirect::to('escuela/AsistenciaS');
    }

    public function addFechaDetalle ($idAsis,$request,$date)
    {
        //
        $porciones = explode(" ", $request->get('tbaNombre'));
        //
        $fechaS= new tbDetalleAsistencia;//llamar
        $fechaS->tbdFecha=$date->toDateString();
        $fechaS->idAsis=$idAsis;
        $fechaS->tbaCedula=$request->get('tbaCedula');
        $fechaS->tbaNombre=$porciones[0];
        $fechaS->tbaApellido=$porciones[2];
        $fechaS->save();
        $this->addHoraS($fechaS->idDetalle,$date);
                
        return Redirect::to('escuela/AsistenciaS');
    }

    public function addHoraS ($idDetalle,$date)
    {
        $horaS= new tbHoraFin;//llamar
        $horaS->tbhfHora=$date->toTimeString();
        $horaS->idDetalle=$idDetalle;
        $horaS->save();
                
        return Redirect::to('escuela/AsistenciaS');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function show ($idAsis)
    {

        return view("escuela.AsistenciaS.show",["asistencia"=>tbAsistencia::findOrFail($idAsis)]);


    }
    

    public function destroy($id)
    {
        //
    }
}
