<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
//parte de llamado
use IndustrialWebpage\tBSilabo;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Response;

use IndustrialWebpage\Http\Requests\SilabFormRequest;
use phpCAS;
use DB; 


class SilaboController extends Controller
{
    //

    
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		
            $silabo=DB::table('tBSilabo as tbU')
            ->join('tbMateria as Tbt','Tbt.idMateria','=','tbU.idMateria')

            ->select('tbU.idSilabo','tbU.idMateria','tbU.tbsiDescripcion','tbU.tbsiDocumento','tbU.tbsiFecha','Tbt.tbmNombre as Materia', 'Tbt.tbmSemestre as Semestre', 'Tbt.tbmParalelo as Paralelo')
            
            ->where('tbU.tbsiDescripcion','LIKE','%'.$query.'%')
            ->orwhere('Tbt.tbmNombre','LIKE','%'.$query.'%')
            ->orwhere('tbU.tbsiFecha','LIKE','%'.$query.'%')
    		
            ->orderBy('tbU.idSilabo','asc')

    		->paginate(7);

    		return view ('escuela.seguimiento.silabo.index',["silabo"=>$silabo,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

        $materia=DB::table('tbMateria')->get();
        return view ("escuela.seguimiento.silabo.create",["materia"=>$materia]);
    }

    
public function store (SilabFormRequest $request)
    {
        $silabo=new tBSilabo;

        $silabo->idMateria=$request->get('idMateria');
        
        $silabo->tbsiDescripcion=$request->get('tbsiDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbsiDocumento')){
         $file=Input::file('tbsiDocumento');
         $file->move(public_path().'/documentos/seguimiento/silabo/',$file->getClientOriginalName());
         $silabo->tbsiDocumento=$file->getClientOriginalName();
        }

        $silabo->tbsiFecha=$request->get('tbsiFecha');

        
        $silabo->save();

        return Redirect::to('escuela/seguimiento/silabo');
    }


    
public function show ($idSilabo)
    {

    	return view("escuela.seguimiento.silabo.show",["silabo"=>tBSilabo::findOrFail($idSilabo)]);

    }

    
public function edit($idSilabo)
    {

    	$silabo=tBSilabo::findOrFail($idSilabo);
        $materia=DB::table('tbMateria')->get();
        return view("escuela.seguimiento.silabo.edit",["silabo"=>$silabo, "materia"=>$materia]);
    }




    
public function update(SilabFormRequest $request, $idSilabo)
    {
        $silabo=tBSilabo::findOrFail($idSilabo);

        $silabo->idMateria=$request->get('idMateria');
        
        $silabo->tbsiDescripcion=$request->get('tbsiDescripcion');

        
        /*seccion pdf */
        if (Input::hasFile('tbsiDocumento')){
         $file=Input::file('tbsiDocumento');
         $file->move(public_path().'/documentos/seguimiento/silabo/',$file->getClientOriginalName());
         $silabo->tbsiDocumento=$file->getClientOriginalName();
        }

        $silabo->tbsiFecha=$request->get('tbsiFecha');

        $silabo->update();

        return Redirect::to('escuela/seguimiento/silabo');
    }

    

public function destroy($idSilabo)
    {

    	
    }


}
