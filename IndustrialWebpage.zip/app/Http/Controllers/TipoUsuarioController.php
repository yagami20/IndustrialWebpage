<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;//

use IndustrialWebpage\Http\Requests;

use IndustrialWebpage\tbTipoUsuario;
use Illuminate\Support\Facades\Redirect;
//use Illuminate\Support\Facades\Input;

use IndustrialWebpage\Http\Requests\TipoUsuarioFormRequest;
use phpCAS;

use DB;


class TipoUsuarioController extends Controller
{
    //
     public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		$tipoUs=DB::table('tbTipoUsuario')->where('tbtuDescripcion','LIKE','%'.$query.'%')
            
            ->where ('tbtuEstado','=','1')
    		->orderBy('tbtuId','desc')

    		->paginate(7);

    		return view ('archivador.tipousuario.index',["tipousuario"=>$tipoUs,"searchText"=>$query]);

    	}



    }


    
public function create()
    {

    	return view ("archivador.tipousuario.create");


    }

    
public function store (TipoUsuarioFormRequest $request)
    {

    	$tipoUs=new tbTipoUsuario; //referencia modelo

        //$tipoUs->tbtuId=$request->get('tbtuId');

    	$tipoUs->tbtuDescripcion=$request->get('tbtuDescripcion');
    	$tipoUs->tbtuEstado='1';

    	$tipoUs->save();

    	return Redirect::to('archivador/tipousuario');


    }


    
public function show ($tbtuId)
    {

    	return view("archivador.tipousuario.show",["tipousuario"=>tbTipoUsuario::findOrFail($tbtuId)]);
        
    }

    
public function edit($tbtuId)
    {

    	return view("archivador.tipousuario.edit",["tipousuario"=>tbTipoUsuario::findOrFail($tbtuId)]);

    }

    
public function update(TipoUsuarioFormRequest $request, $tbtuId)
    {

    	$tipoUs=tbTipoUsuario::findOrFail($tbtuId);

    	$tipoUs->tbtuDescripcion=$request->get('tbtuDescripcion');
    	$tipoUs->tbtuEstado=$request->get('tbtuEstado');
    	
    	$tipoUs->update();

    	return Redirect::to('archivador/tipousuario');
    	
    }

    

public function destroy($tbtuId)
    {

    	$tipoUs=tbTipoUsuario::findOrFail($tbtuId);

    	$tipoUs->tbtuEstado='0';

    	$tipoUs->update();

    	return Redirect::to('archivador/tipousuario'); 


    }

}
