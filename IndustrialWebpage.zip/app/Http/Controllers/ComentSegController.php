<?php

namespace IndustrialWebpage\Http\Controllers;

use Illuminate\Http\Request;

use IndustrialWebpage\Http\Requests;
// parte llamado
use IndustrialWebpage\tBObservacion;
use IndustrialWebpage\tblSeguimientoP;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use phpCAS;

use IndustrialWebpage\Http\Requests\ObservFormRequest;

use DB;


class ComentSegController extends Controller
{
    //
	//

     
    public function __construct()
    {
        $this->configCas();
        
        if(phpCAS::forceAuthentication())
        {
            // echo "cas ";
        }
    }


    
public function index (Request $request)
    {

    	
    }

/*
    
public function create($idSeguimientoP)
    {

        $segped=tblSeguimientoP::findOrFail($idSeguimientoP);
        return view ("escuela.seguimiento.seguimientPed.obserSeguimiento.create");
        
    }
    

    
public function store (ObservFormRequest $request, $idSeguimientoP)
    {
        $coment=new tBObservacion;

        $segped=tblSeguimientoP::findOrFail($idSeguimientoP);

        $coment->tboDetalle=$request->get('tboDetalle');
        
        //seccion pdf //
        if (Input::hasFile('tboDocumento')){
         $file=Input::file('tboDocumento');
         $file->move(public_path().'/documentos/seguimiento/observacion/',$file->getClientOriginalName());
         $coment->tboDocumento=$file->getClientOriginalName();
        }

        $coment->tboEstado=$request->get('tboEstado');

        $coment->tboFecha=$request->get('tboFecha');

        $segped->idObservacion= $request->get('idObservacion');

        $coment->save();

        $segped->update();


        return Redirect::to('escuela/seguimiento/seguimientPed');
    }
*/
    


    
public function show ($idObservacion)
    {

    	return view("escuela.seguimiento.seguimientPed.obserSeguimiento.show",["coment"=>tBObservacion::findOrFail($idObservacion)]);

    }

    
public function edit($idSeguimientoP)
    {

    	$segped=tblSeguimientoP::findOrFail($idSeguimientoP);
        return view ("escuela.seguimiento.seguimientPed.obserSeguimiento.create",["segped"=>$segped]);
        
        
    }




    
public function update(ObservFormRequest $request, $idSeguimientoP)
    {
        $coment=new tBObservacion;

        $coment->tboDetalle=$request->get('tboDetalle');
        
        /*seccion pdf */
        if (Input::hasFile('tboDocumento')){
         $file=Input::file('tboDocumento');
         $file->move(public_path().'/documentos/seguimiento/observacion/',$file->getClientOriginalName());
         $coment->tboDocumento=$file->getClientOriginalName();
        }

        $coment->tboEstado=$request->get('tboEstado');

        $coment->tboFecha=$request->get('tboFecha');

        
              
        $coment->save();

        $this->destroy($coment->idObservacion,$idSeguimientoP);

        return Redirect::to('escuela/seguimiento/seguimientPed');
    }

    

public function destroy($idObservacion,$idSeguimientoP)
    {
    	$segped=tblSeguimientoP::findOrFail($idSeguimientoP);

        $segped->idObservacion= $idObservacion;

        $segped->update();

    	return Redirect::to('escuela/seguimiento/seguimientPed');
    }

}
