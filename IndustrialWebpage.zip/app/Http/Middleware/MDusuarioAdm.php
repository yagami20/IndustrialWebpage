<?php

namespace IndustrialWebpage\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Redirect;

class MDusuarioAdm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      if(!auth()->check()){ 
         return redirect('/');
        }
        else {
             if(auth()->user()->tbtuId!=1) {// no es administrador
            return redirect('layouts.admin');
            }
        }
        
        return $next($request);
        
       // $usuario_actual=\Auth::user();
       // if($usuario_actual->tbtuId!=1){
        // return view("mensajes.msj_rechazado")->with("msj","No tiene suficientes Privilegios para acceder a esta seccion");
        //}
       // return $next($request);;
    }
}
