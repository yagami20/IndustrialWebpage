<?php

namespace IndustrialWebpage\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Redirect;

class MDusuarioDoc
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
         if(!auth()->check()){ 
         return redirect('/');
        }
        else {
             if(auth()->user()->tbtuId!=3) {// no es administrador
            return redirect('layouts.admin');
            }
        }
        
        return $next($request);
        
       // $usuario_actual=\Auth::user();
        //if($usuario_actual->tbtuId!=3){
         //return view("mensajes.msj_rechazado")->with("msj","Esta seccion es solo visible para el usuario Docente <br/> usted aun no ha sido asignado como usuario docente , consulte al administrador del sistema");
        
        //}
        //return $next($request);
    }
}
