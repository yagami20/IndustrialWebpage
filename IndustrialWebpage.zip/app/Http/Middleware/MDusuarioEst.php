<?php

namespace IndustrialWebpage\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Redirect;

class MDusuarioEst
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
         if(!auth()->check()){ 
         return redirect('/');
        }
        else {
             if(auth()->user()->tbtuId!=4) {// no es administrador
            return redirect('layouts.admin');
            }
        }
        
        return $next($request);
    }
}
