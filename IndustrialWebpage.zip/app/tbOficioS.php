<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbOficioS extends Model
{
    //
    protected $table='tbOficioS';

    protected $primaryKey='idOficioS';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbOSDescripcion',  
          
        'tbOSNumOficio',
        'tbOSExaminar'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
