<?php

namespace IndustrialWebpage;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    //AQUI
    protected $table = 'users';
    protected $primaryKey='id';
    //
   // protected $fillable = [
     //   'name', 'email', 'password',
    //];
    protected $fillable =[  //creacion campos recibn valor
        
        'tbuCedula',

        'tbuNombres',
        
        'tbuApellidos',
        
        'email',
        
        'password',

        'tbuCorreoInstitucional',
        
        'tbuSexo',
        
        'tbuTelefono',
        
        'tbuFechaNacimiento',
        
        'tbuFoto',
        
        'tbuPais',
        
        'tbuCiudad',
        
        'tbuCurriculo',
        
        'tbuEstado',
        
        'tbtuId'
    
];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
     public function tbasistencias(){
        return $this->hasMany(tbAsistencia::class);
    }
}
