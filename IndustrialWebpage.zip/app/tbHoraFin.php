<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbHoraFin extends Model
{
    //
    protected $table='tbHoraFin';

    protected $primaryKey='idHoraFin';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        
        'idDetalle',

        'tbhfHora'

        
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
