<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbAutorizacionS extends Model
{
    //
    protected $table='tbAutorizacionS';

    protected $primaryKey='idAutorizacionS';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbASDescripcion', 
        
        'tbASNumOficio',
        'tbASExaminar'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
