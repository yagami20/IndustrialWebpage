<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tBSeguimiento extends Model
{
    //
     protected $table='tBSeguimiento';

    protected $primaryKey='idSeguimiento';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idMateria',
        
        'tbseDescripcion',

        'tbseDocumento',

        'tbseFecha'  
         
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
