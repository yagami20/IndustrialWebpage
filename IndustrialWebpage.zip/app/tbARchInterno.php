<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbARchInterno extends Model
{
    //
    protected $table='tbARchInterno';

    protected $primaryKey='idArchIn';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbarchExNombre',
        
        'idArchEII',
        'idArchTipoI',
        'idFechaIA',
        'idFechaSA'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
