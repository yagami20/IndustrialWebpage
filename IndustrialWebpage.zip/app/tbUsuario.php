<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbUsuario extends Model
{
    //
    protected $table='tbUsuario';

    protected $primaryKey='tbuIdu';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbuCedula',

        'tbuNombres',
    	
        'tbuApellidos',
    	
        'email',
        
        'password',

        'remember_token',

        'tbuCorreoInstitucional',
    	
        'tbuSexo',
    	
        'tbuTelefono',
    	
        'tbuFechaNacimiento',
    	
        'tbuFoto',
    	
        'tbuPais',
    	
        'tbuCiudad',
    	
        'tbuCurriculo',
    	
        'tbuEstado',
    	
        'tbtuId'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        'password', 'remember_token',
    ];

}
