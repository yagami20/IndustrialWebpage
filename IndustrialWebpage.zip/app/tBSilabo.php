<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tBSilabo extends Model
{
    //
    protected $table='tBSilabo';

    protected $primaryKey='idSilabo';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idMateria',
        
        'tbsiDescripcion',

        'tbsiDocumento',

        'tbsiFecha'
           
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
