<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbArchTipoI extends Model
{
    //
    protected $table='tbArchTipoI';

    protected $primaryKey='idArchTipoI';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbarchINombre',
        
        'tbarchIEstado' 
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
