<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbAsistencia extends Model
{
    //
    protected $table='tbAsistencia';

    protected $primaryKey='idAsis'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        
        'tbaDescripcion'

        
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
