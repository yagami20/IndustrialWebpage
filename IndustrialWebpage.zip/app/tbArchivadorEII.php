<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbArchivadorEII extends Model
{
    //

    protected $table='tbArchivadorEII';

    protected $primaryKey='idArchEII';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbaeiiNombre',
        
        'idEscuela'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
