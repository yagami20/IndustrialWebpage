<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbAutorizacionI extends Model
{
    //
    protected $table='tbAutorizacionI';

    protected $primaryKey='idAutorizacionI'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbAIDescripcion',  
        
        'tbAINumOficio',
        'tbAIExaminar' 
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
