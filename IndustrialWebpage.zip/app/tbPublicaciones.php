<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;

class tbPublicaciones extends Model implements SluggableInterface
{
     use SluggableTrait;

    /**
     * Sluggable configuration.
     *
     * @var array
     */
    protected $sluggable =[
        'build_from'      => 'tbpTitulo',
        'save_to'         => 'slug',
       
     ];
    //
    protected $table='tbPublicaciones';

    protected $primaryKey='idPublicacion';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbpTitulo',
        'tbpDescripcion',

        'tbpFoto',
    	
        'tbpExaminar',
    	
        'tbpFecha',
        
        'tbpEstado',

        'idEscuela'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];


}
