<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbEscuela extends Model
{
    //
    protected $table='tbEscuela';

    protected $primaryKey='idEscuela';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbeNombre',

        'tbeDireccion',
    	
        'tbeTelefono'


    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

}
