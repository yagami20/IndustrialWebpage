<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbDescarga extends Model
{
    //
    protected $table='tbDescargas';

    protected $primaryKey='idDescarga';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbdTitulo',
        'tbdDescripcion',
   	
        'tbdExaminar',
    	
        'tbdFecha',
        
        'tbdEstado',

        'idEscuela',
        
        'tbdSeccion'

    
];
 protected  $guarded =[
 //atributos tipo warded

    
];

}
