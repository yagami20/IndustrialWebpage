<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbDetalleAsistencia extends Model
{
    //
    protected $table='tbDetalleAsistencia';

    protected $primaryKey='idDetalle';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        
        'idAsis', 

        'tbdFecha',

        'tbaCedula',

        'tbaNombre',

        'tbaApellido'

        
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
