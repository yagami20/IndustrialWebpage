<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbTipoUsuario extends Model
{
    //
    protected $table='tbTipoUsuario';

    protected $primaryKey='tbtuId';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tbtuDescripcion',
        
        'tbtuEstado'
        
    	];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
