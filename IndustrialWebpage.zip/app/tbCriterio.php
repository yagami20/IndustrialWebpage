<?php

namespace IndustrialWebpage;

use Illuminate\Database\Eloquent\Model;

class tbCriterio extends Model
{
    //
     protected $table='tbCriterio';

    protected $primaryKey='idCriterio';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idEscuela',

        'tbcDescripcion',
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];
}
