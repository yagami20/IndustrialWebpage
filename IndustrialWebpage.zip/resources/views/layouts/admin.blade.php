<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Facultad Mecanica | Escuela Ing. Industrial</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="{{asset('css_plantilla_antigua/css/bootstrap.min.css')}}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset('css_plantilla_antigua/css/font-awesome.css')}}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{asset('css_plantilla_antigua/css/AdminLTE.min.css')}}">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="{{asset('css_plantilla_antigua/css/_all-skins.min.css')}}">
    <link rel="apple-touch-icon" href="{{asset('css_plantilla_antigua/img/apple-touch-icon.png')}}">
    <link rel="shortcut icon" href="{{asset('css_plantilla_antigua/img/favicon.ico')}}">
     <link rel="stylesheet" href="{{asset('css_plantilla_antigua/css/bootstrap-datetimepicker.min.css')}}">  

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <header class="main-header">

        <!-- Logo -->
        <a href="{{ url('/') }}" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>EI</b>I</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Industrial</b></span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Navegación</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <small class="bg-green">Online</small>
                  <span class="hidden-xs">{{phpCAS::getAttribute('name')}}</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    
                    <p>
                      Usuario Administrador - Desarrollador Software <!--descrip us. -->
                    </p>
                    <p>Cedula: {{phpCAS::getAttribute('cedula')}}</p>
                    <p>{{phpCAS::getAttribute('upn')}}</p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    
                    <div class="pull-right">
                      <a href="{{asset('/logout')}}" class="btn btn-default btn-flat">Cerrar</a>
                    </div>
                  </li>
                </ul>
              </li>
              
            </ul>
          </div>

        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
            
            {{--  --}}
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Usuarios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <{{-- li><a href="{{url('archivador/uAdministrativo')}}"><i class="fa fa-circle-o"></i>Administrativo</a></li> --}}
                {{-- <li><a href="{{url('archivador/uDocente')}}"><i class="fa fa-circle-o"></i>Docente</a></li>
                <li><a href="{{url('archivador/uEstudiante')}}"><i class="fa fa-circle-o"></i>Estudiante</a></li> --}}
                <li><a href="{{url('escuela/archivador/oficiosI')}}"><i class="fa fa-circle-o"></i>Oficios Ingreso</a></li>
                <li><a href="{{url('escuela/archivador/oficiosS')}}"><i class="fa fa-circle-o"></i>Oficios Salida</a></li>
                <li><a href="{{url('escuela/archivador/autorI')}}"><i class="fa fa-circle-o"></i>Autorizaciones Ingreso</a></li>
                <li><a href="{{url('escuela/archivador/autorS')}}"><i class="fa fa-circle-o"></i>Autorizaciones Salida</a></li>
                <li><a href="{{url('escuela/archivador/busquedaO')}}"><i class="fa fa-circle-o"></i>Busqueda Oficio Fechas</a></li>
                <li><a href="{{url('escuela/archivador/busquedaA')}}"><i class="fa fa-circle-o"></i>Busqueda Autorizacion Fechas</a></li> 
              </ul>
            </li>

            
            
            <!-- lista icono-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Publicaciones</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/publicaciones')}}"><i class="fa fa-circle-o"></i>Ingresar</a></li>
              </ul>
            </li>
            <!-- -->

            <!-- lista autoevaluacion-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i>
                <span>Autoevaluacion</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/autoevaluacion/criterio')}}"><i class="fa fa-circle-o"></i>Criterio</a></li>
                <li><a href="{{url('escuela/autoevaluacion/subcriterio')}}"><i class="fa fa-circle-o"></i>Subcriterio</a></li>
                <li><a href="{{url('escuela/autoevaluacion/indicador')}}"><i class="fa fa-circle-o"></i>Indicador</a></li>
                <li><a href="{{url('escuela/autoevaluacion/subindicador')}}"><i class="fa fa-circle-o"></i>SubIndicador</a></li>
                <li><a href="{{url('escuela/autoevaluacion/pdf')}}" target="blank"><i class="fa fa-circle-o"></i>Reporte</a></li>
                <li><a href="{{url('escuela/autoevaluacion/BusqAut')}}" target="blank"><i class="fa fa-circle-o"></i>Busqueda</a></li>
                
              </ul>
            </li>
            <!-- -->

            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Asistencia</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/AsistenciaI')}}"><i class="fa fa-circle-o"></i> Ingresos</a></li>
                <li><a href="{{url('escuela/AsistenciaS')}}"><i class="fa fa-circle-o"></i> Salidas</a></li>
                <li><a href="{{url('escuela/AsisBusqueda/busquedaO')}}"><i class="fa fa-circle-o"></i> Reporte Asistencia</a></li>
                <li><a href="{{url('escuela/AsisBusqueda/busquedaI')}}"><i class="fa fa-circle-o"></i> Reporte Asis. Individual</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-shopping-cart"></i>
                <span>Seguimiento</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/seguimiento/materia')}}"><i class="fa fa-circle-o"></i> Materias</a></li>
                <li><a href="{{url('escuela/seguimiento/silabo')}}"><i class="fa fa-circle-o"></i> Silabos</a></li>
                <li><a href="{{url('escuela/seguimiento/planificacion')}}"><i class="fa fa-circle-o"></i> Planificaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/seguimientos')}}"><i class="fa fa-circle-o"></i> Seguimientos</a></li>
                <li><a href="{{url('escuela/seguimiento/observacion')}}"><i class="fa fa-circle-o"></i> Observaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/seguimientPed')}}"><i class="fa fa-circle-o"></i> Seguimiento Pedagogico</a></li>
              </ul>
            </li>
                       
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Download</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/descargador')}}"><i class="fa fa-circle-o"></i>Publicaciones</a></li>
                <li><a href="{{url('escuela/descargadorS')}}"><i class="fa fa-circle-o"></i>Silabos</a></li>
                <li><a href="{{url('escuela/descargadorP')}}"><i class="fa fa-circle-o"></i>Planificaciones</a></li>

                
                
              </ul>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-plus-square"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-info-circle"></i> <span>Acerca De...</span>
                <small class="label pull-right bg-yellow">IT</small>
              </a>
            </li>
                        
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>





       <!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        
        <!-- Main content -->
        <section class="content">
          
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Sistema Administrador</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                      <div class="col-md-12">
                              <!--Contenido-->
                              @yield('contenido')
                              <!--Fin Contenido-->
                           </div>
                        </div>
                        
                      </div>
                    </div><!-- /.row -->
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <!--Fin-Contenido-->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2017-2022 <a href="www.incanatoit.com">Industrial - ESPOCH</a>.</strong> All rights reserved.
      </footer>

      
    <!-- jQuery 2.1.4 -->
    <script src="{{asset('css_plantilla_antigua/js/jQuery-2.1.4.min.js')}}"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="{{asset('css_plantilla_antigua/js/bootstrap.min.js')}}"></script>
    <!-- AdminLTE App -->
    <script src="{{asset('css_plantilla_antigua/js/app.min.js')}}"></script>
   <script src="{{asset('css_plantilla_antigua/js/moment.min.js')}}"></script>
  <script src="{{asset('css_plantilla_antigua/js/bootstrap-datetimepicker.min.js')}}"></script>
   <script src="{{asset('css_plantilla_antigua/js/bootstrap-datetimepicker.es.js')}}"></script>
   <script type="text/javascript">
     $('#divMiCalendario').datetimepicker({
          format:'YYYY-MM-DD HH:mm'       
      });
      $('#divMiCalendario').data("DateTimePicker").show();
   </script>
   <!-- javascript del sistema laravel -->
   <script src="{{asset('js/sistemalaravel.js')}}"></script>

   <script src="{{ asset('vendor/ckeditor/ckeditor.js') }}"></script>
    
  </body>
</html>
