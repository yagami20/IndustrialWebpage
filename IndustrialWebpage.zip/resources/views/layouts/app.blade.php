<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title')-Escuela Ingenieria Industrial</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">

    <!-- Estilos CSS personalizados -->
    <link rel="stylesheet" href="{{asset('css/estilos.css')}}">  
    <link rel="stylesheet" href="{{asset('css/stilosencabezado.css')}}">
    <link rel="stylesheet" href="{{asset('font-awesome/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/estilosVideo.css')}}">
    <link rel="stylesheet" href="{{asset('css/estilosVideo.css')}}">
    <link href="{{asset('css/personalizado.css')}}" rel="stylesheet">
    <link href="{{asset('lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">
    <!-- jquery -->
    <script type="text/javascript"> 
        $(document).ready(function () {
          //Código jquery para realizar alguna acción
        });
    </script>

    <!-- fin stilos -->

</head>
<body >
 
    <div class="container-fluid " align="center">
        
    @include('shared.header')
    

    @yield('content')


    <footer id="footer-main">
        <div class="container">
            <div class="row">
                <div class="col-sm-3" align="center">
                   <h5 align="center">ESCUELA DE INGENIERIA INDUSTRIAL</h5>
                  <a href="{{ url('/') }}" > <img class="mediana1" class="fixed-botton" class="img-fluid" class="rounded " src="{{ asset('img/sello.jpg') }}" alt="responsive SelloEii" ></a>
                </div>
                <div class="col-sm-3" align="center" >
                    <ul class="list-unstyled" ">
                       <h5>INSTITUCION:</h5>
                        <li><a href="{{ url('WebExterna/Facultad') }}" >Informacion General</a></li>
                        <li><a href="">Autoridades</a></li>
                       
                    </ul>
                </div>
                <div class="col-sm-3" align="center">
                    <ul class="list-unstyled">
                      <h5 >FACULTADES:</h5>
                        <li ><a href=""><p>Escuela Ingenieria Industrial - EII </p></a></li>
                        <li><a href=""><p>Escuela Ingenieria Automotriz - EIA</p></a></li>
                        <li><a href="">Escuela Ingenieria de Mantenimiento- EIDM</a></li>
                        <li><a href="">Escuela Ingenieria Mecanica - EIM</a></li>
                    </ul>
                </div>
                <div class="col-sm-3" align="center">
                    <h5 align="center">INFORMACION:</h5>
                    <p>Escuela Superior Politécnica de Chimborazo <br>Escuela de Ingenieria Industrial <br>Riobamba - Ecuador</p>
                    <p >Dirección Panamericana Sur 1 1/2 | Teléfono: 593 (03) 2 998-200 | Telefax: (03) 2 317-001 | Código Postal: EC060155 | Créditos</p>
                </div>
            </div>
        </div>
    </footer>
    </div>

    

    

    

</body>
<!-- jQuery first, then Bootstrap JS. -->
<script src="{{asset('js/config.js')}}"></script>
    <script src="{{asset('js/jquery-3.1.1.min.js')}}"></script>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>
    <script src="{{asset('js/general.js')}}"></script>
    <script src="{{asset('js/mainvideo.js')}}"></script>
    <script src="{{asset('js/jquery.nivo.slider.js')}}"></script>
    <!-- fin script -->
      <script src="{{asset('lib/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('lib/jquery/jquery-migrate.min.js')}}"></script>
  <script src="{{asset('lib/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('lib/easing/easing.min.js')}}"></script>
  <script src="{{asset('lib/superfish/hoverIntent.js')}}"></script>
  <script src="{{asset('lib/superfish/superfish.min.js')}}"></script>
  <script src="{{asset('lib/wow/wow.min.js')}}"></script>
  <script src="{{asset('lib/waypoints/waypoints.min.js')}}"></script>
  <script src="{{asset('lib/counterup/counterup.min.js')}}"></script>
  <script src="{{asset('lib/owlcarousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('lib/isotope/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('lib/lightbox/js/lightbox.min.js')}}"></script>
  <script src="{{asset('lib/touchSwipe/jquery.touchSwipe.min.js')}}"></script>
  <!-- Contact Form JavaScript File -->
  <script src="{{asset('contactform/contactform.js')}}"></script>

  <!-- Template Main Javascript File -->
  <script src="{{asset('js/main.js')}}"></script>
  
  <script src="{{ asset('vendor/ckeditor/ckeditor.js') }}"></script>

</html>

