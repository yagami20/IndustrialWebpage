@extends ('layouts.admin')
@section ('contenido')

	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Indicador: {{$indicador->tbinDescripcion}}</h3>

			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($indicador,['method'=>'PATCH','route'=>['escuela.autoevaluacion.indicador.update',$indicador->idIndicador], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>SubCriterio</label>
					<select name="idSubcriterio" class="form-control">
						@foreach($subcriterio as $tpu)
						<option value="{{$tpu->idSubcriterio}}" readonly="readonly" selected>{{$tpu->tbscDescripcion}}</option>
						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<!--Fecha-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbinDescripcion"> Nombre Subcriterio:</label>
				<input type="text" name="tbinDescripcion" required value="{{$indicador->tbinDescripcion}}" class="form-control" placeholder="Fecha...">
			</div>	
			</div>
			<!--Examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbinDocumento"> PDF</label>
				<div class="from-group">
				@if(($indicador->tbinDocumento)!="")
				
				<!-- ver archivo-->
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				<div class="from-group">
				<iframe src="/documentos/autoevaluacion/indicador/<?=  $indicador->tbinDocumento;   ?>" height="200px" width="480px" > archivo</iframe>
				</div>
				</div>

				<input type="file" name="tbinDocumento" class="form-control" >

				@endif	
				</div>
				
			</div>	
			</div>
			<!--Fecha-->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection