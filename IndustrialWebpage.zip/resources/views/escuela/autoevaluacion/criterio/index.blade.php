@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Criterios <a href="criterio/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.autoevaluacion.criterio.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Criterio</th>
		 			
		 			<th>Descripcion</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($criterio as $usd) 
		 		<tr>
		 			
		 			<td>{{$usd->idCriterio}}</td>
		 			
		 			<td>{{$usd->tbcDescripcion}}</td>
		 			<td>
		 				<a href="{{URL::action('CriterioController@edit',$usd->idCriterio)}}"><button class="btn btn-info">Editar</button></a>
		 				<!-- <a href="{{route('autoevaluacion.show', [$usd->idCriterio])}}"><button class="btn btn-primary">Subindicador</button></a> -->
		 			</td>
		 			
		 		</tr>
		 		@endforeach

		 	</table>
		 </div>
		 {{$criterio->render()}}
	</div>		
</div>


@endsection