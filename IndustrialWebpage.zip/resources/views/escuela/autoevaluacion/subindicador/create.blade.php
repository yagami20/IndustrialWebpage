@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo SubIndicador</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'escuela/autoevaluacion/subindicador','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}

		<div class="row">
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<!-- seccion subCriterio -->
			
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Indicador</label>
					<select name="idIndicador" class="form-control">
						@foreach($indicador as $tps)
						<option value="{{$tps->idIndicador}}">{{$tps->tbinDescripcion}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!-- -->
			<!-- Fecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiDescripcion"> Descripcion</label>
				<input type="text" name="tbsubiDescripcion" required value="{{old('tbsubiDescripcion')}}" class="form-control" placeholder="Descripcion...">
			</div>	
			</div>
			<!-- -->
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiDocumento"> Documento Subindicador</label>
				<input type="file" name="tbsubiDocumento" class="form-control" placeholder="Curriculo..." >
			</div>	
			</div>
			<!-- -->
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiTabla"> Documento tabla Subindicador</label>
				<input type="file" name="tbsubiTabla" class="form-control" placeholder="Curriculo..." >
			</div>	
			</div>
			<!-- -->
			<!-- Fecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiFecha"> Fecha Ingreso Documentacion</label>
				<input type="text" name="tbsubiFecha" required value="{{old('tbsubiFecha')}}" class="form-control" placeholder="Fecha...">
			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		
@endsection