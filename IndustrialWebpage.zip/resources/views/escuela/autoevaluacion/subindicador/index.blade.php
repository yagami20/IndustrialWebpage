@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de SubIndicadores <a href="subindicador/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.autoevaluacion.subindicador.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Criterio</th>
		 			<th>Subcriterio</th>
		 			<th>Indicador</th>
		 			<th>SubIndicador</th>
		 			<!-- <th>Documento</th> -->
		 			<!-- <th>Tabla</th> -->
		 			<th>Fecha</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($subindicador as $usd) 
		 		<tr>
		 			
		 			<td>{{$usd->DesC}}</td>
		 			<td>{{$usd->DesSC}}</td>
		 			<td>{{$usd->DesIn}}</td>
		 			<td>{{$usd->DesSI}}</td>
		 			<!-- <td>{{$usd->tbsubiDocumento}}</td> -->
		 			<!-- <td>{{$usd->tbsubiTabla}}</td> -->
		 			<td>{{$usd->tbsubiFecha}}</td>
		 			
		 			<td>
		 				<a href="{{URL::action('SubindicController@edit',$usd->idSubindicador)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$usd->idSubindicador}}" data-toggle="modal"><button class="btn btn-success">Documento</button></a>
		 				<a href="" data-target="#modal-tabla-{{$usd->idSubindicador}}" data-toggle="modal"><button class="btn btn-success">Tabla</button></a>
		 				
		 			</td>
		 			
		 		</tr>
		 		@include('escuela.autoevaluacion.subindicador.modal')
		 		@include('escuela.autoevaluacion.subindicador.modal2')
		 		@endforeach

		 	</table>
		 </div>
		 {{$subindicador->render()}}
	</div>		
</div>


@endsection