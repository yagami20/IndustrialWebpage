@extends ('layouts.admin')
@section ('contenido')

	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar SubIndicador: {{$subindicador->tbsubiDescripcion}}</h3>

			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($subindicador,['method'=>'PATCH','route'=>['escuela.autoevaluacion.subindicador.update',$subindicador->idSubindicador], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Indicador</label>
					<select name="idIndicador" class="form-control">
						@foreach($indicador as $tpu)
						<option value="{{$tpu->idIndicador}}" readonly="readonly" selected>{{$tpu->tbinDescripcion}}</option>
						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<!--Fecha-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiDescripcion"> descripcion SubIndicador:</label>
				<input type="text" name="tbsubiDescripcion" required value="{{$subindicador->tbsubiDescripcion}}" class="form-control" placeholder="Fecha...">
			</div>	
			</div>
			<!--Examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiDocumento"> PDF</label>
				<div class="from-group">
				@if(($subindicador->tbsubiDocumento)!="")
				
				<!-- ver archivo-->
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				<div class="from-group">
				<iframe src="/documentos/autoevaluacion/subindicador/documento/<?=  $subindicador->tbsubiDocumento;   ?>" height="200px" width="480px" > archivo</iframe>
				</div>
				</div>

				<input type="file" name="tbsubiDocumento" class="form-control" >

				@endif	
				</div>
				
			</div>	
			</div>
			<!--Fecha-->
			<!--tabla -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiTabla"> PDF</label>
				<div class="from-group">
				@if(($subindicador->tbsubiTabla)!="")
				
				<!-- ver archivo-->
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				<div class="from-group">
				<iframe src="/documentos/autoevaluacion/subindicador/tabla/<?=  $subindicador->tbsubiTabla;   ?>" height="200px" width="480px" > archivo</iframe>
				</div>
				</div>

				<input type="file" name="tbsubiTabla" class="form-control" >

				@endif	
				</div>
				
			</div>	
			</div>
			<!--Fecha-->
			<!--Fecha-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsubiFecha"> descripcion SubIndicador:</label>
				<input type="text" name="tbsubiFecha" required value="{{$subindicador->tbsubiFecha}}" class="form-control" placeholder="Fecha...">
			</div>	
			</div>
			<!--Examinar -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection