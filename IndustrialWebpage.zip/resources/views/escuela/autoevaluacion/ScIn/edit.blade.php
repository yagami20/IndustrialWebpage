@extends ('layouts.docente')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Indicadores <a href="{{URL::action('IndicadorController@create')}}"><button class="btn btn-success">Nuevo</button></a></h3>
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Criterio</th>
		 			<th>Subcriterio</th>
		 			<th>Indicador</th>
		 			<!-- <th>Documento</th> -->
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($indicador as $usd) 
		 		<tr>
		 			
		 			<td>{{$usd->DesC}}</td>
		 			<td>{{$usd->DesSC}}</td>
		 			<td>{{$usd->tbinDescripcion}}</td>
		 			<!-- <td>{{$usd->tbinDocumento}}</td> -->
		 			<td>
		 				<a href="{{route('subindicadores.show', [$usd->idIndicador])}}"><button class="btn btn-primary">SubIndicador</button></a>
		 				<a href="{{URL::action('IndicadorController@edit',$usd->idIndicador)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$usd->idIndicador}}" data-toggle="modal"><button class="btn btn-success">Ver Documento</button></a>
		 				
		 			</td>
		 			
		 		</tr>
		 		@include('escuela.autoevaluacion.indicador.modal')
		 		@endforeach

		 	</table>
		 </div>
		 {{$indicador->render()}}
	</div>		
</div>


@endsection