@extends ('layouts.admin')
@section ('contenido')

	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3 align="center">Editar Publicacion</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($publicacion,['method'=>'PATCH','route'=>['escuela.publicaciones.update',$publicacion->idPublicacion], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- -->
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpTitulo">Titulo </label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbpTitulo" rows="5" cols="90">{{$publicacion->tbpTitulo}}</textarea>	
				</div>
				
			</div>	
			</div>
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
			<div class="from-group">
				<label for="tbpDescripcion">Descripcion </label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbpDescripcion" id="bodyField" rows="10" cols="80">{!! $publicacion->tbpDescripcion !!}</textarea>
				
				@ckeditor ('bodyField', ['height' => 300],['width' => 100])
				</div>
				
			</div>	
			</div>
			<!--Foto -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group"> 
				<label for="tbpFoto"> Foto</label>
				<input type="file" name="tbpFoto" class="form-control" >
				@if(($publicacion->tbpFoto)!="")
				<img src="{{asset('/imagenes/publicaciones/'.$publicacion->tbpFoto)}}" height="100px" width="100px">
				@endif
			</div>	
			</div>
			<!--Examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpExaminar"> PDF</label>
				<div class="from-group">
				@if(($publicacion->tbpExaminar)!="")
				
				<!-- ver archivo-->
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				<div class="from-group">
				<iframe src="/documentos/curriculo/<?=  $publicacion->tbpExaminar;   ?>" height="200px" width="480px" > archivo</iframe>
				</div>
				</div>

				<!--descargar archivo-->

				<!--<a href="descargar_publicacion/<?=  $publicacion->idPublicacion;   ?>"  ><button class="btn  btn-success btn-xs">Descargar</button></a> -->

				<input type="file" name="tbpExaminar" class="form-control" >

				@endif	
				</div>
				
			</div>	
			</div>
			<!--Fecha-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpFecha"> Fecha</label>
				<input type="text" name="tbpFecha" required value="{{$publicacion->tbpFecha}}" class="form-control" placeholder="Fecha...">
			</div>	
			</div>
			
			<!--Estado-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpEstado"> Estado</label>
				<input type="text" name="tbpEstado" required value="1" readonly="readonly" class="form-control">
				<!-- <input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->
			</div>	
			</div>
			<!--IDESCUELA-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!--Valorizacion -->
					<label>Escuela</label>
					<select name="idEscuela" class="form-control">
						@foreach($escuela as $tpu)
						@if($tpu->idEscuela=='1')
						<option value="{{$tpu->idEscuela}}" readonly="readonly" selected>{{$tpu->tbeNombre}}</option>
						@endif

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection