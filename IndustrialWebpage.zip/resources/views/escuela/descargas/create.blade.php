@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nueva Documento Academico</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'escuela/descargas','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}

		<div class="row">
			<!--Titulo id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdTitulo"> Titulo</label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbdTitulo" rows="4" cols="80">Titulo Documento Academico</textarea>	
				</div>
				
			</div>	
			</div>
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdDescripcion"> Descripcion</label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbdDescripcion" rows="4" cols="80">Escribe aquí una Descripcion corta..</textarea>	
				</div>
				
			</div>	
			</div>
			
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdExaminar"> Archivo Pdf</label>
				<input type="file" name="tbdExaminar" class="form-control" placeholder="Archivo Pdf..." >
			</div>	
			</div>
			<!-- Fecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<fieldset>
           <label for="tbdFecha"> Fecha</label>
                  <div class='input-group date' id='divMiCalendario'>
                      <input type='text' name="tbdFecha" required value="{{old('tbdFecha')}}" class="form-control"  readonly/>
                      <span class="input-group-addon">
                      <i class="fa fa-calendar" aria-hidden="false"></i>
                      </span>
                  </div>
          </fieldset>	
			</div>
			<!-- -->
			<!-- seccion tbtipus -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Escuela</label>
					<select name="idEscuela" class="form-control">
						@foreach($escuela as $tpu)
						@if($tpu->idEscuela=='1')
						<option value="{{$tpu->idEscuela}}" readonly="readonly" selected>{{$tpu->tbeNombre}}</option>
						@endif

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdEstado"> Estado</label>
				<input type="text" name="tbdEstado" required value="1" readonly="readonly" class="form-control">
				<!-- <input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4">
			<div class="from-group">
				<label for="tbdSeccion">Publicar el Archivo en: </label>

				<!-- <input type="text" name="tbdEstado" required value="1" readonly="readonly" class="form-control">
				<input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->

				 
                      
                     
                       <select id="tbdSeccion" name="tbdSeccion" class="form-control">

							<option value="1 ">Documentos Academicos</option>
							<option value="2 ">Carrera</option>
							
                     
                      </select>


			</div>	
			</div>
			<!-- -->
		</div>
			
			<br><div class="form-group" align="center">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		
@endsection