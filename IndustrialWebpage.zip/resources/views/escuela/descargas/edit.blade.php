@extends ('layouts.admin')
@section ('contenido')

	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Documento Academico: {{$descarga->tbdDescripcion}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($descarga,['method'=>'PATCH','route'=>['escuela.descargas.update',$descarga->idDescarga], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- -->
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdTitulo">Titulo </label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbdTitulo" rows="4" cols="60">{{$descarga->tbdTitulo}}</textarea>	
				</div>
				
			</div>	
			</div>
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdDescripcion">Descripcion </label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbdDescripcion" rows="4" cols="60">{{$descarga->tbdDescripcion}}</textarea>	
				</div>
				
			</div>	
			</div>
		
			<!--Examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdExaminar"> Documento PDF</label>
				<div class="from-group">
				@if(($descarga->tbdExaminar)!="")
				
				<!-- ver archivo-->
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				<div class="from-group">
				<iframe src="/documentos/curriculo/<?=  $descarga->tbdExaminar;   ?>" height="200px" width="480px" > archivo</iframe>
				</div>
				</div>

				

				<input type="file" name="tbdExaminar" class="form-control" >

				@endif	
				</div>
				
			</div>	
			</div>
			<!--Fecha-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			
			<fieldset>
           <label for="tbdFecha"> Fecha</label>
                  <div class='input-group date' id='divMiCalendario'>
                      <input type='text' name="tbdFecha" required value="{{old('$descarga->tbdFecha')}}" class="form-control"  readonly/>
                      <span class="input-group-addon">
                      <i class="fa fa-calendar" aria-hidden="false"></i>
                      </span>
                  </div>
          </fieldset>	
			</div>
			
			<!--Estado-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbdEstado"> Estado</label>
				<input type="text" name="tbdEstado" required value="1" readonly="readonly" class="form-control">
				<!-- <input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->
			</div>	
			</div>
			<!--IDESCUELA-->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!--Valorizacion -->
					<label>Escuela</label>
					<select name="idEscuela" class="form-control">
						@foreach($escuela as $tpu)
						@if($tpu->idEscuela=='1')
						<option value="{{$tpu->idEscuela}}" readonly="readonly" selected>{{$tpu->tbeNombre}}</option>
						@endif

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-4 col-sm-4 col-md-4 col-xs-4">
			<div class="from-group">
				<label for="tbdSeccion">Publicar el Archivo en: </label>

				<!-- <input type="text" name="tbdEstado" required value="1" readonly="readonly" class="form-control">
				<input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->

				 
                      
                     
                       <select id="tbdSeccion" name="tbdSeccion" class="form-control">

							<option value="1 ">Documentos Academicos</option>
							<option value="2 ">Carrera</option>
							
                     
                      </select>


			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group" align="center">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection