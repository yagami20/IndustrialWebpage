@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Documentos Academicos <a href="descargas/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.descargas.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>No</th>
		 			<th>Titulo</th>
		 			<th>Descripcion</th>
		 					 			
		 			<th>Fecha</th>
		 			<!-- <th>Escuela</th> -->
		 			<!-- <th>Estado</th> -->
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($descarga as $usd) 
		 		@if ($usd->tbdEstado=='1')
		 		<tr>
		 			
		 			<td>{{$usd->idDescarga}}</td>
		 			<td>{{$usd->tbdTitulo}}</td>
		 			<td>{{$usd->tbdDescripcion}}</td>
		 			
		 			
		 			<td>{{$usd->tbdFecha}}</td>
		 			<!-- <td>{{$usd->idEscuela}}</td> -->
		 			<td>
		 				<a href="{{URL::action('DescargaController@edit',$usd->idDescarga)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-tabla-{{$usd->idDescarga}}" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
		 				<a href="" data-target="#modal-delete-{{$usd->idDescarga}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 				

		 				
		 			</td>
		 			
		 		</tr>
		 		@endif
		 		
		 		@include('escuela.descargas.modal')
		 		@include('escuela.descargas.modal2')
		 		@endforeach

		 	</table>
		 </div>
		 {{$descarga->render()}}
	</div>		
</div>


@endsection