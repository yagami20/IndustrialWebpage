@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Oficio Ingreso: {{$oficioI->tbOIDescripcion}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($oficioI,['method'=>'PATCH','route'=>['escuela.archivador.oficiosI.update',$oficioI->idOficioI], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row"> 
			<!-- -->
 
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOIDescripcion"> Descripcion: </label>
				<input type="text" name="tbOIDescripcion" required value="{{$oficioI->tbOIDescripcion}}" class="form-control" placeholder="Nombres...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbfiaFecha"> Fecha:</label>
				@foreach($fechaI as $tps)
				@if($tps->idOficioI == $oficioI->idOficioI )
				<input type="text" name="tbfiaFecha" required value="{{$tps->tbfiaFecha}}" class="form-control" placeholder="DD-MM-AA...">
				<input type="hidden" name="idFechaIA" required value="{{$tps->idFechaIA}}">
				@endif
				@endforeach
			</div>
			</div>
			
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOIExaminar"> Documento Oficio</label>
				<input type="file" name="tbOIExaminar" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOINumOficio"> NumOficio:</label>
				<input type="text" name="tbOINumOficio" required value="{{$oficioI->tbOINumOficio}}" class="form-control" placeholder="EII###...">
			</div>
			</div>
			<!-- -->
			<!--verfecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idFechaSA" value="0">
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idOficioS" value="1">
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idAutorizacionI" value="1">
			</div>
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection