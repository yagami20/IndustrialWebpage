@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Oficio Ingreso</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'escuela/archivador/oficiosI','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}
			
			<div class="row">
			 <!--archivadorEII -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>archivadorEII: </label>
					<select name="idArchEII" class="form-control">
						@foreach($archivadorEII as $tps)
						<option value="{{$tps->idArchEII}}">{{$tps->tbaeiiNombre}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!--tipoArchivador -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>archTipoI: </label>
					<select name="idArchTipoI" class="form-control">
						@foreach($archTipoI as $tps)
						<option value="{{$tps->idArchTipoI}}">{{$tps->tbarchINombre}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!--Tipo Archivador -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>archTipoI: </label>
					<select name="cont" class="form-control">
						<option value="1">Archivador Interno</option>
						<option value="2">Archivador Externo</option>
						
						
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOIDescripcion"> Descripcion:</label>
				<input type="text" name="tbOIDescripcion" class="form-control" placeholder="Descripcion...">
			</div>
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbfiaFecha"> Fecha:</label>
				<input type="text" name="tbfiaFecha" class="form-control" placeholder="DD-MM-AA...">
			</div>
			</div>
			<!--verfecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idFechaSA" value="0">
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idOficioS" value="1">
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idAutorizacionI" value="1">
			</div>
			</div>
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOIExaminar"> Documento Oficio</label>
				<input type="file" name="tbOIExaminar" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbOINumOficio"> NumOficio:</label>
				<input type="text" name="tbOINumOficio" class="form-control" placeholder="EII###...">
			</div>
			</div>
			<!-- -->
			</div>
						
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection