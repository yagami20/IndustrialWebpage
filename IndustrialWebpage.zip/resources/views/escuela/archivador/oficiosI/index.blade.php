@extends ('layouts.admin')
@section ('contenido')

<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<!-- <h3>Listado Observaciones <a href="observacion/create"><button class="btn btn-success">Nuevo</button></a></h3> -->
		<h3>Listado de Oficios Ingreso <a href="oficiosI/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.archivador.oficiosI.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			
		 			<th>Descripcion</th>
		 			<th>NumOficio</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($oficioI as $tpu)
		 		@if($tpu->idOficioI != 1 )  
		 		
		 		<tr>
		 			<td>{{$tpu->tbOIDescripcion}}</td>
		 			<td>{{$tpu->tbOINumOficio}}</td>
		 			<td>
		 				<a href="{{URL::action('OficioIController@edit',$tpu->idOficioI)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$tpu->idOficioI}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 				<a href="" data-target="#modal-tabla-{{$tpu->idOficioI}}" data-toggle="modal"><button class="btn btn-success">Documento</button></a>
		 			</td>
		 		</tr>
		 		@include('escuela.archivador.oficiosI.modal')
		 		@include('escuela.archivador.oficiosI.modal2')
		 		@endif
		 		
		 		@endforeach
		 	</table>
		 </div>
		 {{$oficioI->render()}}
	</div>		
</div>


@endsection