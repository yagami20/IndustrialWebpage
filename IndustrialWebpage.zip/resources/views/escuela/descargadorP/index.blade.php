@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Planificaciones</h3>
		@include('escuela.descargadorP.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Fecha</th>
		 			<th>Planificacion</th>
		 			<th>Materia</th>
		 			<th>Semestre</th>
		 			
		 			<th>Paralelo</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($planificacion as $usd) 
		 		
		 		<tr>
		 			<td>{{$usd->tbplFecha}}</td>
		 			<td>{{$usd->tbplDescripcion}}</td>
		 			<td>{{$usd->Materia}}</td>
		 			<td>{{$usd->Semestre}}</td> 
		 			
		 			<td>{{$usd->Paralelo}}</td>
		 			
		 			<td>
		 				
		 				<a href="" data-target="#modal-tabla-{{$usd->idPlanificacion}}" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
		 			</td>
		 			
		 		</tr>
		 		
		 		
		 		@include('escuela.descargadorP.modal2')
		 		@endforeach

		 	</table>
		 </div>
		 {{$planificacion->render()}}
	</div>		
</div>


@endsection