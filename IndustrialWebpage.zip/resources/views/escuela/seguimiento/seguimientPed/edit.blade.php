@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Seguimiento:</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($segp,['method'=>'PATCH','route'=>['escuela.seguimiento.seguimientPed.update',$segp->idSeguimientoP], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- seccion Escuela -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Escuela: </label>
					<select name="idEscuela" class="form-control">
						@foreach($escuela as $tps)
						<option value="{{$tps->idEscuela}}">{{$tps->tbeNombre}}</option>

						@endforeach
					</select>

				<!--<label for="tbtuId"> tuId</label>
				<input type="text" name="tbtuId" class="form-control" placeholder="tuId...">-->
			</div>
			</div>
			<!-- -->

			<!-- seccion planificacion -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Planificacion: </label>
					<select name="idPlanificacion" class="form-control">
						@foreach($planificacion as $tpl)
						@if($tpl->idPlanificacion==$segp->idPlanificacion)
						<option value="{{$tpl->idPlanificacion}}" selected>{{$tpl->tbplDescripcion}}</option>
						@else
						<option value="{{$tpl->idPlanificacion}}">{{$tpl->tbplDescripcion}}</option>
						@endif

						@endforeach
					</select>

				
			</div>
			</div>
			<!-- -->
			<!-- seccion silabo -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Silabo: </label>
					<select name="idSilabo" class="form-control">
						@foreach($silabo as $tbs)
						@if($tbs->idSilabo==$segp->idSilabo)
						<option value="{{$tbs->idSilabo}}" selected>{{$tbs->tbsiDescripcion}}</option>
						@else
						<option value="{{$tbs->idSilabo}}">{{$tbs->tbsiDescripcion}}</option>
						@endif

						@endforeach
					</select>
			</div>
			</div>
			<!-- -->
			<!-- seccion seguimiento -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Seguimiento: </label>
					<select name="idSeguimiento" class="form-control">
						@foreach($seguimiento as $tpse)
						@if($tpse->idSeguimiento==$segp->idSeguimiento)
						<option value="{{$tpse->idSeguimiento}}" selected>{{$tpse->tbseDescripcion}}</option>
						@else
						<option value="{{$tpse->idSeguimiento}}">{{$tpse->tbseDescripcion}}</option>
						@endif

						@endforeach
					</select>
			</div>
			</div>
			<!-- -->
			<!--observacion -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idObservacion" value="1">   

			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsegFecha"> Fecha: </label>
				<input type="text" name="tbsegFecha" required value="{{$segp->tbsegFecha}}" class="form-control" placeholder="DD-MM-AA...">

			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection