@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado Seguimientos Pedagogicos<a href="seguimientPed/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.seguimiento.seguimientPed.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<!-- <th>Id</th> -->
		 			<!-- <th>Escuela</th>-->
		 			<th>Fecha</th>
		 			<th>Materia</th>
		 			<th>Planificacion</th>
		 			<th>Silabo</th>
		 			<th>Seguimiento</th>
		 			<th>Observacion</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($segp as $tpu) 
		 		<tr>
		 			<!-- <td>{{$tpu->idSeguimientoP}}</td> -->
		 			<!-- <td>{{$tpu->Escuela}}</td> -->
		 			<td>{{$tpu->tbsegFecha}}</td>
		 			<td>{{$tpu->Materia}}</td>
		 			<!-- <td>{{$tpu->DesPl}}</td> -->
		 			<td>
		 				<a href="" data-target="#modal-tabla-{{$tpu->idSeguimientoP}}" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!-- <td>{{$tpu->DesSi}}</td> -->
		 			<td>
		 				<a href="" data-target="#modal-silabo-{{$tpu->idSeguimientoP}}" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!-- <td>{{$tpu->DesSe}}</td> -->
		 			<td>
		 				<a href="" data-target="#modal-segdoc-{{$tpu->idSeguimientoP}}" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!--<td>{{$tpu->DesOb}}</td> -->
		 			<!--detalle observacion -->
		 			<td>
		 				@if($tpu->idObservacion =='1')
						<p class="label label-warning">Sin Comentario</p>
						@else
						<a href="" data-target="#modal-observdoc-{{$tpu->idSeguimientoP}}" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
						@endif
		 				
		 			</td>
		 			<td>
		 				<a href="{{URL::action('SegPedController@edit',$tpu->idSeguimientoP)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$tpu->idSeguimientoP}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 				@if($tpu->idObservacion =='1')
						<h3><a href="{{URL::action('ComentSegController@edit',$tpu->idSeguimientoP)}}"><button class="btn btn-success">Agg. Observacion</button></a></h3>
						@else
						
						@endif
		 				
		 				
		 			</td>
		 		</tr>
		 		@include('escuela.seguimiento.seguimientPed.modal')
		 		@include('escuela.seguimiento.seguimientPed.modal2')
		 		@include('escuela.seguimiento.seguimientPed.modal3')
		 		@include('escuela.seguimiento.seguimientPed.modal4')
		 		@include('escuela.seguimiento.seguimientPed.modal5')
		 		@endforeach
		 	</table>
		 	
		 </div>
		 {{$segp->render()}}
	</div>		
</div>

@endsection