@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Seguimiento Pedagogico</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'escuela/seguimiento/seguimientPed','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}
			
			<div class="row">
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Escuela: </label>
					<select name="idEscuela" class="form-control">
						@foreach($escuela as $tps)
						<option value="{{$tps->idEscuela}}">{{$tps->tbeNombre}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!-- -->
			<!-- seccion planificacion -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Planificacion</label>
					<select name="idPlanificacion" class="form-control">
						@foreach($planificacion as $tpl)
						<option value="{{$tpl->idPlanificacion}}">{{$tpl->tbplDescripcion}}</option>

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<!-- seccion silabo -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Silabo</label>
					<select name="idSilabo" class="form-control">
						@foreach($silabo as $tbs)
						<option value="{{$tbs->idSilabo}}">{{$tbs->tbsiDescripcion}}</option>

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<!-- seccion seguimiento -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Seguimiento</label>
					<select name="idSeguimiento" class="form-control">
						@foreach($seguimiento as $tpse)
						<option value="{{$tpse->idSeguimiento}}">{{$tpse->tbseDescripcion}}</option>

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idObservacion" value="1">   

			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsegFecha"> Fecha:</label>
				<input id="tbsegFecha" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('tbsegFecha') ? ' is-invalid' : '' }}" name="tbsegFecha" value="{{ old('tbsegFecha') }}" required autofocus>
				
			</div>
			</div>
			
			<!-- -->
		</div>
			
						
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection