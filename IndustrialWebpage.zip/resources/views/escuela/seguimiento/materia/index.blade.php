@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado Materias <a href="materia/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('escuela.seguimiento.materia.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Id</th>
		 			<th>Materia</th>
		 			<th>Semestre</th>
		 			<th>ISBN</th>
		 			<th>Paralelo</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($materia as $tpu) 
		 		<tr>
		 			<td>{{$tpu->idMateria}}</td>
		 			<td>{{$tpu->tbmNombre}}</td>
		 			<td>{{$tpu->tbmSemestre}}</td>
		 			<td>{{$tpu->tbmISBN}}</td>
		 			<td>{{$tpu->tbmParalelo}}</td>
		 			<td>
		 				<a href="{{URL::action('MateriaController@edit',$tpu->idMateria)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$tpu->idMateria}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 			</td>
		 		</tr>
		 		@include('escuela.seguimiento.materia.modal')
		 		@endforeach
		 	</table>
		 </div>
		 {{$materia->render()}}
	</div>		
</div>

@endsection