@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nueva Materia</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'escuela/seguimiento/materia','method'=>'POST','autocomplete'=>'off'))!!}
			{{Form::token()}}
			
			
			<div class="from-group">
				<label for="tbmNombre"> Nombre Materia:</label>
				<input type="text" name="tbmNombre" class="form-control" placeholder="Nombre...">
			</div>
			
			<div class="from-group">
				<label for="tbmSemestre"> Semestre:</label>
				<input type="text" name="tbmSemestre" class="form-control" placeholder="Semestre...">
			</div>
			
			<div class="from-group">
				<label for="tbmISBN"> ISBN:</label>
				<input type="text" name="tbmISBN" class="form-control" placeholder="ISBN...">
			</div>
			
			<div class="from-group">
				<label for="tbmParalelo"> Paralelo:</label>
				<input type="text" name="tbmParalelo" class="form-control" placeholder="Paralelo...">
			</div>
			

			<!-- <div class="from-group">
				<label for="tbmSemestre"> Estado</label>
				<input type="text" name="tbmSemestre" class="form-control" value="1" readonly="readonly">
			</div> -->
			
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection