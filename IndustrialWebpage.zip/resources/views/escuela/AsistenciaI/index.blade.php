@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Registro de Entrada</h3>
		{{-- @foreach ($asistencia as $usC)
		@if(strcmp (phpCAS::getAttribute('cedula') , $usC->cedula ) !== 0)
		@if(strcmp ($dia , $usC->Fecha ) !== 0) --}}
		<h3>Registar<a href="AsistenciaI/create"><button class="btn btn-success">Nuevo</button></a></h3>
		{{-- @endif
		@endif
		@endforeach --}}
		@include('escuela.AsistenciaI.search')
	
	</div>
	
	
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Dia</th>
		 			<th>Fecha</th>		 			
		 			<th>Cédula</th>
		 			<th>Nombre</th>
		 			<th>Apellido</th>
		 			<th>Hora Entrada</th>
		 			
		 		</thead>
		 		@foreach ($asistencia as $usd) 
		 		
		 		<tr>
		 			<td>{{$usd->Dia}}</td>
		 			<td>{{$usd->Fecha}}</td>
		 			<td>{{$usd->cedula}}</td>
		 			<td>{{$usd->Nombre}}</td>
		 			<td>{{$usd->Apellido}}</td>
		 			<td>{{$usd->hora}}</td>
		 			
		 			
		 			
		 		</tr>
		 		
		 		
		 		@endforeach

		 	</table>
		 </div>
		 {{$asistencia->render()}}
	</div>		
</div>



@endsection