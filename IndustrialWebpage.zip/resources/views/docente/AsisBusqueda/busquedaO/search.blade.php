{!! Form::open(array('url'=>'escuela/AsisBusqueda/busquedaO', 'method'=>'GET','autocomplete'=>'off','role'=>'search')) !!}

<div class="form-group">
	
<div class="input-group">
	
	<label for="FechaInicio"> Fecha Inicio: </label>
	<input type="text" class="form-control" name="FechaInicio" placeholder="AA-MM-DD...">
	<!-- <br> -->
</div>
<div class="input-group">
	<label for="FechaFin"> Fecha Fin: </label>
	<input type="text" class="form-control" name="FechaFin" placeholder="AA-MM-DD..." value="{{$FechaFin}}">
</div>
	<!--  -->
<div class="input-group">
					<!-- Valorizacion -->
		<label>Busqueda por: </label>
		<select name="cont" class="form-control">
			<option value="1">Ingreso</option>
			<option value="2">Salida</option>
		</select>
</div>
	<!--  -->
		
	<div>	
		<br>
		<br>
		<span class="input-group-btn">
			<button type="submit" class="btn btn-primary" target="blank">Buscar </button>
			
		</span>
	</div>
	
</div>
{{Form::close()}}
