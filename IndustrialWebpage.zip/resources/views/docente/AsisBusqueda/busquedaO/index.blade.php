@extends ('layouts.admin')
@section ('contenido')

<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<!-- <h3>Listado Observaciones <a href="observacion/create"><button class="btn btn-success">Nuevo</button></a></h3> -->
		<h3>Busqueda de Oficios</h3>
		@include('escuela.AsisBusqueda.busquedaO.search')
	</div>
</div>




@endsection