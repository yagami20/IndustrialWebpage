@extends ('layouts.docente')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Publicaciones</h3>
		@include('docente.descargador.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Publicacion</th>
		 			<th>Descripcion</th>
		 			<th>Foto</th>
		 			
		 			<th>Fecha</th>
		 			<!-- <th>Escuela</th> -->
		 			<!-- <th>Estado</th> -->
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($publicacion as $usd) 
		 		@if ($usd->tbpEstado=='1')
		 		<tr>
		 			
		 			<td>{{$usd->idPublicacion}}</td>
		 			<td>{{$usd->tbpDescripcion}}</td>
		 			<!-- <td>{{$usd->tbpExaminar}}</td> -->
		 			<td>
		 				<img src="{{asset('/imagenes/publicaciones/'.$usd->tbpFoto)}}" alt="{{$usd->idPublicacion}}" height="100px" width="100px" class="img-thumbnail">
		 			</td>
		 			<td>{{$usd->tbpFecha}}</td>
		 			<!-- <td>{{$usd->idEscuela}}</td> -->
		 			<td>
		 				
		 				<a href="" data-target="#modal-tabla-{{$usd->idPublicacion}}" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
		 			</td>
		 			
		 		</tr>
		 		@endif
		 		
		 		@include('docente.descargador.modal2')
		 		@endforeach

		 	</table>
		 </div>
		 {{$publicacion->render()}}
	</div>		
</div>


@endsection