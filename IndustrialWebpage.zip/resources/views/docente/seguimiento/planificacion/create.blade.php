@extends ('layouts.docente')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nueva Planificacion</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'docente/seguimiento/planificacion','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}
			
			<div class="row">
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Materia: </label>
					<select name="idMateria" class="form-control">
						@foreach($materia as $tps)
						<option value="{{$tps->idMateria}}">{{$tps->tbmNombre}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplDescripcion"> Descripcion:</label>
				<input type="text" name="tbplDescripcion" class="form-control" placeholder="Descripcion...">
			</div>
			</div>
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplDocumento"> Documento Planificacion</label>
				<input type="file" name="tbplDocumento" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplFecha"> Fecha:</label>
				<input type="text" name="tbplFecha" class="form-control" placeholder="DD-MM-AA...">
			</div>
			</div>
			<!-- -->
			</div>
						
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection