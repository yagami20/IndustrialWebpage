@extends ('layouts.docente')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Planificacion: {{$planificacion->tbplDescripcion}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

			{!!Form::model($planificacion,['method'=>'PATCH','route'=>['docente.seguimiento.planificacion.update',$planificacion->idPlanificacion], 'files'=>'true'])!!}
			{{Form::token()}}
			
			<div class="row">
			<!-- seccion Materia -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Materia: </label>
					<select name="idMateria" class="form-control">
						@foreach($materia as $tpu)
						@if($tpu->idMateria==$planificacion->idMateria)
						<option value="{{$tpu->idMateria}}" selected>{{$tpu->tbmNombre}}</option>
						@else
						<option value="{{$tpu->idMateria}}">{{$tpu->tbmNombre}}</option>
						@endif

						@endforeach
					</select>

				<!--<label for="tbtuId"> tuId</label>
				<input type="text" name="tbtuId" class="form-control" placeholder="tuId...">-->
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplDescripcion"> Descripcion: </label>
				<input type="text" name="tbplDescripcion" required value="{{$planificacion->tbplDescripcion}}" class="form-control" placeholder="Nombres...">
			</div>	
			</div>
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplDocumento"> Documento Planificacion</label>
				<input type="file" name="tbplDocumento" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbplFecha"> Fecha: </label>
				<input type="text" name="tbplFecha" required value="{{$planificacion->tbplFecha}}" class="form-control" placeholder="DD-MM-AA...">
			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			{!!Form::close()!!}

		
@endsection