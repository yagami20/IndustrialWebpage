@extends ('layouts.docente')
@section ('contenido')

<center><img src="{{asset('imagenes/docent.jpg')}}" style="width: 500px; height: 400px"></center>
@endsection