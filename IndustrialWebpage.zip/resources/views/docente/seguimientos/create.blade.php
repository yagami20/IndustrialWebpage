@extends ('layouts.docente')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Seguimiento</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'docente/seguimientos','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}
			
			<div class="row">
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Materia: </label>
					<select name="idMateria" class="form-control">
						@foreach($materia as $tps)
						<option value="{{$tps->idMateria}}">{{$tps->tbmNombre}}</option>
						@endforeach
						
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbseDescripcion"> Descripcion:</label>
				<input type="text" name="tbseDescripcion" class="form-control" placeholder="Descripcion...">
			</div>
			</div>
			
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbseDocumento"> Documento Seguimiento</label>
				<input type="file" name="tbseDocumento" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbseFecha"> Fecha:</label>
				
				<input id="tbseFecha" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('tbseFecha') ? ' is-invalid' : '' }}" name="tbseFecha" value="{{ old('tbseFecha') }}" required autofocus>
			</div>
			</div>
			<!-- -->
		</div>
			
						
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection