@extends ('layouts.docente')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Registro de Salida</h3>
		
		<h3>Registar<a href="AsistenciaS/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('docente.AsistenciaS.search')
	
	</div>
	
	
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Dia</th>
		 			<th>Fecha</th>		 			
		 			<th>Cédula</th>
		 			<th>Nombre</th>
		 			<th>Apellido</th>
		 			<th>Hora Salida</th>
		 			
		 		</thead>
		 		@foreach ($asistencia as $usd) 
		 		
		 		<tr>
		 			<td>{{$usd->Dia}}</td>
		 			<td>{{$usd->Fecha}}</td>
		 			<td>{{$usd->cedula}}</td>
		 			<td>{{$usd->Nombre}}</td>
		 			<td>{{$usd->Apellido}}</td>
		 			<td>{{$usd->hora}}</td>
		 			
		 			
		 			
		 		</tr>
		 		
		 		
		 		@endforeach

		 	</table>
		 </div>
		 {{$asistencia->render()}}
	</div>		
</div>



@endsection