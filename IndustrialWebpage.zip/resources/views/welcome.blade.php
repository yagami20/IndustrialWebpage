@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Bienvenido</div>

               <!--
                <div class="panel-body">
                    Your Application's Landing Page.
                </div> -->
            </div>
        </div>
       

         @include('shared.sidebar')
         @include('shared.noticias')
         @include('shared.videos')
         @include('shared.servicios')

         
        
    </div>
</div>
@endsection
