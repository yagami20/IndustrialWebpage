@extends('layouts.app')

@section('content')
<div class="container">	
	<br>
<br>
<br>
	<li class="list-inline-item" >
              <i  id="id-cont-titl" class="devicons devicons-html5"><h1>Documentos Academicos de Eii <i class="fa fa-file-pdf-o" aria-hidden="true"></i></h1></i>
	<div class="col-md-6 col-md-offset-2">
<div class="row">


	
		
		@include('WebExterna.DocAcademicos.search')
	</div>
</div>

<div class="row">
	<div class="col-md-12 col-md-offset-2">
		 <div class="table-responsive-sm">
		 	<table class="table table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>No</th>
		 			<th>Titulo</th>
		 			
		 					 			
		 			<th>Fecha</th>
		 			<!-- <th>Escuela</th> -->
		 			<!-- <th>Estado</th> -->
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($descarga as $usd) 
		 		@if ($usd->tbdEstado=='1' && $usd->tbdSeccion=='1')
		 		<tr>
		 			
		 			<td>{{$usd->idDescarga}}</td>
		 			<td>{{$usd->tbdTitulo}}</td>
		 			
		 			
		 			
		 			<td>{{$usd->tbdFecha}}</td>
		 			<!-- <td>{{$usd->idEscuela}}</td> -->
		 			<td>
		 				
		 				<a href="" data-target="#modal-tabla-{{$usd->idDescarga}}" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
		 				

		 				
		 			</td>
		 			
		 		</tr>
		 		@endif
		 		
		 	
		 		@include('WebExterna.DocAcademicos.modal2')
		 		@endforeach
		 		

		 	</table>
		 </div>
		 {{$descarga->render()}}
	</div>		
</div>

</div>
@endsection