
@extends('layouts.app')

@section('content')
 <!--Contenido-->
    <div class="container ">
      <ol class="breadcrumb">
        <li class="list-inline-item">
              <i  id="id-cont-titl" class="devicons devicons-html5"><h1>Noticias del Eii <i class="fa fa-newspaper-o" aria-hidden="true"></i></h1></i>
  
      </ol>
      <!--==========================
      Team Section
    ============================-->
    <section id="team">
      <div class="container">
        <div class="section-header wow fadeInUp">
          <h3>Autoridades</h3>
          
        </div>

        <div class="row">


          <div class="col-lg-3 col-md-6">
            <h4> Facultad Mecanica</h4>
            <div class="member">
              <img src="{{ asset('img/Autoridades/Decano.jpg') }}" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                  
                  <span></span>
                  <div class="social">
                    <a href=""><i class="fa fa-twitter"></i></a>
                    <a href=""><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-google-plus"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <span><strong>DECANO/A:</strong>Ing. Carlos José Santillán Mariño</span>
            
            <p><i class="fa fa-envelope-o"> </i>csantillan_m@espoch.edu.ec</p>
          </div>

          <div class="col-lg-3 col-md-6 ">
            <h4> Facultad Mecanica</h4>
            <div class="member">
              <img src="{{ asset('img/Autoridades/VICEDECANO.jpg') }}" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                 
                  <span></span>
                  <div class="social">
                    <a href=""><i class="fa fa-twitter"></i></a>
                    <a href=""><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-google-plus"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <span><strong>VICEDECANO/A:</strong>Ing Ángel Guamán</span>
            <p><i class="fa fa-envelope-o"> </i>aguaman@espoch.edu.ec</p>
          </div>
          

         
        </div>
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <h4> Escuela Ingenieria Industrial</h4>
            <div class="member">
              <img src="{{ asset('img/Autoridades/directoreii.jpg') }}" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                  
                  
                  <div class="social">
                    <a href=""><i class="fa fa-twitter"></i></a>
                    <a href=""><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-google-plus"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <span><strong>DIRECTOR DE ESCUELA:</strong>Ing. Marco Almendariz </span>
            
            <p><i class="fa fa-envelope-o"> </i> malmendariz@espoch.edu.ec</p>
          </div>

          

         
        </div>

      </div>
    </section><!-- #team -->
      
    </div> <!--...Contenido  -->
@endsection