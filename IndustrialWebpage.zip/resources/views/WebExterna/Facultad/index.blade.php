@extends('layouts.app')

@section('content')
<div class="container"> 
  <br><h2>Escuela Ingenieria Industrial</h2><br>
<div class="row">
 
</div>
<!-- Page Content -->
    <div class="container">

      <!-- Heading Row -->
      <div class="row my-4">
        <div class="col-lg-6">
          <div class="card hovercard">
                <div class="cardheader">

                </div>
                <div class="avatar">
                    <img alt="" src="{{ asset('img/sello.jpg') }}">
                </div>
                <div class="info">
                    
                    <div class="desc">Escuela Ingenieria Industrial </div>
                    <div class="desc">
                      <a rel="publisher"
                       href="https://eii.espoch.edu.ec">
                        <i class="fa fa-globe" >eii.espoch.edu.ec</i>
                    </a>
                    </div>
                    
                </div>
                <div class="bottom">
                    <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac" target="_blank">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="btn btn-danger btn-sm" rel="publisher"
                       href="https://plus.google.com/116970194139409687955" target="_blank">
                        <i class="fa fa-google-plus"></i>
                    </a>
                    <a class="btn btn-primary btn-sm" rel="publisher"
                       href="https://www.facebook.com/Ingenier%C3%ADa-Industrial-Espoch-603949486478948/" target="_blank">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="btn btn-danger btn-sm" rel="publisher" href="https://www.youtube.com/channel/UC4QYVLdNSRfIVfONLtJTZ1Q/featured" target="_blank">
                        <i class="fa fa-youtube-play"></i>
                    </a>
                </div>
            </div>
          

        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-6">
          <h3 class="card-title">Definición e importancia de la carrera:</h3>
          <p class="text-justify">Fundamentalmente, la ingeniería industrial tiene sus cimientos en cualquier sistema de producción. El Ingeniero Industrial analiza y especifica componentes integrados de las personas, de las máquinas, y de recursos para crear sistemas eficientes y eficaces que producen las mercancías y los servicios beneficiosos integrados al buen vivir de la sociedad. En su ámbito profesional su desempeño lo realiza enmarcado en la realidad actual y proyección futura de la demanda productiva nacional e internacional, participando activamente en el proceso de transformación del país, con espíritu crítico y mentalidad de servicio.</p>
       
        </div>
        
        <!-- /.col-md-4 -->
      </div>
      <!-- /.row -->

      <!-- Call to Action Well -->
      <div class="card text-white bg-secondary my-4 text-center">
        <div class="card-body">

          <p class="text-white m-0"><br></p>
        </div>
      </div>

     <!-- Content Row -->
      <div class="row">
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 16px 16px 16px 16px; '>
              <h2 class="card-title">Misión</h2>
              <p ALIGN="justify">Formar ingenieros industriales competentes, su accionar se sustenta en la base del conocimiento de las ciencias básicas y de la ingeniería, se adapta fácilmente a trabajar en equipos multidisciplinarios, contribuyendo de manera eficaz en la solución de problemas en el ámbito de su especialidad: producción, productividad, calidad, seguridad y del ambiente, actuando con responsabilidad ética y social, en correspondencia con  el desarrollo de la región y del país.</p>
            </div>
            
          </div>
        </div>
        <!-- /.col-md-4 -->
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 16px 16px 16px 16px; '>
              <h2 class="card-title">Visión</h2>
              <p ALIGN="justify">Alcanzar la excelencia en la formación profesional de ingenieros industriales con liderazgo, capaces de contribuir al desarrollo sustentable  del país con  la práctica de valores éticos, morales y responsabilidad social, para alcanzar el régimen del buen vivir.</p>
            </div>
            
          </div>
        </div>
        <!-- /.col-md-4 -->
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 16px 16px 16px 16px; '>
              <h2 class="card-title">Título que Otorga:</h2>
              <p ALIGN="justify">Ingeniero Industrial.</p>
            </div>
            
          </div>
        </div>
        <!-- /.col-md-4 -->
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 16px 16px 16px 16px; '>
              <h2 class="card-title">Modalidad de Estudio:</h2>
              <p ALIGN="justify">Presencial.</p>
            </div>
            
          </div>
        </div>
        <!-- /.col-md-4 -->
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 16px 16px 16px 16px; '>
              <h2 class="card-title">Duración de la Carrera:</h2>
              <p ALIGN="justify">250 créditos  (incluye el sistema de titulación) que corresponderían a 10 niveles semestrales o cinco (5) años.</p>
              <h2 class="card-title">Perfil Profesional:</h2>
              <p ALIGN="justify">El estudiante al finalizar su formación profesional, debe ser capaz de demostrar sus capacidades relacionadas con conocimientos (saber), habilidades y destrezas (saber hacer) y actitudes (saber ser) en relación con las necesidades del contexto, particularmente: Diseñar, planificar, coordinar, dirigir, ejecutar y evaluar procesos de producción y desarrollo industrial, adaptación de tecnologías, métodos de trabajo y control de calidad de los sistemas productivos, considerando aspectos éticos, de optimización de recursos y de sustentabilidad industrial y ambiental.Realizar actividades de reingeniería, diseño de plantas industriales, automatización de procesos, utilizando modernas técnicas informáticas e investigaciones de mercado sobre la necesidad de fabricar nuevos productos.Realizar análisis técnicos económicos, desempeñar funciones administrativas y de dirección de personal, con iniciativa, liderazgo, creatividad, pensamiento social y humanista.Analizar y evaluar el entorno global, nacional, regional y municipal como bases para desarrollar una actividad empresarial.Planear, diseñar métodos de producción y de servicios, optimizando recursos para la operación de plantas industriales y/o servicios con performance competitiva.Programar, organizar, poner en marcha y controlar de los procesos productivos de la empresa. Realizar una evaluación técnica y económica de éstos y formular una predicción de su comportamiento.Integrar los elementos que constituyen un sistema o un proceso: personas, tecnología, máquinas, equipos, materiales e información, para optimizar su rendimiento y calidad, reduciendo sus costos y respetando factores medioambientales, en un marco de desarrollo sustentable.Aplicar la computación, la informática y sistemas de automatización a las actividades de producción industrial y a los servicios de administración.Formar parte de equipos de trabajo junto a otros profesionales para tomar decisiones a nivel de la administración estratégica de la empresa y asesora técnicamente a los diferentes departamentos.Diseñar productos y servicios que satisfagan las necesidades del mercado con responsabilidad social.Identificar los problemas industriales y organizacionales desde una perspectiva económico- financiera y administrativa, para proponer, ejecutar y evaluar alternativas de solución, atendiendo a las tendencias y normativas internacionales así como a la demanda social. Gestionar sistemas de planeación y control de producción de bienes industriales orientados a la satisfacción de los clientes, con miras al logro de máximos niveles de productividad, competitividad y protección ambiental.</p>
            </div>
            
          </div>
        </div>
        
        <!-- /.col-md-4 -->
        <div class="col-md-6 mb-6" style='float: center; padding: 16px 16px 16px 16px; '>
          <div class="card h-100">
            <div class="card-body" style=' padding: 20px 20px 20px 20px;'>
              <h2 class="card-title">Campo Ocupacional:</h2>
              <p ALIGN="justify">El profesional de la ingeniería industrial tiene su ubicación laboral en las diferentes empresas públicas y privadas donde cumple sus funciones al amparo de sus competencias genéricas, y prácticas profesionales que fueron anotadas con anterioridad, a saber:</p>

               <div class="li" align="left">• Empresas de producción y de servicios</div>
            <div class="li" align="left">• Empresas de asistencia técnica y transferencia de tecnología.</div>
            <div class="li" align="left">• Empresas consultoras</div>
            <div class="li" align="left">• Organismos e instituciones públicos y privados </div>
            <div class="li" align="left">• Instituciones de educación y capacitación</div>
            <div class="li" align="left">• Empresas de comercialización de elementos, equipos, maquinaria, y otros.</div>
            <div class="li" align="left">• Emprendimiento y autoempleo</div>
            <!--pdf-->
            <br><h3 class="card-title">Malla Curricular y Informacion Curricular:</h3>
                <div class="row">
                  <div class="col-md-8 col-md-offset-2">
                     <div class="table-responsive-sm" >
                      <table class="table  table-condensed table-hover"  >
                       
                        @foreach ($descarga as $usd) 
                        @if ($usd->tbdEstado=='1' && $usd->tbdSeccion=='2')
                        <tr>
                          
                          <td >{{$usd->tbdTitulo}}</td>
                          
                          <td>
                            
                            <a href="" data-target="#modal-tabla-{{$usd->idDescarga}}" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
                            
                          </td>
                          
                        </tr>
                        @endif
                        @include('WebExterna.Facultad.modal2')
                        @endforeach
                        

                      </table>
                     </div>
                     
                  </div>    
                </div>
                <!-- /.pdf -->
            </div>
           

            
          </div>
        </div>
        <!-- /.col-md-4 -->
             
        
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->



</div>
@endsection