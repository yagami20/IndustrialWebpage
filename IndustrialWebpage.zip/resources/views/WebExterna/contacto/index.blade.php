@extends('layouts.app')

@section('content')
 <!--==========================
      Contact Section
    ============================-->
    <section id="contact" class="section-bg wow fadeInUp">
      <div class="container">

        <div class="section-header">
          <h3><i  id="id-cont-titl" class="devicons devicons-html5">Horario de Atencion <i class="fa fa-clock-o" aria-hidden="true"></i></i></h3>
               <table class="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">Hora</th>
                    <th scope="col">08:00-13:00</th>
                    <th scope="col">14:30-17:30</th>
                    <th scope="col">14:30-17:30</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">08:00-13:00</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">14:30-17:30</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">14:30-17:30</th>
                    <td colspan="2">Larry the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
        </div>
         <div class="section-header">
          <h3>Contacto</h3>
          
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="fa fa-map-marker"></i>
              <h3>Address</h3>
              <address>Panamericana Sur km 1 1/2, Riobamba-Ecuador </address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="fa fa-phone-square"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855">+1 5589 55488 55</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="fa fa-envelope-o"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com">info@example.com</a></p>
            </div>
          </div>

        </div>

        

      </div>
    </section><!-- #contact -->

@endsection