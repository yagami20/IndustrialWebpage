@extends('layouts.app')

@section('content')
 <!--Contenido-->
    <div class="container-fluid text-center ">
     
<br><br><br>


      <section class="row">
       

       <article class="col-xs-12 col-md-10 col-lg-10">
        
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade in active show" id="Noticia">
               
               <!-- Seccion noticias-->
                <div class="container">
                        
                        @if ($publicacion->tbpEstado=='1')
                        @if ($publicacion->idPublicacion==$idP)
          


                          <!-- Blog Post -->
                          <div class="card mb-2">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-lg-4" style="width: 300px; height: 300px;">
                                  <a href="#">
                                    
                                    <img  src="{{asset('/imagenes/publicaciones/'.$publicacion->tbpFoto)}}" alt="{{$publicacion->idPublicacion}}"  style="width: 300px; height: 300px;" class="img-responsive img-thumbnail">


                                  </a>
                                </div>
                                <div class="col-lg-6">
                                  <h2 class="card-title">{{$publicacion->tbpDescripcion}}</h2>
                                  <p class="lead" align="justify">{!! $publicacion->tbpDescripcion !!}</p>

                                   
                                  
                                </div>

                              </div>
                            </div>
                            <div class="card-footer text-muted">
                              Posted on {{$publicacion->tbpFecha}}
                            
                            </div>




                           
                        @endif
                        @endif 


                         
                 

                        

                          

                          <!-- Pagination -->
                          <ul class="pagination justify-content-center mb-4">

                            
                          

                          </ul>
                          

                </div>


               <!-- seccion copias_____> -->

              </div>
             
             
            
              
            </div>
                                   
       </article>      
       
       </section>
    </div> <!--...Contenido  -->
@endsection