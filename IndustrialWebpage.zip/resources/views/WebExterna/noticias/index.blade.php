
@extends('layouts.app')

@section('content')
 <!--Contenido-->
    <div class="container-fluid text-center ">
      <br> <br><br>
      
        <li class="list-inline-item">
              <i  id="id-cont-titl" class="devicons devicons-html5"><h1>Noticias del Eii <i class="fa fa-newspaper-o" aria-hidden="true"></i></h1></i>


           
     
      <div class="col-md-4 col-md-offset-2">
    
    @include('WebExterna.noticias.search')
  </div>



      <section class="row">
       

       <article class="col-xs-12 col-md-10 col-lg-10">
        
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade in active show" id="Noticia">
               
               <!-- Seccion noticias-->
                <div class="container">
                        @foreach ($publicacion as $usd) 
                        @if ($usd->tbpEstado=='1')
          


                          <!-- Blog Post -->
                          <div class="card mb-2">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-lg-4" style="width: 300px; height: 300px;">
                                  <a href="#">
                                    
                                    <img  src="{{asset('/imagenes/publicaciones/'.$usd->tbpFoto)}}" alt="{{$usd->idPublicacion}}"  style="width: 300px; height: 300px;" class="img-responsive img-thumbnail">


                                  </a>
                                </div>
                                <div class="col-lg-6">
                                  <h2 class="card-title">{{$usd->tbpDescripcion}}</h2> 
                                  <p align="justify">{!! substr($usd->tbpDescripcion,0,200).'...' !!}</p>
                                  <a href="{{URL::action('noticias@article',$usd->idPublicacion)}}" class="btn btn-primary">Leer mas.. &rarr;</a>
                                 
                                 <a href="" data-target="#modal-tabla-{{$usd->idPublicacion}}" data-toggle="modal"><button class="btn btn-primary"> VER PDF</button></a>
                                </div>
                              </div>
                            </div>
                            <div class="card-footer text-muted">
                              Posted on {{$usd->tbpFecha}}
                            
                            </div>

                           
                        @endif 
                          @include('WebExterna.noticias.modal2')
                         @endforeach  
                 

                        

                          

                          <!-- Pagination -->
                          <ul class="pagination justify-content-center mb-4">
                            
                            {{$publicacion->render()}}

                          </ul>

                </div>


               <!-- seccion oticias_____> -->

              </div>
             
             
             
              
            </div>
                                   
       </article>      
       
       </section>
    </div> <!--...Contenido  -->
@endsection