 <section id="services">
      <div class="container ">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading">Siguenos en:</h2>
            <hr class="my-4">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-1 mx-auto">
              <a href="https://www.facebook.com/Ingenier%C3%ADa-Industrial-Espoch-603949486478948/" target="_blank">
              <i class="fa fa-5x fa-facebook-square text-primary mb-3 sr-icons i-responsive i-portfolio i-hover"></i></a>
              <h3 class="mb-3">Facebook</h3>
              
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-1 mx-auto">
              <a href="#" target="_blank">
              <i class="fa fa-5x fa-instagram text-primary mb-3 sr-icons i-responsive i-portfolio i-hover"></i></a>
              <h3 class="mb-3">Instagram</h3>
              
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-1 mx-auto">
             <a href="https://plus.google.com/116970194139409687955" target="_blank"> <i class="fa fa-5x fa-google-plus-official text-primary mb-3 sr-icons i-responsive i-portfolio i-hover"></i></a>
              <h3 class="mb-3">Google</h3>
              
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-1 mx-auto">
              <a  href="https://www.youtube.com/channel/UC4QYVLdNSRfIVfONLtJTZ1Q/featured" target="_blank">
              <i class="fa fa-5x fa-youtube text-primary mb-3 sr-icons i-responsive i-portfolio i-hover "></i></a>
              <h3 class="mb-1">Youtube</h3>
              
            </div>
          </div>
        </div>
      </div>
    </section>