<!--seccion noticias y eventos y sidevar-->
    <section id="acerca-de">
         <!-- Page Content -->
    <div class="container-fluid">

      <!-- Page Heading/Breadcrumbs -->
     
     

     <br>

      <!-- Content Row -->
      <div class="row">
        <!-- Sidebar Column -->
        <div class="col-lg-3 mb-4">
          <div class="list-group" align="left">
            <a href="index.html" class="list-group-item" target="_blank">ENlACES:</a>
             <a href="http://admision.espoch.edu.ec/" class="list-group-item" target="_blank">
              UAN – Espoch</a>
               <a href="https://www.espoch.edu.ec/index.php/estudiante.html" class="list-group-item" target="_blank">Oasis Estudiante</a>
                <a href="https://elearning.espoch.edu.ec/" class="list-group-item" target="_blank">E-Virtual</a>
             <a href="https://login.microsoftonline.com/?whr=espoch.edu.ec" class="list-group-item" target="_blank">Espoch WebMail</a>
            
           
            <a href="http://bibliotecas.espoch.edu.ec/bdatos.html" class="list-group-item" target="_blank">Biblioteca Virtual</a>
           
           
            <a href="portfolio-3-col.html" class="list-group-item" target="_blank">3 Column Portfolio</a>
            <a href="http://evaluacion.espoch.edu.ec/2/" class="list-group-item" target="_blank">Evaluación Institucional</a>
            <a href="https://www.espoch.edu.ec/index.php/calendario.html" class="list-group-item" target="_blank">Calendario Academico Espoch</a>
            
           
          </div>
        </div>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
            <!--==========================
      Portfolio Section
    ============================-->
    <section id="portfolio"   >
      <div class="container">

        <header class="section-header">
          <h3 class="section-title">Noticias:</h3>
        </header>

        

        <div class="row portfolio-container"> 
           @forelse($sliders as $slider )
            
          <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
            
            <div class="portfolio-wrap">
              <figure>
                <img class="d-block img-fluid" src="{{asset('/imagenes/publicaciones/'.$slider->tbpFoto)}}"  alt="">
                <a href="{{asset('/imagenes/publicaciones/'.$slider->tbpFoto)}}" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview">
                  <i class="fa fa-5x fa-eye"></i></a>
                <a href="{{URL::action('noticias@article',$slider->idPublicacion)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              </figure>  

              
              <div class="portfolio-info">
                <h6 align="left"><a >{{substr($slider->tbpDescripcion,0,50).'...'}}</a></h6>
                
              </div>
            </div>
             
          </div>
            
          @empty
          @endforelse
          
          
        </div>


      </div>


    </section><!-- #portfolio -->

         

        </div>
        
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
     <hr class="my-4">
    </section>
