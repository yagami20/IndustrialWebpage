<!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active">
            <div class="carousel-background"><img src="img/espoch.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Somos Profesionales</h2>
                <p>Alcanzar la excelencia en la formación profesional de ingenieros industriales con liderazgo, capaces de
contribuir al desarrollo sustentable del país con la práctica de valores éticos, morales y responsabilidad
social, para alcanzar el régimen del buen vivir</p>
                <a href="#featured-services" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/intro-carousel/2.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Misión de la carrera</h2>
                <p>Formar ingenieros industriales competentes, su accionar se sustenta en la base del conocimiento de las
ciencias básicas y de la ingeniería, se adapta fácilmente a trabajar en equipos multidisciplinarios,
contribuyendo de manera eficaz en la solución de problemas en el ámbito de su especialidad: producción,
productividad, calidad, seguridad industrial y del ambiente, actuando con responsabilidad ética y social, en
correspondencia con el desarrollo de la región y del país.</p>
                <a href="#featured-services" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/docente.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Escuela Ingenieria Industrial</h2>
                <p>Formar profesionales en el ámbito industrial, competentes e integrales con sólidos conocimientos técnico -
científicos, habilidades y actitudes para planificar, diseñar, rediseñar, implementar, mejorar, innovar y
optimizar sistemas productivos de bienes y servicios.</p>
                <a href="#featured-services" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/intro-carousel/4.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Nam libero tempore</h2>
                <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum.</p>
                <a href="#featured-services" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-background"><img src="img/intro-carousel/5.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2>Magnam aliquam quaerat</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                <a href="#featured-services" class="btn-get-started scrollto">Get Started</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#introCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon ion-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#introCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon ion-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>
  </section><!-- #intro -->