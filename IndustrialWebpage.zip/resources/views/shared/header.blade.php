<!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="{{ url('/') }}" class="scrollto">EII</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#intro"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="{{ url('/') }}">Home</a></li>
           <li class="menu-has-children"><a href="">Facultad</a>
            <ul>
              <li><a href="{{url('WebExterna/Facultad') }}">Acerca de Nosotros</a></li>
              <li><a href="{{url('WebExterna/Autoridades') }}">Autoridades</a></li>
              <li><a href="#">Drop Down 4</a></li>
              <li><a href="#">Drop Down 5</a></li>
            </ul>
          </li>
          <li class="menu-has-children"><a href="">Asociaciones</a>
            <ul>
              <li><a href="#about">Asociación de Estudiantes</a></li>
              <li><a href="#">Asociación de Docentes</a></li>
             
            </ul>
          </li>
                
          <li><a href="{{url('WebExterna/noticias') }}">Noticias</a></li>
           <li><a href="{{url('WebExterna/DocAcademicos')}}">Documentos Academicos</a></li>
        
          <li><a href="{{url('WebExterna/contacto') }}">Horarios y Contacto</a></li>

           <!-- inicio login                    
                <a href="{{ url('/login') }}" class="btn btn-primary">Login</a> 
              -->
                <!-- Authentication Links -->
                    @if (Auth::guest())
                     {{-- <li><a href="{{asset('/cas/protected')}}">Login</a></li>  --}}
                      <li><a href="{{asset('/login')}}">Login</a></li>

            @endif
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

  