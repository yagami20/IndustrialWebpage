  <!--inicio video-->
             <section id="acerca-de-video">
        <div class="contenido-seccion-video">
            <div class="container">
               <div class="row">
        <div class="col-lg-6">
          <h5>Escuela Ingenieria Industrial</h5>
          <ul align="left">
            <li>
              <strong>Videos Institucion</strong>
            </li>
            <ul>
            <li>Aniversario de la Escuela de Ingenieria Industrial ESPOCH 2016</li>
            <li>Empacadora de baldosas Automatización1</li>
            <li>CONGRESO DE CIENCIA E INNOVACIÓN TECNOLÓGICA INDUSTRIAL</li>
            <li>CONGRESO DE CIENCIA E INNOVACIÓN TECNOLÓGICA INDUSTRIAL</li>
            </ul>
            
            
          </ul>
          
          <p class="text-justify" >Felicitaciones a la Escuela de Ingeniería  Industrial  de la Escuela Superior Politécnica de Chimborazo de Riobamba al cumplir 19 años de importante labor formando profesionales comprometidos con el desarrollo del centro del país y de nuestro querido Ecuador.</p>
        </div>
        <div class="col-lg-6"><br><br>
                        <div class="slideshow">
                  <ul class="slider">
                    <li>
                      <div class="embed-responsive embed-responsive-16by9">
                         <iframe width="560" height="315" src="https://www.youtube.com/embed/rbNhXSMNPwU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                      </div>
                    

                    </li>
                    <li>
                      <div class="embed-responsive embed-responsive-16by9">
                          <iframe width="560" height="315" src="https://www.youtube.com/embed/bEk6bFhFgA0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                      </div>

                    </li>
                    <li>
                      <div class="embed-responsive embed-responsive-16by9">
                         <iframe width="560" height="315" src="https://www.youtube.com/embed/ApWoR-0jlQ8" frameborder="0" allowfullscreen></iframe>

                      </div>

                    </li>
                    <li>
                      <div class="embed-responsive embed-responsive-16by9">
                         <iframe width="560" height="315" src="https://www.youtube.com/embed/Fh65L-XEc7o" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                      </div>
                    </li>
                  </ul>

                  <ol class="paginationvid">
                    
                  </ol>
                
                  <div class="left">
                    <span class="fa fa-chevron-left"></span>
                  </div>

                  <div class="right">
                    <span class="fa fa-chevron-right"></span>
                  </div>

                </div>
        </div>
      </div>
        </div>
      </div>  
        
      </div>
    </section>
    <!-- fin video-->