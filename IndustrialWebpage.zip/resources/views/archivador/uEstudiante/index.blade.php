@extends ('layouts.admin')
@section ('contenido')
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Estudiantes <a href="uEstudiante/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('archivador.uEstudiante.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Cedula</th>
		 			<th>Nombres</th>
		 			<th>Apellidos</th>
		 			<th>CorreoPersonal</th>
		 			<th>CorreoInstitucional</th>
		 			<th>Sexo</th>
		 			<th>Telefono</th>
		 			<th>Foto</th>
		 			<th>Ciudad</th>
		 			<!-- <th>Estado</th> -->
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($uEstudiante as $usd) 
		 		@if ($usd->tbuEstado=='1')
		 		<tr>
		 			
		 			<td>{{$usd->tbuCedula}}</td>
		 			<td>{{$usd->tbuNombres}}</td>
		 			<td>{{$usd->tbuApellidos}}</td>
		 			<td>{{$usd->email}}</td>
		 			<td>{{$usd->tbuCorreoInstitucional}}</td>
		 			<td>{{$usd->tbuSexo}}</td>
		 			<td>{{$usd->tbuTelefono}}</td>
		 			<td>
		 				<img src="{{asset('/imagenes/usuarios/'.$usd->tbuFoto)}}" alt="{{$usd->tbuNombres}}" height="100px" width="100px" class="img-thumbnail">
		 			</td>
		 			<td>{{$usd->tbuCiudad}}</td>
		 			<!-- <td>{{$usd->tbuEstado}}</td> -->
		 			<td>
		 				<a href="{{URL::action('uEstudianteController@edit',$usd->id)}}"><button class="btn btn-info">Editar</button></a>

		 				<a href="" data-target="#modal-tabla-{{$usd->id}}" data-toggle="modal"><button class="btn btn-success">Titulo</button></a>
		 				<a href="" data-target="#modal-delete-{{$usd->id}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 			</td>
		 			
		 		</tr>
		 		@endif
		 		
		 		@include('archivador.uEstudiante.modal')
		 		@include('archivador.uEstudiante.modal2')
		 		@endforeach

		 	</table>
		 </div>
		 {{$uEstudiante->render()}}
	</div>		
</div>


@endsection