@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Usuario</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'archivador/uAdministrativo','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			 {{ Form::token() }}

		<div class="row">
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
					<label for="tbuCedula"> Cedula</label>
				<input type="text" name="tbuCedula" required value="{{old('tbuCedula')}}" class="form-control" placeholder="Cedula...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			 <div class="form-group{{ $errors->has('tbuNombres') ? ' has-error' : '' }}">
                            <label for="tbuNombres" >Nombres</label>

                          
                                <input id="tbuNombres" type="text" class="form-control" name="tbuNombres" value="{{ old('tbuNombres') }}" placeholder="Nombres...">

                                @if ($errors->has('tbuNombres'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('tbuNombres') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuApellidos"> Apellidos</label>
				<input type="text" name="tbuApellidos" required value="{{old('tbuApellidos')}}" class="form-control" placeholder="Apellidos...">
			</div>	
			</div>

			<!--email -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" >Corre Personal</label>

                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}"  placeholder="Email...">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                           
                        </div>
                    </div>
			<!--password -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

			<div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" >Password</label>

                           
                                <input id="password" type="password" class="form-control" name="password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>

                        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            <label for="password-confirm" >Confirm Password</label>

                            
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>
		
			<!--Remember -->
			
		
			
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuCorreoInstitucional"> CorreoInstitucional</label>
				<input type="text" name="tbuCorreoInstitucional" required value="{{old('tbuCorreoInstitucional')}}" class="form-control" placeholder="CorreoInstitucional...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuSexo"> Sexo</label>
				<input type="text" name="tbuSexo" required value="{{old('tbuSexo')}}" class="form-control" placeholder="Sexo(M-F)...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuTelefono"> Telefono</label>
				<input type="text" name="tbuTelefono" required value="{{old('tbuTelefono')}}" class="form-control" placeholder="Telefono...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuFechaNacimiento"> FechaNacimiento</label>
				<input type="text" name="tbuFechaNacimiento" required value="{{old('tbuFechaNacimiento')}}" class="form-control" placeholder="FechaNacimiento...">
			</div>	
			</div>
			<!--seccion foto -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuFoto"> Foto</label>
				<input type="file" name="tbuFoto" class="form-control" >
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuPais"> Pais</label>
				<input type="text" name="tbuPais" required value="{{old('tbuPais')}}" class="form-control" placeholder="Pais...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuCiudad"> Ciudad</label>
				<input type="text" name="tbuCiudad" required value="{{old('tbuCiudad')}}" class="form-control" placeholder="Ciudad...">
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuCurriculo"> Curriculo</label>
				<input type="file" name="tbuCurriculo"  class="form-control" >
			</div>	
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbuEstado"> Estado</label>
				<input type="text" name="tbuEstado" required value="1" readonly="readonly" class="form-control">
			</div>	
			</div>
			<!-- seccion tbtipus -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- <label>Tipo Usuario</label>
					<select name="tbtuId" class="form-control">
						@foreach($tipousuario as $tpu)
						<option value="{{$tpu->tbtuId}}">{{$tpu->tbtuDescripcion}}</option>

						@endforeach
					</select> -->
					<!-- Valorizacion -->
					<label>Tipo Usuario</label>
					<select name="tbtuId" class="form-control">
						@foreach($tipousuario as $tpu) 
						@if($tpu->tbtuId=='2')
						<option value="{{$tpu->tbtuId}}" readonly="readonly" selected>{{$tpu->tbtuDescripcion}}</option>
						@endif

						@endforeach
					</select>

				</div>
			</div>
			<!-- -->
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		
@endsection