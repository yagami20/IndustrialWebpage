@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado Tipo Usuarios <a href="tipousuario/create"><button class="btn btn-success">Nuevo</button></a></h3>
		@include('archivador.tipousuario.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Id</th>
		 			<th>Descripcion</th>
		 			<th>Estado</th>
		 			<th>Opciones</th>
		 		</thead>
		 		@foreach ($tipousuario as $tpu) 
		 		<tr>
		 			<td>{{$tpu->tbtuId}}</td>
		 			<td>{{$tpu->tbtuDescripcion}}</td>
		 			<td>{{$tpu->tbtuEstado}}</td>
		 			<td>
		 				<a href="{{URL::action('TipoUsuarioController@edit',$tpu->tbtuId)}}"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-{{$tpu->tbtuId}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
		 			</td>
		 		</tr>
		 		@include('archivador.tipousuario.modal')
		 		@endforeach
		 	</table>
		 </div>
		 {{$tipousuario->render()}}
	</div>		  
</div>

@endsection