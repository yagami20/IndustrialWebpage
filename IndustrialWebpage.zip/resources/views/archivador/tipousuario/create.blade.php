@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Nuevo Tipo Usuario</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::open(array('url'=>'archivador/tipousuario','method'=>'POST','autocomplete'=>'off'))!!}
			{{Form::token()}}
			
			<!--
			<div class="form-group">
					<label for="tbtuId"> Id</label>
				<input type="text" name="tbtuId" class="form-control" placeholder="ID...">
			</div>
			-->
			<div class="from-group">
				<label for="tbtuDescripcion"> Descripcion</label>
				<input type="text" name="tbtuDescripcion" class="form-control" placeholder="Descripcion...">
			</div>
			<div class="from-group">
				<label for="tbtuEstado"> Estado</label>
				<input type="text" name="tbtuEstado" class="form-control" value="1" readonly="readonly">
			</div>
			
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			{!!Form::close()!!}

		</div>	
	</div>
@endsection