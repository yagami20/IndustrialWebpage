@extends('layouts.app')

@section('content')

<div class="container">
    <br><br><br><br><div class="row">
        <div class="col-md-12 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Registro</strong></div><br>
                <div class="panel-body">

    
                   <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            
                            @if (count($errors)>0)
                            <div class="alert alert-danger">
                                <ul>
                                @foreach ($errors -> all() as $error)
                                    <li>{{$error}}</li>
                                @endforeach
                                </ul>
                            </div>
                            @endif
                    </div>
                </div>
            {!!Form::open(array('url'=>'/register','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
            {{Form::token()}}
            <!--   {{ csrf_field() }} -->

        <div class="row" align="left">
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12 ">
            <div class="form-group" >
                   <strong> <label for="tbuCedula"> Cedula</label></strong>
                <input type="text" name="tbuCedula" required value="{{old('tbuCedula')}}" class="form-control" placeholder="Cedula...">
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
             <div class="form-group{{ $errors->has('tbuNombres') ? ' has-error' : '' }}">
                          <strong>  <label for="tbuNombres" >Nombres</label></strong>

                          
                                <input id="tbuNombres" type="text" class="form-control" name="tbuNombres" value="{{ old('tbuNombres') }}" placeholder="Nombres...">

                                @if ($errors->has('tbuNombres'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('tbuNombres') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuApellidos"> Apellidos</label></strong>
                <input type="text" name="tbuApellidos" required value="{{old('tbuApellidos')}}" class="form-control" placeholder="Apellidos...">
            </div>  
            </div>
            <!--email -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <strong><label for="email" >Corre Personal</label></strong>

                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}"  placeholder="Email...">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                           
                        </div>
                    </div>
            <!--password -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <strong><label for="password" >Password</label></strong>

                           
                                <input id="password" type="password" class="form-control" name="password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>

                        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            <strong><label for="password-confirm" >Confirm Password</label></strong>

                            
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            
                        </div>
                    </div>
            <!--Remember -->
            
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuCorreoInstitucional"> CorreoInstitucional</label></strong>
                <input type="text" name="tbuCorreoInstitucional" required value="{{old('tbuCorreoInstitucional')}}" class="form-control" placeholder="CorreoInstitucional...">
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
           
            <div class="from-group">
                <strong><label for="tbuSexo">Sexo</label></strong>

                       <select id="tbuSexo" name="tbuSexo" class="form-control">

                            <option value="M">Maculino</option>
                            <option value="F ">Femenino</option>                          
                     
                      </select>
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuTelefono"> Telefono</label></strong>
                <input type="text" name="tbuTelefono" required value="{{old('tbuTelefono')}}" class="form-control" placeholder="Telefono...">
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuFechaNacimiento"> FechaNacimiento</label></strong>
                <input type="text" name="tbuFechaNacimiento" required value="{{old('tbuFechaNacimiento')}}" class="form-control" placeholder="FechaNacimiento...">
            </div>  
            </div>
            <!--seccion foto -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuFoto"> Foto</label></strong>
                <input type="file" name="tbuFoto" class="form-control" >
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
               <strong> <label for="tbuPais"> Pais</label></strong>
                <input type="text" name="tbuPais" required value="{{old('tbuPais')}}" class="form-control" placeholder="Pais...">
            </div>  
            </div>
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuCiudad"> Ciudad</label></strong>
                <input type="text" name="tbuCiudad" required value="{{old('tbuCiudad')}}" class="form-control" placeholder="Ciudad...">
            </div>  
            </div>
            <!-- -->
            
            <!--seccion curriculo -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <strong><label for="tbuCurriculo"> Curriculo</label></strong>
                <input type="file" name="tbuCurriculo" class="form-control" >
            </div>  
            </div>
            <!-- -->
            <!-- -->
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="from-group">
                <label for="tbuEstado"> </label>
                <input type="text" name="tbuEstado" required value="1" readonly="readonly" class="form-control" hidden="tbuEstado">
            </div>  
            </div>
            
        </div><br>
            
            <div class="form-group" align="center">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>


            {!!Form::close()!!}


                 

            </div>
        </div>
    </div>
</div>
@endsection
