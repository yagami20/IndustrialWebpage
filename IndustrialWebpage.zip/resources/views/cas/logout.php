<?php

session_start();
session_unset(); 
  // unset($_SESSION["nombre_cliente"]);
  if (ini_get("session.use_cookies")) 
	{
	  $params = session_get_cookie_params();
	  setcookie(session_name(), '', time() - 42000,
	      $params["path"], $params["domain"],
	      $params["secure"], $params["httponly"]);
	}
session_destroy();
session_write_close(); 
  // Session::flush();

// header('Location: index.php');
// route('/');
header('Location: https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https://seguridad.espoch.edu.ec/cas/logout?service=http://localhost:8080/IndustrialWebpage/public');
$cas_url=header('Location: index.php');
phpCAS::logout(​​$cas_url);
exit;

/* Decoded: (ejemplo para entender)
https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https://seguridad.espoch.edu.ec/cas/logout?service=http://localhost/gestorMSA/cas/protected

Encoded:
https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https%3A%2F%2Fseguridad.espoch.edu.ec%2Fcas%2Flogout%3Fservice%3Dhttps%3A%2F%2Felearning.espoch.edu.ec%2Findex.php


*/

?>
