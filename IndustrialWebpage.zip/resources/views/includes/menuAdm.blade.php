@if(Auth::user()->tbtuId ==1)
<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
           
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Archivador</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Usuarios</a></li>
               
                <li><a href="{{ url('archivador/tipousuario') }}"><i class="fa fa-circle-o"></i> Tipo Usuarios</a></li>
                
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Archivador G</a></li>
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Tipo Archivador In.</a></li>
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Tipo archivador ex.</a></li>
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Arch. Interno</a></li>
                <li><a href="{{url('archivador/usuario')}}"><i class="fa fa-circle-o"></i> Arch. Externo</a></li>
                 
                 <li><a href="{{url('archivador/tipousuario')}}"><i class="fa fa-circle-o"></i> Tipo Usuariosdoc</a></li>
                 </ul>
            </li>
           
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Usuarios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('archivador/uAdministrativo')}}"><i class="fa fa-circle-o"></i>Administrativo</a></li>
                <li><a href="{{url('archivador/uDocente')}}"><i class="fa fa-circle-o"></i>Docente</a></li>
                <li><a href="{{url('archivador/uEstudiante')}}"><i class="fa fa-circle-o"></i>Estudiante</a></li>
                <li><a href="{{url('escuela/archivador/oficiosI')}}"><i class="fa fa-circle-o"></i>Oficios Ingreso</a></li>
                <li><a href="{{url('escuela/archivador/oficiosS')}}"><i class="fa fa-circle-o"></i>Oficios Salida</a></li>
                <li><a href="{{url('escuela/archivador/autorI')}}"><i class="fa fa-circle-o"></i>Autorizaciones Ingreso</a></li>
                <li><a href="{{url('escuela/archivador/autorS')}}"><i class="fa fa-circle-o"></i>Autorizaciones Salida</a></li>
              </ul>
            </li>
            
            <!-- lista icono-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Noticias</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/publicaciones')}}"><i class="fa fa-circle-o"></i>Ingresar</a></li>
              </ul>
            </li>
            <!-- -->
            <!-- lista icono-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Documento Academico</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/descargas')}}"><i class="fa fa-circle-o"></i>Ingresar</a></li>
              </ul>
            </li>
            <!-- -->

            <!-- lista autoevaluacion-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i>
                <span>Autoevaluacion</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/autoevaluacion/criterio')}}"><i class="fa fa-circle-o"></i>Criterio</a></li>
                <li><a href="{{url('escuela/autoevaluacion/subcriterio')}}"><i class="fa fa-circle-o"></i>Subcriterio</a></li>
                <li><a href="{{url('escuela/autoevaluacion/indicador')}}"><i class="fa fa-circle-o"></i>Indicador</a></li>
                <li><a href="{{url('escuela/autoevaluacion/subindicador')}}"><i class="fa fa-circle-o"></i>SubIndicador</a></li>
                <li><a href="{{url('escuela/autoevaluacion/pdf')}}" target="blank"><i class="fa fa-circle-o"></i>Reporte</a></li>
                
              </ul>
            </li>
            <!-- -->

            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Asistencia</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/Asistencia')}}"><i class="fa fa-circle-o"></i> Ingresos</a></li>
                <li><a href="compras/proveedor"><i class="fa fa-circle-o"></i> Salidas</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-shopping-cart"></i>
                <span>Seguimiento</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/seguimiento/materia')}}"><i class="fa fa-circle-o"></i> Materias</a></li>
                <li><a href="{{url('escuela/seguimiento/silabo')}}"><i class="fa fa-circle-o"></i> Silabos</a></li>
                <li><a href="{{url('escuela/seguimiento/planificacion')}}"><i class="fa fa-circle-o"></i> Planificaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/seguimientos')}}"><i class="fa fa-circle-o"></i> Seguimientos</a></li>
                <li><a href="{{url('escuela/seguimiento/observacion')}}"><i class="fa fa-circle-o"></i> Observaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/seguimientPed')}}"><i class="fa fa-circle-o"></i> Seguimiento Pedagogico</a></li>
              </ul>
            </li>
                       
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Download</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/descargador')}}"><i class="fa fa-circle-o"></i>Publicaciones</a></li>
                <li><a href="{{url('escuela/descargadorS')}}"><i class="fa fa-circle-o"></i>Silabos</a></li>
                <li><a href="{{url('escuela/descargadorP')}}"><i class="fa fa-circle-o"></i>Planificaciones</a></li>

                
                
              </ul>
            </li>
         

        

           

             <li>
              <a href="#">
                <i class="fa fa-plus-square"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-info-circle"></i> <span>Acerca De...</span>
                <small class="label pull-right bg-yellow">IT</small>
              </a>
            </li>
                        
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

@endif
<!-- docente -->
@if(Auth::user()->tbtuId ==3)
<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
           
            
           
            
            <!-- lista icono-->
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Publicaciones Doc</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/publicaciones')}}"><i class="fa fa-circle-o"></i>Ingresar</a></li>
              </ul>
            </li>
            <!-- -->

            <!-- lista autoevaluacion-->
          
            <!-- -->

            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Asistencia</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('escuela/Asistencia')}}"><i class="fa fa-circle-o"></i> Ingresos</a></li>
                <li><a href="compras/proveedor"><i class="fa fa-circle-o"></i> Salidas</a></li>
              </ul>
            </li>

            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Area Docente</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <!-- <li><a href="{{url('escuela/seguimiento/materia')}}"><i class="fa fa-circle-o"></i> Materias</a></li>-->
                <li><a href="{{url('escuela/autoevaluacion/CritDoc')}}"><i class="fa fa-circle-o"></i>CriterioDoc</a></li>
                <li><a href="{{url('escuela/seguimiento/silabo')}}"><i class="fa fa-circle-o"></i> Silabos</a></li>
                <li><a href="{{url('escuela/seguimiento/planificacion')}}"><i class="fa fa-circle-o"></i> Planificaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/seguimientos')}}"><i class="fa fa-circle-o"></i> Seguimientos</a></li>
                
                <li><a href="{{url('escuela/seguimiento/SegPedDocente')}}"><i class="fa fa-circle-o"></i>Seguimiento Pedagogico</a></li>
                
                
              </ul>
            </li>

           

             
                        
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

@endif
<!-- docente -->
@if(Auth::user()->tbtuId ==4)
<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
           
            
           

            <!-- lista autoevaluacion-->
          
            <!-- -->

          
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Area Estudiante</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                
                <li><a href="{{url('escuela/descargadorS')}}"><i class="fa fa-circle-o"></i>Silabos</a></li>
                <li><a href="{{url('escuela/descargadorP')}}"><i class="fa fa-circle-o"></i>Planificaciones</a></li>
                <li><a href="{{url('escuela/seguimiento/SegPedFecha')}}"><i class="fa fa-circle-o"></i>Seguimiento por Fecha</a></li>
              </ul>
            </li>

          
                        
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

@endif
  


  

