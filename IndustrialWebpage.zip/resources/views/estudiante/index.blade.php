@extends ('layouts.estudiante')
@section ('contenido')

<center><img src="{{asset('imagenes/industrial.jpg')}}" style="width: 500px; height: 400px"></center>
@endsection