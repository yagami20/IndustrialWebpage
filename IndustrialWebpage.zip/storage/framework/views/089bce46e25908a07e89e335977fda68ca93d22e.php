<?php $__env->startSection('contenido'); ?>
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de SubCriterios
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Criterio</th>
		 			<th>Subcriterio</th>
		 			<th>Descripcion</th>
		 			<th>Opciones</th>
		 		</thead>
		 		<?php foreach($subcriterio as $usd): ?> 
		 		<tr>
		 			<td><?php echo e($usd->Descrip); ?></td>
		 			<td><?php echo e($usd->idSubcriterio); ?></td>
		 			<td><?php echo e($usd->tbscDescripcion); ?></td>
		 			<td>
		 				<!-- <a href="<?php echo e(URL::action('CrScController@edit',$usd->idSubcriterio)); ?>"><button class="btn btn-info">Editar</button></a>-->
		 				<a href="<?php echo e(route('indicadores.show', [$usd->idSubcriterio])); ?>"><button class="btn btn-primary">Indicador</button></a>
		 				
		 				
   
		 				
		 			</td>
		 			
		 		</tr>
		 		<?php endforeach; ?>

		 	</table>
		 </div>
		 <?php echo e($subcriterio->render()); ?>

	</div>		
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>