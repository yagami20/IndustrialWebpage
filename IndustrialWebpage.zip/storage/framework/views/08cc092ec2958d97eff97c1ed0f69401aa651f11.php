<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Silabo: <?php echo e($silabo->tbsiDescripcion); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php foreach($errors -> all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

			<?php echo Form::model($silabo,['method'=>'PATCH','route'=>['escuela.seguimiento.silabo.update',$silabo->idSilabo], 'files'=>'true']); ?>

			<?php echo e(Form::token()); ?>

			
			<div class="row">
			<!-- seccion Materia -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Materia: </label>
					<select name="idMateria" class="form-control">
						<?php foreach($materia as $tpu): ?>
						<?php if($tpu->idMateria==$silabo->idMateria): ?>
						<option value="<?php echo e($tpu->idMateria); ?>" selected><?php echo e($tpu->tbmNombre); ?></option>
						<?php else: ?>
						<option value="<?php echo e($tpu->idMateria); ?>"><?php echo e($tpu->tbmNombre); ?></option>
						<?php endif; ?>

						<?php endforeach; ?>
					</select>

				<!--<label for="tbtuId"> tuId</label>
				<input type="text" name="tbtuId" class="form-control" placeholder="tuId...">-->
			</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsiDescripcion"> Descripcion: </label>
				<input type="text" name="tbsiDescripcion" required value="<?php echo e($silabo->tbsiDescripcion); ?>" class="form-control" placeholder="Nombres...">
			</div>	
			</div>
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsiDocumento"> Documento Silabo</label>
				<input type="file" name="tbsiDocumento" class="form-control" placeholder="Documento..." >
			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsiFecha"> Fecha: </label>
				<input type="text" name="tbsiFecha" required value="<?php echo e($silabo->tbsiFecha); ?>" class="form-control" placeholder="DD-MM-AA...">
			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>