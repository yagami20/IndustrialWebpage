<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado Seguimientos Pedagogicos<a href="SegPedDocente/create"><button class="btn btn-success">Nuevo</button></a></h3>
		<?php echo $__env->make('escuela.seguimiento.SegPedDocente.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<!-- <th>Id</th> -->
		 			<!-- <th>Escuela</th>-->
		 			<th>Fecha</th>
		 			<th>Materia</th>
		 			<th>Planificacion</th>
		 			<th>Silabo</th>
		 			<th>Seguimiento</th>
		 			<th>Observacion</th>
		 			<th>Opciones</th>
		 		</thead>
		 		<?php foreach($segp as $tpu): ?> 
		 		<tr>
		 			<!-- <td><?php echo e($tpu->idSeguimientoP); ?></td> -->
		 			<!-- <td><?php echo e($tpu->Escuela); ?></td> -->
		 			<td><?php echo e($tpu->tbsegFecha); ?></td>
		 			<td><?php echo e($tpu->Materia); ?></td>
		 			<!-- <td><?php echo e($tpu->DesPl); ?></td> -->
		 			<td>
		 				<a href="" data-target="#modal-tabla-<?php echo e($tpu->idSeguimientoP); ?>" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!-- <td><?php echo e($tpu->DesSi); ?></td> -->
		 			<td>
		 				<a href="" data-target="#modal-silabo-<?php echo e($tpu->idSeguimientoP); ?>" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!-- <td><?php echo e($tpu->DesSe); ?></td> -->
		 			<td>
		 				<a href="" data-target="#modal-segdoc-<?php echo e($tpu->idSeguimientoP); ?>" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
		 			</td>
		 			<!--<td><?php echo e($tpu->DesOb); ?></td> -->
		 			<!--detalle observacion -->
		 			<td>
		 				<?php if($tpu->idObservacion =='1'): ?>
						<p class="label label-warning">Sin Comentario</p>
						<?php else: ?>
						<a href="" data-target="#modal-observdoc-<?php echo e($tpu->idSeguimientoP); ?>" data-toggle="modal"><button class="btn btn-link">Ver</button></a>
						<?php endif; ?>
		 				
		 			</td>
		 			<td>
		 				<a href="<?php echo e(URL::action('SegPedDocController@edit',$tpu->idSeguimientoP)); ?>"><button class="btn btn-info">Editar</button></a>
		 				<!-- 
		 				<a href="" data-target="#modal-delete-<?php echo e($tpu->idSeguimientoP); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a> -->
		 				<!-- Comentario -->
		 				<!-- 
		 				<?php if($tpu->idObservacion =='1'): ?>
						<h3><a href="<?php echo e(URL::action('ComentSegController@edit',$tpu->idSeguimientoP)); ?>"><button class="btn btn-success">Agg. Observacion</button></a></h3>
						<?php else: ?>
						
						<?php endif; ?> -->
		 				
		 				
		 			</td>
		 		</tr>
		 		<!-- <?php echo $__env->make('escuela.seguimiento.seguimientPed.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
		 		<?php echo $__env->make('escuela.seguimiento.seguimientPed.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('escuela.seguimiento.seguimientPed.modal3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('escuela.seguimiento.seguimientPed.modal4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('escuela.seguimiento.seguimientPed.modal5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php endforeach; ?>
		 	</table>
		 	
		 </div>
		 <?php echo e($segp->render()); ?>

	</div>		
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>