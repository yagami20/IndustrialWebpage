<?php $__env->startSection('contenido'); ?>
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de Planificaciones</h3>
		<?php echo $__env->make('escuela.descargadorP.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Fecha</th>
		 			<th>Planificacion</th>
		 			<th>Materia</th>
		 			<th>Semestre</th>
		 			
		 			<th>Paralelo</th>
		 			<th>Opciones</th>
		 		</thead>
		 		<?php foreach($planificacion as $usd): ?> 
		 		
		 		<tr>
		 			<td><?php echo e($usd->tbplFecha); ?></td>
		 			<td><?php echo e($usd->tbplDescripcion); ?></td>
		 			<td><?php echo e($usd->Materia); ?></td>
		 			<td><?php echo e($usd->Semestre); ?></td> 
		 			
		 			<td><?php echo e($usd->Paralelo); ?></td>
		 			
		 			<td>
		 				
		 				<a href="" data-target="#modal-tabla-<?php echo e($usd->idPlanificacion); ?>" data-toggle="modal"><button class="btn btn-success"> VER PDF</button></a>
		 			</td>
		 			
		 		</tr>
		 		
		 		
		 		<?php echo $__env->make('escuela.descargadorP.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php endforeach; ?>

		 	</table>
		 </div>
		 <?php echo e($planificacion->render()); ?>

	</div>		
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>