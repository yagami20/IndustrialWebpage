<?php $__env->startSection('contenido'); ?>

<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<!-- <h3>Listado Observaciones <a href="observacion/create"><button class="btn btn-success">Nuevo</button></a></h3> -->
		<h3>Busqueda de Indicadores de Autoevaluacion</h3>
		<?php echo $__env->make('escuela.autoevaluacion.BusqAut.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>