<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-delete-<?php echo e($tpu->idPlanificacion); ?>">
<?php echo e(Form::Open(array('action'=>array('PlanifController@destroy',$tpu->idPlanificacion),'method'=>'delete'))); ?>

<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Eliminar Planificacion</h4>
	</div>
	<div class="modal-body">
		<p>Las Planificaciones no se pueden eliminar ya que son la raiz del Seguimiento Pedagogico</p>
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
<?php echo e(Form::Close()); ?>	

</div>