<?php $__env->startSection('contenido'); ?>
	
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Listado de SubIndicadores <a href="<?php echo e(URL::action('SubindicController@create')); ?>"><button class="btn btn-success">Nuevo</button></a></h3>
		
	</div>
</div>

<div class="row">
	<div class="col-lg-14 col-md-14 col-sm-14 col-xs-14">
		 <div class="table-responsive">
		 	<table class="table table-striped table-bordered table-condensed table-hover" >
		 		<thead>
		 			<th>Criterio</th>
		 			<th>Subcriterio</th>
		 			<th>Indicador</th>
		 			<th>SubIndicador</th>
		 			<!-- <th>Documento</th> -->
		 			<!-- <th>Tabla</th> -->
		 			<th>Fecha</th>
		 			<th>Opciones</th>
		 		</thead>
		 		<?php foreach($subindicador as $usd): ?> 
		 		<tr>
		 			
		 			<td><?php echo e($usd->DesC); ?></td>
		 			<td><?php echo e($usd->DesSC); ?></td>
		 			<td><?php echo e($usd->DesIn); ?></td>
		 			<td><?php echo e($usd->DesSI); ?></td>
		 			<!-- <td><?php echo e($usd->tbsubiDocumento); ?></td> -->
		 			<!-- <td><?php echo e($usd->tbsubiTabla); ?></td> -->
		 			<td><?php echo e($usd->tbsubiFecha); ?></td>
		 			
		 			<td>
		 				<a href="<?php echo e(URL::action('SubindicController@edit',$usd->idSubindicador)); ?>"><button class="btn btn-info">Editar</button></a>
		 				<a href="" data-target="#modal-delete-<?php echo e($usd->idSubindicador); ?>" data-toggle="modal"><button class="btn btn-success">Documento</button></a>
		 				<a href="" data-target="#modal-tabla-<?php echo e($usd->idSubindicador); ?>" data-toggle="modal"><button class="btn btn-success">Tabla</button></a>
		 				
		 			</td>
		 			
		 		</tr>
		 		<?php echo $__env->make('escuela.autoevaluacion.subindicador.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('escuela.autoevaluacion.subindicador.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php endforeach; ?>

		 	</table>
		 </div>
		 <?php echo e($subindicador->render()); ?>

	</div>		
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>