<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nueva Publicacion</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php foreach($errors -> all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'escuela/publicaciones','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?>


		<div class="row">
			<!--Titulo id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpTitulo"> Titulo</label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbpTitulo" rows="5" cols="60">Titulo de la Publicacion</textarea>	
				</div>
				
			</div>	
			</div>
			<!--Descripcion id="edit-comment-body-und-0-value" -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpDescripcion"> Descripcion</label>
				<!-- <input type="text" name="tbpDescripcion" class="form-control" placeholder="Descripcion..." > -->
				<div class="from-group">
				<textarea name="tbpDescripcion" id="bodyField" rows="10" cols="70">Escribe aquí tu Descripcion</textarea>
				<?=app(JeroenNoten\LaravelCkEditor\CkEditor::class)->editor('bodyField', ['height' => 200],['width' => 200]);?>
				</div>
				
			</div>	
			</div>
			<!--seccion foto -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpFoto"> Foto</label>
				<input type="file" name="tbpFoto" class="form-control" >
			</div>	
			</div>
			<!--seccion examinar -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpExaminar"> Curriculo</label>
				<input type="file" name="tbpExaminar" class="form-control" placeholder="Curriculo..." >
			</div>	
			</div>
			<!-- Fecha -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpFecha"> Fecha</label>
				<input type="text" name="tbpFecha" required value="<?php echo e(old('tbpFecha')); ?>" class="form-control" placeholder="DD-MM-AA...">
			</div>	
			</div>
			<!-- -->
			<!-- seccion tbtipus -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<!-- Valorizacion -->
					<label>Escuela</label>
					<select name="idEscuela" class="form-control">
						<?php foreach($escuela as $tpu): ?>
						<?php if($tpu->idEscuela=='1'): ?>
						<option value="<?php echo e($tpu->idEscuela); ?>" readonly="readonly" selected><?php echo e($tpu->tbeNombre); ?></option>
						<?php endif; ?>

						<?php endforeach; ?>
					</select>

				</div>
			</div>
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbpEstado"> Estado</label>
				<input type="text" name="tbpEstado" required value="1" readonly="readonly" class="form-control">
				<!-- <input type="hidden" name="remember_token" value="<?php echo csrf_token(); ?>"> -->
			</div>	
			</div>
			<!-- -->
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>


			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>