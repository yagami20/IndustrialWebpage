<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Seguimiento:</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php foreach($errors -> all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

			<?php echo Form::model($segp,['method'=>'PATCH','route'=>['escuela.seguimiento.seguimientPed.update',$segp->idSeguimientoP], 'files'=>'true']); ?>

			<?php echo e(Form::token()); ?>

			
			<div class="row">
			<!-- seccion Escuela -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Escuela: </label>
					<select name="idEscuela" class="form-control">
						<?php foreach($escuela as $tps): ?>
						<option value="<?php echo e($tps->idEscuela); ?>"><?php echo e($tps->tbeNombre); ?></option>

						<?php endforeach; ?>
					</select>

				<!--<label for="tbtuId"> tuId</label>
				<input type="text" name="tbtuId" class="form-control" placeholder="tuId...">-->
			</div>
			</div>
			<!-- -->

			<!-- seccion planificacion -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Planificacion: </label>
					<select name="idPlanificacion" class="form-control">
						<?php foreach($planificacion as $tpl): ?>
						<?php if($tpl->idPlanificacion==$segp->idPlanificacion): ?>
						<option value="<?php echo e($tpl->idPlanificacion); ?>" selected><?php echo e($tpl->tbplDescripcion); ?></option>
						<?php else: ?>
						<option value="<?php echo e($tpl->idPlanificacion); ?>"><?php echo e($tpl->tbplDescripcion); ?></option>
						<?php endif; ?>

						<?php endforeach; ?>
					</select>

				
			</div>
			</div>
			<!-- -->
			<!-- seccion silabo -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Silabo: </label>
					<select name="idSilabo" class="form-control">
						<?php foreach($silabo as $tbs): ?>
						<?php if($tbs->idSilabo==$segp->idSilabo): ?>
						<option value="<?php echo e($tbs->idSilabo); ?>" selected><?php echo e($tbs->tbsiDescripcion); ?></option>
						<?php else: ?>
						<option value="<?php echo e($tbs->idSilabo); ?>"><?php echo e($tbs->tbsiDescripcion); ?></option>
						<?php endif; ?>

						<?php endforeach; ?>
					</select>
			</div>
			</div>
			<!-- -->
			<!-- seccion seguimiento -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12"> 
				<div class="from-group">
					<label>Seguimiento: </label>
					<select name="idSeguimiento" class="form-control">
						<?php foreach($seguimiento as $tpse): ?>
						<?php if($tpse->idSeguimiento==$segp->idSeguimiento): ?>
						<option value="<?php echo e($tpse->idSeguimiento); ?>" selected><?php echo e($tpse->tbseDescripcion); ?></option>
						<?php else: ?>
						<option value="<?php echo e($tpse->idSeguimiento); ?>"><?php echo e($tpse->tbseDescripcion); ?></option>
						<?php endif; ?>

						<?php endforeach; ?>
					</select>
			</div>
			</div>
			<!-- -->
			<!--observacion -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<input type="hidden" name="idObservacion" value="1">   

			</div>	
			</div>
			<!-- -->
			<!-- -->
			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="from-group">
				<label for="tbsegFecha"> Fecha: </label>
				<input type="text" name="tbsegFecha" required value="<?php echo e($segp->tbsegFecha); ?>" class="form-control" placeholder="DD-MM-AA...">

			</div>	
			</div>
			<!-- -->
			
		</div>
			
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>

			
			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>