/*general*/
jQuery(document).ready(function() {
	jQuery('#slider-home').carousel({
	  interval: 7000,
	  pause: "hover"
	})
});




